import React, { useState } from 'react';
import { Sparkles, Sliders, ArrowLeftRight, Clock, ShieldCheck, Check } from 'lucide-react';
import { ASSET_IMAGES } from '../data/cleaningData';

interface ComparisonCase {
  id: string;
  name: string;
  category: string;
  beforeLabel: string;
  afterLabel: string;
  beforeDetails: string[];
  afterDetails: string[];
  image: string;
  timeSpent: string;
}

export const BeforeAfterSection: React.FC = () => {
  const [sliderPosition, setSliderPosition] = useState<number>(50);
  const [selectedCaseIndex, setSelectedCaseIndex] = useState<number>(0);

  const cases: ComparisonCase[] = [
    {
      id: 'sofa',
      name: 'Fabric Sofa & Upholstery',
      category: 'Living Room',
      beforeLabel: 'Before: Stains & Odor',
      afterLabel: 'After: Fresh & Sanitized',
      beforeDetails: ['Dark tea & coffee spills', 'Deep dust trapped in foam', 'Sweat marks on armrests'],
      afterDetails: ['100% stain lifted', 'Sanitized against dust mites', 'Fresh pleasant fragrance'],
      image: ASSET_IMAGES.sofaCarpet,
      timeSpent: '75 Minutes'
    },
    {
      id: 'kitchen',
      name: 'Kitchen Chimney & Backsplash',
      category: 'Kitchen',
      beforeLabel: 'Before: Sticky Grease Slime',
      afterLabel: 'After: Mirror Polish Steel',
      beforeDetails: ['Clogged greasy baffle filters', 'Yellow oil residue on tiles', 'Sticky exhaust motor casing'],
      afterDetails: ['Suction restored to 100%', 'Sparkling tile grouting', 'Degreased food-safe surfaces'],
      image: ASSET_IMAGES.kitchenChimney,
      timeSpent: '90 Minutes'
    },
    {
      id: 'bathroom',
      name: 'Bathroom Tile & Hard Water Scale',
      category: 'Bathroom',
      beforeLabel: 'Before: White Chalky Scale',
      afterLabel: 'After: High Shine Chrome',
      beforeDetails: ['Mineral marks on shower glass', 'Yellow stains in toilet bowl', 'Discolored ceramic grout'],
      afterDetails: ['Limescale dissolved', 'Hospital grade disinfection', '99.9% bacteria free'],
      image: ASSET_IMAGES.deepHome,
      timeSpent: '60 Minutes'
    },
    {
      id: 'carpet',
      name: 'Living Room Carpet & Rug',
      category: 'Living Room',
      beforeLabel: 'Before: Matted & Dusty',
      afterLabel: 'After: Restored Color & Pile',
      beforeDetails: ['Dull faded pattern', 'Pet dander & food crumbs', 'Stale ambient odor'],
      afterDetails: ['Fluffy raised fiber pile', 'Vibrant original colors', 'Extracted deep mud slurry'],
      image: ASSET_IMAGES.sofaCarpet,
      timeSpent: '60 Minutes'
    },
    {
      id: 'floor',
      name: 'Vitrified Floor Machine Scrub',
      category: 'Full Home',
      beforeLabel: 'Before: Dull Scuff Marks',
      afterLabel: 'After: Factory Gloss Buff',
      beforeDetails: ['Blackened grout lines', 'Sticky foot grime layer', 'Dull matte finish'],
      afterDetails: ['Single-disc rotary buffed', 'Bright white grout lines', 'High reflection gloss'],
      image: ASSET_IMAGES.deepHome,
      timeSpent: '90 Minutes'
    }
  ];

  const currentCase = cases[selectedCaseIndex];

  return (
    <section id="before-after" className="py-16 sm:py-24 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Proven Real Results</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-display text-balance">
            Before & After
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Slide horizontally to see the visible difference our professional deep cleaning machinery makes on everyday home surfaces.
          </p>
        </div>

        {/* Case Selector Tabs */}
        <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {cases.map((c, idx) => (
            <button
              key={c.id}
              onClick={() => {
                setSelectedCaseIndex(idx);
                setSliderPosition(50);
              }}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-xl whitespace-nowrap transition-all cursor-pointer ${
                selectedCaseIndex === idx
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>

        {/* Interactive Comparison Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-slate-50 rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm">
          
          {/* Interactive Split Slider Container */}
          <div className="lg:col-span-8">
            <div className="relative h-[320px] sm:h-[420px] rounded-2xl overflow-hidden shadow-md select-none bg-slate-900">
              
              {/* After Image Layer (Base) */}
              <img
                src={currentCase.image}
                alt="After cleaning results"
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/40 via-transparent to-transparent pointer-events-none" />

              {/* After Badge (Right) */}
              <div className="absolute top-4 right-4 bg-emerald-600/95 backdrop-blur-md text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm">
                {currentCase.afterLabel}
              </div>

              {/* Before Layer (Clipped via slider position) */}
              <div
                className="absolute inset-0 overflow-hidden"
                style={{ width: `${sliderPosition}%` }}
              >
                <img
                  src={currentCase.image}
                  alt="Before cleaning state"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-cover filter brightness-[0.70] contrast-[1.15] sepia-[0.35]"
                  style={{ width: '100%', maxWidth: 'none' }}
                />
                <div className="absolute inset-0 bg-stone-900/35 pointer-events-none" />

                {/* Before Badge (Left) */}
                <div className="absolute top-4 left-4 bg-slate-900/95 backdrop-blur-md text-amber-300 text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm">
                  {currentCase.beforeLabel}
                </div>
              </div>

              {/* Slider Divider Bar with Draggable Handle */}
              <div
                className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-20 shadow-2xl"
                style={{ left: `${sliderPosition}%` }}
              >
                <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-9 h-9 rounded-full bg-white text-slate-800 shadow-xl border-2 border-emerald-500 flex items-center justify-center">
                  <ArrowLeftRight className="w-4 h-4 text-emerald-600" />
                </div>
              </div>

              {/* Interactive Range Slider (Overlay for smooth touch/mouse scrubbing) */}
              <input
                type="range"
                min="0"
                max="100"
                value={sliderPosition}
                onChange={(e) => setSliderPosition(Number(e.target.value))}
                className="absolute inset-0 opacity-0 cursor-ew-resize w-full h-full z-30"
                aria-label="Drag before and after comparison"
              />

              {/* Bottom helper prompt */}
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-black/70 backdrop-blur-xs text-white text-[11px] font-medium px-3 py-1 rounded-full pointer-events-none z-10">
                ↔ Drag slider left or right
              </div>
            </div>
          </div>

          {/* Right Column: Case Details & Transformation Breakdown */}
          <div className="lg:col-span-4 flex flex-col justify-between space-y-5">
            <div>
              <span className="text-xs uppercase tracking-wider font-bold text-emerald-700">
                {currentCase.category}
              </span>
              <h3 className="text-2xl font-extrabold text-slate-900 font-display mt-0.5">
                {currentCase.name}
              </h3>

              <div className="flex items-center gap-2 text-xs text-slate-500 mt-2 font-medium">
                <Clock className="w-3.5 h-3.5 text-emerald-600" />
                <span>Service Time: <strong>{currentCase.timeSpent}</strong></span>
              </div>

              {/* Before state checklist */}
              <div className="mt-5 p-3.5 bg-amber-50/70 border border-amber-200/80 rounded-xl">
                <div className="text-xs font-bold text-amber-900 mb-1.5 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500" />
                  Condition Before:
                </div>
                <ul className="space-y-1 text-xs text-amber-800">
                  {currentCase.beforeDetails.map((b, i) => (
                    <li key={i}>• {b}</li>
                  ))}
                </ul>
              </div>

              {/* After state checklist */}
              <div className="mt-3 p-3.5 bg-emerald-50/70 border border-emerald-200/80 rounded-xl">
                <div className="text-xs font-bold text-emerald-900 mb-1.5 flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  Outcome After Cleaning:
                </div>
                <ul className="space-y-1 text-xs text-emerald-800 font-medium">
                  {currentCase.afterDetails.map((a, i) => (
                    <li key={i}>✓ {a}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-2 text-xs text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>100% Satisfaction Check before technician leaves your home.</span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
