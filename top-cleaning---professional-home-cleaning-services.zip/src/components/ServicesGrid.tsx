import React, { useState, useMemo } from 'react';
import { Search, Sparkles, Clock, Star, ArrowRight, Eye, Calendar, CheckCircle, Languages } from 'lucide-react';
import { ServiceItem } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';
import { ThreeDCard } from './ThreeDCard';

interface ServicesGridProps {
  services: ServiceItem[];
  onSelectService: (service: ServiceItem) => void;
  onBookService: (serviceName: string, startingPrice: number) => void;
}

export const ServicesGrid: React.FC<ServicesGridProps> = ({
  services,
  onSelectService,
  onBookService,
}) => {
  const { language, toggleLanguage, t } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = [
    { id: 'all', label: language === 'hi' ? 'सभी सेवाएं (28)' : 'All Services (28)' },
    { id: 'full_home', label: language === 'hi' ? 'पूरा घर' : 'Full Home' },
    { id: 'rooms', label: language === 'hi' ? 'कमरे' : 'Rooms' },
    { id: 'kitchen_bath', label: language === 'hi' ? 'किचन व बाथरूम' : 'Kitchen & Bath' },
    { id: 'furniture_fabric', label: language === 'hi' ? 'सोफा व कारपेट' : 'Furniture & Fabric' },
    { id: 'appliances', label: language === 'hi' ? 'अप्लायंसेज' : 'Appliances' },
    { id: 'specialized', label: language === 'hi' ? 'स्पेशल काम (लोडिंग, पेड़, कार)' : 'Specialized (Loading, Tree, Car)' },
  ];

  const filteredServices = useMemo(() => {
    return services.filter((service) => {
      const matchesCategory =
        selectedCategory === 'all' || service.category === selectedCategory;
      const matchesSearch =
        service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        service.shortDesc.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [services, selectedCategory, searchQuery]);

  return (
    <section id="services" className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading with 1-Touch Translate Trigger */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-6">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100/80 border border-emerald-300 px-3 py-1 rounded-full uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
              <span>{language === 'hi' ? '3D सर्विस डायरेक्टरी · 1-टच भाषा बदलें' : '3D Service Directory · 1-Touch Bilingual'}</span>
            </div>
            <div className="flex items-center gap-3">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight font-display text-balance">
                {t('servicesTitle')}
              </h2>
              <button
                type="button"
                onClick={toggleLanguage}
                title="Touch to switch language (टच करके भाषा बदलें)"
                className="hidden sm:inline-flex items-center gap-1 px-3 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border-2 border-emerald-300 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
              >
                <Languages className="w-3.5 h-3.5 text-emerald-600" />
                <span>{language === 'hi' ? '1-Touch English' : '1-टच हिंदी'}</span>
              </button>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-2xl font-medium">
              {t('servicesSub')}
            </p>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-80 shrink-0">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('searchServicePlaceholder')}
              className="w-full h-11 pl-10 pr-4 bg-white border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 shadow-xs"
            />
          </div>
        </div>

        {/* Category Pills with 3D Tactile Elevation */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-200 cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-emerald-600 text-white shadow-[0_4px_10px_rgba(16,185,129,0.35)] -translate-y-0.5'
                  : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 hover:border-slate-300'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Service Cards with 3D Perspective & Touch-to-Translate */}
        {filteredServices.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-sm max-w-md mx-auto">
            <p className="text-slate-500 font-bold">
              {language === 'hi' ? `"${searchQuery}" के लिए कोई सर्विस नहीं मिली` : `No cleaning services found for "${searchQuery}"`}
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="mt-4 px-4 py-2 text-xs font-bold text-emerald-800 bg-emerald-100 rounded-xl hover:bg-emerald-200 cursor-pointer"
            >
              {language === 'hi' ? 'फ़िल्टर हटाएं' : 'Reset Filters'}
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredServices.map((service) => (
              <ThreeDCard key={service.id} allowTouchTranslate={true}>
                <div className="flex flex-col bg-white rounded-3xl overflow-hidden border-2 border-slate-200/90 hover:border-emerald-400 shadow-sm transition-colors duration-300 h-full">
                  
                  {/* Image Slot */}
                  <div className="relative h-48 w-full overflow-hidden bg-slate-100">
                    <img
                      src={service.image}
                      alt={service.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />

                    {/* Pricing Tag Overlay */}
                    <div className="absolute bottom-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-xl shadow-md border border-slate-200 text-slate-900">
                      <span className="text-[10px] text-slate-500 block uppercase font-bold leading-none">
                        {t('startingFrom')}
                      </span>
                      <span className="text-base font-black font-display text-emerald-800 leading-tight">
                        ₹{service.startingPrice}
                      </span>
                    </div>

                    {/* Rating Overlay */}
                    <div className="absolute bottom-3 right-3 flex items-center gap-1 bg-slate-900/80 backdrop-blur-md px-2 py-1 rounded-lg text-[11px] text-white font-bold">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                      <span>{service.rating}</span>
                      <span className="text-slate-400 text-[10px]">({service.reviewsCount})</span>
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 mb-1.5 font-bold">
                        <Clock className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{service.duration}</span>
                        <span aria-hidden="true">·</span>
                        <span className="capitalize text-emerald-800">{service.category.replace('_', ' ')}</span>
                      </div>

                      <h3 className="text-base font-black text-slate-900 group-hover:text-emerald-700 transition-colors line-clamp-1">
                        {service.name}
                      </h3>

                      <p className="text-xs text-slate-500 mt-1.5 line-clamp-2 leading-relaxed">
                        {service.shortDesc}
                      </p>

                      {/* Features mini checklist */}
                      <div className="mt-3 pt-3 border-t border-slate-100 space-y-1">
                        {service.features.slice(0, 2).map((feat, idx) => (
                          <div key={idx} className="flex items-center gap-1.5 text-[11px] text-slate-600 line-clamp-1">
                            <CheckCircle className="w-3 h-3 text-emerald-600 shrink-0" />
                            <span>{feat}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* 3D Tactile Buttons */}
                    <div className="mt-5 pt-3 border-t border-slate-100 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => onSelectService(service)}
                        className="flex-1 inline-flex items-center justify-center gap-1 py-2.5 px-3 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all active:scale-95 cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5 text-slate-600" />
                        <span>{language === 'hi' ? 'डिटेल देखें' : 'Details'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onBookService(service.name, service.startingPrice)}
                        className="flex-1 inline-flex items-center justify-center gap-1 py-2.5 px-3 text-xs font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-[0_3px_0_#047857] active:translate-y-0.5 active:shadow-none transition-all cursor-pointer"
                      >
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{t('bookNow')}</span>
                      </button>
                    </div>

                  </div>

                </div>
              </ThreeDCard>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
