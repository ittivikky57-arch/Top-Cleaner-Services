import React, { useState } from 'react';
import { Phone, MessageCircle, Mail, MapPin, Send, CheckCircle2, Calendar, Sparkles, Languages } from 'lucide-react';
import { CONTACT_INFO, INITIAL_SERVICES } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';

interface ContactSectionProps {
  onOpenBooking: () => void;
  onNewInquiry?: (inquiry: {
    name: string;
    phone: string;
    email: string;
    service: string;
    message: string;
    time: string;
  }) => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onOpenBooking, onNewInquiry }) => {
  const { language, toggleLanguage, t } = useLanguage();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [service, setService] = useState('Full Home Deep Cleaning');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const whatsappUrl = `https://wa.me/${CONTACT_INFO.whatsappNumber}?text=${encodeURIComponent(
    language === 'hi'
      ? 'नमस्ते PURE CLEANING, मुझे पूछताछ या बुकिंग करनी है।\n\nनाम:\nसर्विस:\nपता:'
      : 'Hello PURE CLEANING, I want to book a service.\n\nName:\nService:\nAddress:\nPreferred Date:\nPreferred Time:'
  )}`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    if (onNewInquiry) {
      onNewInquiry({
        name: name.trim(),
        phone: phone.trim(),
        email: email.trim() || 'Not provided',
        service,
        message: message.trim() || (language === 'hi' ? 'सामान्य पूछताछ' : 'General enquiry'),
        time: new Date().toLocaleTimeString(),
      });
    }

    setSubmitted(true);
    setName('');
    setPhone('');
    setEmail('');
    setMessage('');
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <section id="contact" className="py-16 sm:py-24 bg-slate-50 border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header with 1-Touch Translate */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100 px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>{language === 'hi' ? '3D फास्ट रिस्पॉन्स डेस्क' : 'Fast Response Desk'}</span>
          </div>

          <div className="flex items-center justify-center gap-3">
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight font-display text-balance">
              {t('contactTitle')}
            </h2>
            <button
              type="button"
              onClick={toggleLanguage}
              title="Touch to switch language (टच करके भाषा बदलें)"
              className="inline-flex items-center gap-1 px-3 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border-2 border-emerald-300 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
            </button>
          </div>

          <p className="text-xs sm:text-sm text-slate-600 mt-2 font-medium">
            {t('contactSub')}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Direct Contact Info & CTAs */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-sm space-y-6">
              <h3 className="text-xl font-black text-slate-900 font-display">
                {language === 'hi' ? 'सीधा संपर्क करें' : 'Get In Touch Directly'}
              </h3>
              
              <div className="space-y-4">
                {/* Phone */}
                <a
                  href={`tel:${CONTACT_INFO.phoneRaw}`}
                  className="flex items-start gap-3.5 p-3 rounded-2xl hover:bg-slate-50 transition-colors group"
                >
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 font-bold block uppercase">{language === 'hi' ? 'कॉल (डायरेक्ट)' : 'Phone Call (Direct)'}</span>
                    <span className="text-base font-black text-slate-900 group-hover:text-emerald-700">
                      {CONTACT_INFO.phone}
                    </span>
                  </div>
                </a>

                {/* WhatsApp */}
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-3.5 p-3 rounded-2xl hover:bg-slate-50 transition-colors group"
                >
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 font-bold block uppercase">{language === 'hi' ? 'व्हाट्सएप चैट' : 'WhatsApp Messaging'}</span>
                    <span className="text-base font-black text-slate-900 group-hover:text-emerald-700">
                      {CONTACT_INFO.whatsapp}
                    </span>
                  </div>
                </a>

                {/* Email */}
                <a
                  href={`mailto:${CONTACT_INFO.email}`}
                  className="flex items-start gap-3.5 p-3 rounded-2xl hover:bg-slate-50 transition-colors group"
                >
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 font-bold block uppercase">{language === 'hi' ? 'ईमेल सपोर्ट' : 'Email Support'}</span>
                    <span className="text-base font-black text-slate-900 group-hover:text-emerald-700 truncate">
                      {CONTACT_INFO.email}
                    </span>
                  </div>
                </a>

                {/* Hours */}
                <div className="flex items-start gap-3.5 p-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center shrink-0">
                    <Calendar className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 font-bold block uppercase">{language === 'hi' ? 'काम के घंटे' : 'Service Hours'}</span>
                    <span className="text-sm font-black text-slate-900">
                      {CONTACT_INFO.workingHours}
                    </span>
                  </div>
                </div>
              </div>

              {/* Direct Booking Modal Button */}
              <div className="pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={onOpenBooking}
                  className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-4 text-xs font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-2xl shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none transition-all cursor-pointer"
                >
                  <Calendar className="w-4 h-4" />
                  <span>{language === 'hi' ? 'तारीख व समय के साथ ऑनलाइन बुक करें' : 'Book Date & Time Slot Online'}</span>
                </button>
              </div>
            </div>

          </div>

          {/* Right Column: Online Enquiry Form */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-3xl p-6 sm:p-8 lg:p-10 border-2 border-slate-200 shadow-xl">
              <h3 className="text-xl font-black text-slate-900 font-display mb-1">
                {language === 'hi' ? 'ऑनलाइन सर्विस मैसेज भेजें' : 'Send an Online Enquiry'}
              </h3>
              <p className="text-xs text-slate-500 mb-6 font-medium">
                {language === 'hi' ? 'हमारी टीम 15-30 मिनट में आपसे संपर्क करेगी।' : 'Fill details below and our service desk will contact you within 15-30 minutes.'}
              </p>

              {submitted ? (
                <div className="p-8 text-center bg-emerald-50 rounded-2xl border-2 border-emerald-200 space-y-3">
                  <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto animate-bounce" />
                  <h4 className="text-lg font-black text-slate-900">
                    {language === 'hi' ? 'पूछताछ मैसेज भेज दिया गया!' : 'Enquiry Received!'}
                  </h4>
                  <p className="text-xs text-slate-600 font-medium">
                    {language === 'hi' ? 'धन्यवाद! हमारी टीम जल्द ही आपसे संपर्क करेगी।' : 'Thank you. Our dispatch supervisor will call you shortly on your number.'}
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">
                        {language === 'hi' ? 'आपका नाम *' : 'Your Name *'}
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder={language === 'hi' ? 'उदा: राहुल वर्मा' : 'e.g. Rahul V.'}
                        className="w-full h-11 px-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">
                        {language === 'hi' ? 'मोबाइल नंबर *' : 'Mobile Number *'}
                      </label>
                      <input
                        type="tel"
                        required
                        maxLength={10}
                        value={phone}
                        onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                        placeholder="62043 19105"
                        className="w-full h-11 px-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">
                        {language === 'hi' ? 'ईमेल (वैकल्पिक)' : 'Email (Optional)'}
                      </label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="user@example.com"
                        className="w-full h-11 px-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">
                        {language === 'hi' ? 'सर्विस चुनें' : 'Service Required'}
                      </label>
                      <select
                        value={service}
                        onChange={(e) => setService(e.target.value)}
                        className="w-full h-11 px-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                      >
                        {INITIAL_SERVICES.map((s) => (
                          <option key={s.id} value={s.name}>
                            {s.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {language === 'hi' ? 'मैसेज / काम का विवरण' : 'Message / Details of Work'}
                    </label>
                    <textarea
                      rows={3}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder={language === 'hi' ? 'घर का साइज, विशेष दाग या कोई सवाल लिखें...' : 'Mention property size, special requirements or questions...'}
                      className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-6 text-sm font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-2xl shadow-[0_5px_0_#047857] active:translate-y-1 active:shadow-none transition-all cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>{language === 'hi' ? 'मैसेज भेजें (Submit Enquiry)' : 'Send Service Inquiry'}</span>
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
