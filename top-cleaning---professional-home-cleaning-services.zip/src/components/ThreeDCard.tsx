import React, { useState, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Languages } from 'lucide-react';

interface ThreeDCardProps {
  children: React.ReactNode;
  className?: string;
  allowTouchTranslate?: boolean;
  intensity?: number;
}

export const ThreeDCard: React.FC<ThreeDCardProps> = ({
  children,
  className = '',
  allowTouchTranslate = true,
  intensity = 15
}) => {
  const { language, toggleLanguage } = useLanguage();
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotX = ((y - centerY) / centerY) * -intensity;
    const rotY = ((x - centerX) / centerX) * intensity;

    setRotateX(rotX);
    setRotateY(rotY);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setIsHovered(false);
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      style={{
        perspective: 1000,
      }}
      className="relative group transition-transform duration-200"
    >
      <div
        style={{
          transform: isHovered
            ? `rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(12px)`
            : 'rotateX(0deg) rotateY(0deg) translateZ(0px)',
          transition: isHovered ? 'transform 0.1s ease-out' : 'transform 0.4s cubic-bezier(0.2, 0.8, 0.2, 1)',
          transformStyle: 'preserve-3d',
        }}
        className={`relative rounded-3xl transition-shadow duration-300 ${
          isHovered
            ? 'shadow-[0_20px_40px_rgba(0,0,0,0.12),0_10px_20px_rgba(16,185,129,0.1)]'
            : 'shadow-[0_4px_20px_rgba(0,0,0,0.05)]'
        } ${className}`}
      >
        {/* Subtle 3D Glass Light Sheen */}
        <div
          className={`absolute inset-0 rounded-3xl pointer-events-none transition-opacity duration-300 z-10 ${
            isHovered ? 'opacity-100' : 'opacity-0'
          }`}
          style={{
            background: 'linear-gradient(135deg, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0) 60%)',
          }}
        />

        {/* Quick 1-Touch Translate Mini Badge on Card Corner */}
        {allowTouchTranslate && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              toggleLanguage();
            }}
            title="Touch to switch Hindi / English (टच करके भाषा बदलें)"
            className="absolute top-3 right-3 z-30 opacity-70 group-hover:opacity-100 hover:scale-110 active:scale-95 transition-all p-1.5 rounded-full bg-white/90 backdrop-blur-md border border-slate-200/90 shadow-sm text-[10px] font-bold text-slate-700 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
          >
            <Languages className="w-3 h-3 text-emerald-600" />
            <span className="text-[10px] uppercase font-mono tracking-tight font-extrabold">
              {language === 'hi' ? 'ENG' : 'हिंदी'}
            </span>
          </button>
        )}

        {children}
      </div>
    </div>
  );
};
