import React from 'react';
import { Phone, MessageCircle, Calendar, Languages } from 'lucide-react';
import { CONTACT_INFO } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';

interface FloatingActionsProps {
  onOpenBooking: () => void;
}

export const FloatingActions: React.FC<FloatingActionsProps> = ({ onOpenBooking }) => {
  const { language, toggleLanguage, t } = useLanguage();

  const whatsappUrl = `https://wa.me/${CONTACT_INFO.whatsappNumber}?text=${encodeURIComponent(
    language === 'hi'
      ? 'नमस्ते PURE CLEANING, मुझे सर्विस बुक करनी है।\n\nनाम:\nसर्विस:\nपता:'
      : 'Hello PURE CLEANING, I want to book a cleaning or loading service.\n\nName:\nService:\nAddress:\nPreferred Date:\nPreferred Time:'
  )}`;

  return (
    <>
      {/* Desktop Floating Actions (Bottom Right) */}
      <div className="fixed bottom-6 right-6 z-40 hidden sm:flex flex-col items-end gap-3 group">
        
        {/* 3D Floating 1-Touch Language Switcher */}
        <button
          onClick={toggleLanguage}
          title="1-Touch Language Switch (एक टच में भाषा बदलें)"
          className="flex items-center gap-2 px-4 py-2.5 bg-white/95 hover:bg-white text-slate-800 rounded-full shadow-[0_8px_20px_rgba(0,0,0,0.15)] border-2 border-emerald-300 hover:border-emerald-500 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer"
        >
          <Languages className="w-4 h-4 text-emerald-600" />
          <span className="text-xs font-black tracking-wide">
            {language === 'hi' ? '🇮🇳 हिंदी (Tap for ENG)' : '🇬🇧 English (टच: हिंदी)'}
          </span>
        </button>

        {/* WhatsApp Floating CTA */}
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-5 py-3.5 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-full shadow-[0_8px_25px_rgba(37,211,102,0.4)] hover:scale-105 active:scale-95 transition-all duration-200"
          title="Book on WhatsApp"
        >
          <MessageCircle className="w-5 h-5 fill-white text-[#25D366]" />
          <span className="text-xs font-black tracking-wide">
            {language === 'hi' ? 'व्हाट्सएप पर बात करें' : 'Book on WhatsApp'}
          </span>
        </a>
      </div>

      {/* Mobile Bottom Fixed Bar (Compact, with 1-Touch Language Pill) */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-2 flex items-center justify-between gap-1.5 shadow-2xl">
        
        {/* 1-Touch Translate Button */}
        <button
          onClick={toggleLanguage}
          title="Switch Language"
          className="flex items-center justify-center gap-1 py-2 px-2.5 bg-emerald-50 active:bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-xl text-[11px] font-black transition-colors"
        >
          <Languages className="w-3.5 h-3.5 text-emerald-700" />
          <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
        </button>

        {/* Direct Call Button */}
        <a
          href={`tel:${CONTACT_INFO.phoneRaw}`}
          className="flex-1 flex items-center justify-center gap-1 py-2 px-2 bg-slate-100 active:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-colors"
        >
          <Phone className="w-3.5 h-3.5 text-emerald-600" />
          <span>{t('callNow')}</span>
        </a>

        {/* WhatsApp Button */}
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex items-center justify-center gap-1 py-2 px-2 bg-[#25D366] active:bg-[#20ba59] text-white rounded-xl text-xs font-black transition-colors shadow-xs"
        >
          <MessageCircle className="w-3.5 h-3.5 fill-white text-[#25D366]" />
          <span>{t('whatsapp')}</span>
        </a>

        {/* Book Now Button */}
        <button
          onClick={onOpenBooking}
          className="flex-1 flex items-center justify-center gap-1 py-2 px-2 bg-emerald-600 active:bg-emerald-700 text-white rounded-xl text-xs font-black transition-colors shadow-xs cursor-pointer"
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>{t('bookNow')}</span>
        </button>
      </div>
    </>
  );
};
