import React, { useState } from 'react';
import {
  X,
  Calendar,
  DollarSign,
  Tag,
  CheckCircle,
  Clock,
  Phone,
  MessageCircle,
  Plus,
  Trash2,
  Edit2,
  Users,
  Search,
  Filter,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { BookingRecord, ServiceItem, CONTACT_INFO } from '../data/cleaningData';

interface AdminDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookings: BookingRecord[];
  services: ServiceItem[];
  onUpdateBookingStatus: (bookingId: string, newStatus: BookingRecord['status']) => void;
  onUpdateServicePrice: (serviceId: string, newPrice: number) => void;
  onAddService: (newService: ServiceItem) => void;
  onDeleteService: (serviceId: string) => void;
  currentDiscount: number;
  onUpdateDiscount: (newDiscount: number) => void;
  inquiries: Array<{
    name: string;
    phone: string;
    email: string;
    service: string;
    message: string;
    time: string;
  }>;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  isOpen,
  onClose,
  bookings,
  services,
  onUpdateBookingStatus,
  onUpdateServicePrice,
  onAddService,
  onDeleteService,
  currentDiscount,
  onUpdateDiscount,
  inquiries,
}) => {
  const [activeTab, setActiveTab] = useState<'bookings' | 'services' | 'offers' | 'inquiries'>('bookings');
  const [searchBookingQuery, setSearchBookingQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  
  // New service form state
  const [showAddService, setShowAddService] = useState(false);
  const [newServiceName, setNewServiceName] = useState('');
  const [newServicePrice, setNewServicePrice] = useState(499);
  const [newServiceCategory, setNewServiceCategory] = useState<ServiceItem['category']>('specialized');
  const [newServiceDesc, setNewServiceDesc] = useState('');

  // Discount settings state
  const [discountVal, setDiscountVal] = useState(currentDiscount);
  const [discountSavedNotice, setDiscountSavedNotice] = useState(false);

  if (!isOpen) return null;

  const filteredBookings = bookings.filter((b) => {
    const matchesStatus = statusFilter === 'All' || b.status === statusFilter;
    const matchesSearch =
      b.customerName.toLowerCase().includes(searchBookingQuery.toLowerCase()) ||
      b.id.toLowerCase().includes(searchBookingQuery.toLowerCase()) ||
      b.phone.includes(searchBookingQuery) ||
      b.service.toLowerCase().includes(searchBookingQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const getStatusBadge = (status: BookingRecord['status']) => {
    switch (status) {
      case 'New':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Confirmed':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Assigned':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'In Progress':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Completed':
        return 'bg-slate-100 text-slate-800 border-slate-300';
      case 'Cancelled':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  const handleCreateService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newServiceName.trim()) return;

    const newSvc: ServiceItem = {
      id: `svc-${Date.now()}`,
      name: newServiceName.trim(),
      category: newServiceCategory,
      shortDesc: newServiceDesc.trim() || 'Custom on-demand cleaning service.',
      fullDesc: newServiceDesc.trim() || 'Custom on-demand cleaning service tailored to your home needs.',
      startingPrice: Number(newServicePrice),
      duration: '1 - 2 Hours',
      rating: 5.0,
      reviewsCount: 1,
      image: services[0]?.image || '',
      features: ['Trained professional team', 'Safe specialized chemicals', 'Machine scrubbing'],
      includes: ['Surface cleaning', 'Floor wash', 'Inspection check'],
      equipmentUsed: ['Industrial Vacuum', 'Microfiber Kits']
    };

    onAddService(newSvc);
    setNewServiceName('');
    setNewServiceDesc('');
    setNewServicePrice(499);
    setShowAddService(false);
  };

  const handleSaveDiscount = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateDiscount(Number(discountVal));
    setDiscountSavedNotice(true);
    setTimeout(() => setDiscountSavedNotice(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/75 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-6xl w-full max-h-[94vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
        
        {/* Modal Top Bar */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base font-display">
                PURE CLEANING · Business Admin Console
              </h3>
              <p className="text-[11px] text-slate-400">
                Manage bookings, update prices, modify discount offers & customer enquiries
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Controls Bar */}
        <div className="px-6 py-3 bg-slate-100 border-b border-slate-200 flex items-center justify-between gap-3 overflow-x-auto shrink-0">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveTab('bookings')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
                activeTab === 'bookings'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Bookings ({bookings.length})
            </button>

            <button
              onClick={() => setActiveTab('services')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
                activeTab === 'services'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Services & Pricing ({services.length})
            </button>

            <button
              onClick={() => setActiveTab('offers')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
                activeTab === 'offers'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Offers & Promo System
            </button>

            <button
              onClick={() => setActiveTab('inquiries')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
                activeTab === 'inquiries'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Customer Enquiries ({inquiries.length})
            </button>
          </div>

          <div className="text-xs text-slate-500 hidden sm:block">
            Support: <strong className="text-slate-800">+91 62043 19105</strong>
          </div>
        </div>

        {/* Tab Body Contents */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50">
          
          {/* TAB 1: BOOKING MANAGEMENT */}
          {activeTab === 'bookings' && (
            <div className="space-y-4">
              
              {/* Search & Filter Header */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchBookingQuery}
                    onChange={(e) => setSearchBookingQuery(e.target.value)}
                    placeholder="Search by customer name, ID, phone, or service..."
                    className="w-full h-9 pl-9 pr-3 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div className="flex items-center gap-2 overflow-x-auto">
                  <span className="text-xs font-semibold text-slate-500 shrink-0">Status:</span>
                  {['All', 'New', 'Confirmed', 'Assigned', 'In Progress', 'Completed', 'Cancelled'].map((st) => (
                    <button
                      key={st}
                      onClick={() => setStatusFilter(st)}
                      className={`px-2.5 py-1 text-[11px] font-bold rounded-lg border whitespace-nowrap transition-colors ${
                        statusFilter === st
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              {/* Bookings Table */}
              <div className="bg-white rounded-2xl border border-slate-200 overflow-x-auto shadow-2xs">
                <table className="w-full text-left text-xs text-slate-700">
                  <thead className="bg-slate-100 text-slate-800 text-[11px] uppercase font-bold tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Booking ID</th>
                      <th className="py-3 px-4">Customer</th>
                      <th className="py-3 px-4">Service & Property</th>
                      <th className="py-3 px-4">Schedule</th>
                      <th className="py-3 px-4">Address</th>
                      <th className="py-3 px-4">Price</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredBookings.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-12 text-center text-slate-400 font-medium">
                          No matching bookings found.
                        </td>
                      </tr>
                    ) : (
                      filteredBookings.map((b) => (
                        <tr key={b.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-slate-900">
                            {b.id}
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-bold text-slate-900">{b.customerName}</div>
                            <div className="text-[11px] text-slate-500">{b.phone}</div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-semibold text-slate-900">{b.service}</div>
                            <div className="text-[11px] text-slate-500">{b.propertyType}</div>
                          </td>
                          <td className="py-3 px-4 whitespace-nowrap">
                            <div className="font-medium text-slate-800">{b.date}</div>
                            <div className="text-[11px] text-emerald-700 font-semibold">{b.timeSlot}</div>
                          </td>
                          <td className="py-3 px-4 max-w-xs truncate" title={b.address}>
                            {b.address}
                          </td>
                          <td className="py-3 px-4 font-extrabold text-slate-900 font-display">
                            ₹{b.price}
                          </td>
                          <td className="py-3 px-4">
                            <select
                              value={b.status}
                              onChange={(e) =>
                                onUpdateBookingStatus(b.id, e.target.value as BookingRecord['status'])
                              }
                              className={`text-[11px] font-bold px-2 py-1 rounded-lg border focus:outline-none ${getStatusBadge(
                                b.status
                              )}`}
                            >
                              <option value="New">New</option>
                              <option value="Confirmed">Confirmed</option>
                              <option value="Assigned">Assigned</option>
                              <option value="In Progress">In Progress</option>
                              <option value="Completed">Completed</option>
                              <option value="Cancelled">Cancelled</option>
                            </select>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <a
                                href={`tel:${b.phone}`}
                                title="Call Customer"
                                className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700"
                              >
                                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                              </a>
                              <a
                                href={`https://wa.me/${b.phone.replace(/\D/g, '')}?text=${encodeURIComponent(
                                  `Hello ${b.customerName}, regarding your PURE CLEANING booking #${b.id} for ${b.service}.`
                                )}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                title="WhatsApp Customer"
                                className="p-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800"
                              >
                                <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                              </a>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: SERVICES & PRICING MANAGEMENT */}
          {activeTab === 'services' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">
                    Live Service Catalog ({services.length} Services)
                  </h4>
                  <p className="text-xs text-slate-500">
                    Edit starting prices directly or add custom services.
                  </p>
                </div>

                <button
                  onClick={() => setShowAddService(!showAddService)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl"
                >
                  <Plus className="w-4 h-4" />
                  <span>{showAddService ? 'Cancel' : 'Add New Service'}</span>
                </button>
              </div>

              {/* Add New Service Form */}
              {showAddService && (
                <form
                  onSubmit={handleCreateService}
                  className="bg-white p-5 rounded-2xl border border-emerald-300 shadow-sm space-y-3"
                >
                  <div className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Add New Service
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">Service Name *</label>
                      <input
                        type="text"
                        required
                        value={newServiceName}
                        onChange={(e) => setNewServiceName(e.target.value)}
                        placeholder="e.g. Terrace Moss Scrubbing"
                        className="w-full h-9 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">Starting Price (₹) *</label>
                      <input
                        type="number"
                        required
                        value={newServicePrice}
                        onChange={(e) => setNewServicePrice(Number(e.target.value))}
                        className="w-full h-9 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">Category *</label>
                      <select
                        value={newServiceCategory}
                        onChange={(e) => setNewServiceCategory(e.target.value as any)}
                        className="w-full h-9 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                      >
                        <option value="full_home">Full Home</option>
                        <option value="rooms">Rooms</option>
                        <option value="kitchen_bath">Kitchen & Bath</option>
                        <option value="furniture_fabric">Furniture & Fabric</option>
                        <option value="appliances">Appliances</option>
                        <option value="specialized">Specialized</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Short Description</label>
                    <input
                      type="text"
                      value={newServiceDesc}
                      onChange={(e) => setNewServiceDesc(e.target.value)}
                      placeholder="Summary of what the service cleans..."
                      className="w-full h-9 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                  >
                    Save Service
                  </button>
                </form>
              )}

              {/* Service Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {services.map((svc) => (
                  <div
                    key={svc.id}
                    className="bg-white p-4 rounded-xl border border-slate-200 flex items-center justify-between gap-3"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-xs sm:text-sm text-slate-900 truncate">
                        {svc.name}
                      </div>
                      <div className="text-[10px] text-slate-500 uppercase tracking-wide">
                        {svc.category.replace('_', ' ')}
                      </div>
                    </div>

                    {/* Quick price editor */}
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded-lg border border-slate-200">
                        <span className="text-xs text-slate-500 font-bold">₹</span>
                        <input
                          type="number"
                          defaultValue={svc.startingPrice}
                          onBlur={(e) => {
                            const val = Number(e.target.value);
                            if (val > 0) onUpdateServicePrice(svc.id, val);
                          }}
                          className="w-16 bg-transparent text-xs font-bold text-slate-900 focus:outline-none font-display"
                        />
                      </div>

                      <button
                        onClick={() => onDeleteService(svc.id)}
                        title="Delete service"
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: OFFERS & PROMO SYSTEM */}
          {activeTab === 'offers' && (
            <div className="max-w-xl mx-auto space-y-6 bg-white p-6 rounded-2xl border border-slate-200">
              <div>
                <h4 className="text-base font-bold text-slate-900 font-display">
                  Promotional Offer Management
                </h4>
                <p className="text-xs text-slate-500">
                  Configure active promo codes and discount amounts reflected on website.
                </p>
              </div>

              <form onSubmit={handleSaveDiscount} className="space-y-4">
                <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 space-y-2">
                  <div className="text-xs font-bold text-emerald-900">
                    Active Code: FIRST100
                  </div>
                  <p className="text-xs text-emerald-800">
                    Currently gives customers a flat ₹{currentDiscount} discount on their first booking.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    First Booking Discount Amount (₹)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={1000}
                    value={discountVal}
                    onChange={(e) => setDiscountVal(Number(e.target.value))}
                    className="w-full h-10 px-3 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                  />
                </div>

                {discountSavedNotice && (
                  <div className="text-xs font-semibold text-emerald-700 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4" />
                    <span>Discount successfully updated to ₹{discountVal}!</span>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-3 px-4 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl"
                >
                  Save Offer Settings
                </button>
              </form>
            </div>
          )}

          {/* TAB 4: CUSTOMER ENQUIRIES */}
          {activeTab === 'inquiries' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-900">
                  Customer Enquiries Received ({inquiries.length})
                </h4>
                <span className="text-xs text-slate-500">Submitted through contact form</span>
              </div>

              {inquiries.length === 0 ? (
                <div className="py-12 text-center bg-white rounded-2xl border border-slate-200 text-slate-400 text-xs">
                  No inquiries received yet.
                </div>
              ) : (
                <div className="space-y-2">
                  {inquiries.map((inq, i) => (
                    <div
                      key={i}
                      className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-slate-900">{inq.name}</span>
                          <span className="text-xs text-slate-400">({inq.time})</span>
                        </div>
                        <div className="text-xs text-slate-600 mt-0.5">
                          Phone: <strong>{inq.phone}</strong> · Email: {inq.email}
                        </div>
                        <div className="text-xs text-emerald-800 font-semibold mt-0.5">
                          Interested in: {inq.service}
                        </div>
                        {inq.message && (
                          <div className="text-xs text-slate-500 mt-1 italic">
                            "{inq.message}"
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <a
                          href={`tel:${inq.phone}`}
                          className="px-3 py-1.5 text-xs font-bold bg-slate-900 text-white rounded-lg hover:bg-slate-800"
                        >
                          Call
                        </a>
                        <a
                          href={`https://wa.me/${inq.phone.replace(/\D/g, '')}?text=${encodeURIComponent(
                            `Hello ${inq.name}, thank you for contacting PURE CLEANING regarding ${inq.service}.`
                          )}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 text-xs font-bold bg-emerald-600 text-white rounded-lg hover:bg-emerald-700"
                        >
                          WhatsApp
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
