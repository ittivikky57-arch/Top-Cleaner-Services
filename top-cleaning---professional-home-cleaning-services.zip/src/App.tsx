import React, { useState } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { SearchBookingBox } from './components/SearchBookingBox';
import { ServicesGrid } from './components/ServicesGrid';
import { FullHomeSection } from './components/FullHomeSection';
import { RoomByRoomSection } from './components/RoomByRoomSection';
import { ItemCatalogSection } from './components/ItemCatalogSection';
import { EquipmentSection } from './components/EquipmentSection';
import { BeforeAfterSection } from './components/BeforeAfterSection';
import { PricingSection } from './components/PricingSection';
import { PriceCalculator } from './components/PriceCalculator';
import { CleaningMaterialsSection } from './components/CleaningMaterialsSection';
import { CarWashSection } from './components/CarWashSection';
import { LoadingUnloadingSection } from './components/LoadingUnloadingSection';
import { TreePruningSection } from './components/TreePruningSection';
import { AboutSection } from './components/AboutSection';
import { ReviewsSection } from './components/ReviewsSection';
import { FAQSection } from './components/FAQSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';
import { ServiceDetailModal } from './components/ServiceDetailModal';
import { AdminDashboardModal } from './components/AdminDashboardModal';
import { FloatingActions } from './components/FloatingActions';

import {
  INITIAL_SERVICES,
  INITIAL_BOOKINGS,
  ServiceItem,
  BookingRecord,
  CONTACT_INFO
} from './data/cleaningData';

export default function App() {
  const [services, setServices] = useState<ServiceItem[]>(INITIAL_SERVICES);
  const [bookings, setBookings] = useState<BookingRecord[]>(INITIAL_BOOKINGS);
  const [currentDiscount, setCurrentDiscount] = useState<number>(CONTACT_INFO.firstBookingDiscount);
  
  const [inquiries, setInquiries] = useState<
    Array<{
      name: string;
      phone: string;
      email: string;
      service: string;
      message: string;
      time: string;
    }>
  >([
    {
      name: 'Vikas Mishra',
      phone: '9810234512',
      email: 'vikas.m@gmail.com',
      service: 'Bungalow / Duplex Cleaning',
      message: 'Need full exterior jet washing and marble polishing for a 3-floor villa next Sunday.',
      time: '08:15 AM'
    }
  ]);

  // Modal states
  const [detailService, setDetailService] = useState<ServiceItem | null>(null);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  // Booking modal form prefill state
  const [bookingModalState, setBookingModalState] = useState<{
    isOpen: boolean;
    service: string;
    price: number;
    propertyType: string;
    date?: string;
    timeSlot?: string;
    address?: string;
    phone?: string;
  }>({
    isOpen: false,
    service: 'Full Home Deep Cleaning',
    price: 1499,
    propertyType: '2 BHK',
  });

  const handleOpenBooking = (serviceName?: string, price?: number, propertyType?: string) => {
    setBookingModalState((prev) => ({
      ...prev,
      isOpen: true,
      service: serviceName || 'Full Home Deep Cleaning',
      price: price || 1499,
      propertyType: propertyType || prev.propertyType || '2 BHK',
    }));
  };

  const handleCloseBooking = () => {
    setBookingModalState((prev) => ({ ...prev, isOpen: false }));
  };

  const handleSearchBoxBook = (data: {
    service: string;
    propertyType: string;
    date: string;
    timeSlot: string;
    address: string;
    phone: string;
    estimatedPrice: number;
  }) => {
    setBookingModalState({
      isOpen: true,
      service: data.service,
      price: data.estimatedPrice,
      propertyType: data.propertyType,
      date: data.date,
      timeSlot: data.timeSlot,
      address: data.address,
      phone: data.phone,
    });
  };

  const handleCalculatorBook = (calc: {
    propertyType: string;
    cleaningType: string;
    addons: string[];
    price: number;
  }) => {
    const serviceTitle = `${calc.cleaningType} (${calc.propertyType})`;
    setBookingModalState({
      isOpen: true,
      service: serviceTitle,
      price: calc.price,
      propertyType: calc.propertyType,
    });
  };

  const handleBookCarWash = (
    packageName: string,
    price: number,
    vehicleType: string
  ) => {
    setBookingModalState({
      isOpen: true,
      service: `Doorstep Car Care: ${packageName}`,
      price,
      propertyType: `${vehicleType} Vehicle`,
    });
  };

  const handleBookLoadingService = (
    packageName: string,
    price: number,
    duration: string,
    helpers: string
  ) => {
    setBookingModalState({
      isOpen: true,
      service: packageName,
      price,
      propertyType: `${helpers} · ${duration}`,
    });
  };

  const handleBookTreeService = (
    packageName: string,
    price: number,
    duration: string,
    crew: string
  ) => {
    setBookingModalState({
      isOpen: true,
      service: packageName,
      price,
      propertyType: `${crew} · ${duration}`,
    });
  };

  const handleNewBookingCreated = (record: BookingRecord) => {
    setBookings((prev) => [record, ...prev]);
  };

  const handleUpdateBookingStatus = (
    bookingId: string,
    newStatus: BookingRecord['status']
  ) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, status: newStatus } : b))
    );
  };

  const handleUpdateServicePrice = (serviceId: string, newPrice: number) => {
    setServices((prev) =>
      prev.map((s) => (s.id === serviceId ? { ...s, startingPrice: newPrice } : s))
    );
  };

  const handleAddService = (newSvc: ServiceItem) => {
    setServices((prev) => [newSvc, ...prev]);
  };

  const handleDeleteService = (serviceId: string) => {
    setServices((prev) => prev.filter((s) => s.id !== serviceId));
  };

  const handleNewInquiry = (inquiry: {
    name: string;
    phone: string;
    email: string;
    service: string;
    message: string;
    time: string;
  }) => {
    setInquiries((prev) => [inquiry, ...prev]);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col font-sans pb-12 sm:pb-0">
      
      {/* 1. Header / Navigation */}
      <Header
        onOpenBooking={(svc) => handleOpenBooking(svc)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        bookingCount={bookings.length}
      />

      <main className="flex-1">
        {/* 2. Hero Section */}
        <HeroSection onOpenBooking={() => handleOpenBooking()} />

        {/* 3. Search / Booking Box (Placed directly below Hero) */}
        <SearchBookingBox onDirectBook={handleSearchBoxBook} />

        {/* 4. Services Section (27 Services) */}
        <ServicesGrid
          services={services}
          onSelectService={(svc) => setDetailService(svc)}
          onBookService={(name, price) => handleOpenBooking(name, price)}
        />

        {/* 5. Full Home Cleaning (BHK Pricing & Details) */}
        <FullHomeSection
          onBookTier={(tierName, price) => handleOpenBooking(tierName, price)}
        />

        {/* Dedicated Doorstep Car Washing & Detailing Section */}
        <CarWashSection onBookCarWash={handleBookCarWash} />

        {/* Dedicated Loading & Unloading Helpers Section */}
        <LoadingUnloadingSection onBookLoading={handleBookLoadingService} />

        {/* Dedicated Tree Felling & Pruning Work Section */}
        <TreePruningSection onBookTreeService={handleBookTreeService} />

        {/* 6. Room-by-Room Cleaning ("Clean Every Room") */}
        <RoomByRoomSection
          onBookRoom={(roomName, price) => handleOpenBooking(roomName, price)}
        />

        {/* 7. Cleaning Item Catalog ("What Can We Clean?") */}
        <ItemCatalogSection
          onBookItem={(itemName, price) => handleOpenBooking(itemName, price)}
        />

        {/* 8. Cleaning Equipment Section ("Modern Equipment. Better Results.") */}
        <EquipmentSection />

        {/* Dedicated Certified Cleaning Materials & Safe Chemicals Section */}
        <CleaningMaterialsSection />

        {/* 9. Before / After Interactive Slider Section */}
        <BeforeAfterSection />

        {/* 10. Transparent Pricing Section */}
        <PricingSection
          onBookService={(svcName, price) => handleOpenBooking(svcName, price)}
        />

        {/* 11. Interactive Price Calculator */}
        <PriceCalculator onBookCalculated={handleCalculatorBook} />

        {/* 15, 16, 17. About Us, Why Choose PURE CLEANING, Service Promise */}
        <AboutSection />

        {/* 18. Customer Reviews & 5-Star Testimonials */}
        <ReviewsSection />

        {/* 19. FAQ Section */}
        <FAQSection />

        {/* 20. Contact Section */}
        <ContactSection
          onOpenBooking={() => handleOpenBooking()}
          onNewInquiry={handleNewInquiry}
        />
      </main>

      {/* 21. Footer */}
      <Footer
        onOpenBooking={(svc) => handleOpenBooking(svc)}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* 13 & 14. Floating WhatsApp & Call Buttons */}
      <FloatingActions onOpenBooking={() => handleOpenBooking()} />

      {/* 12. Date & Time Booking Modal */}
      <BookingModal
        isOpen={bookingModalState.isOpen}
        onClose={handleCloseBooking}
        initialService={bookingModalState.service}
        initialPrice={bookingModalState.price}
        initialPropertyType={bookingModalState.propertyType}
        initialDate={bookingModalState.date}
        initialTime={bookingModalState.timeSlot}
        initialAddress={bookingModalState.address}
        initialPhone={bookingModalState.phone}
        onBookingConfirmed={handleNewBookingCreated}
      />

      {/* Service Detail Modal */}
      <ServiceDetailModal
        service={detailService}
        onClose={() => setDetailService(null)}
        onBookNow={(name, price) => handleOpenBooking(name, price)}
      />

      {/* 24 & 25. Admin Dashboard Console */}
      <AdminDashboardModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        bookings={bookings}
        services={services}
        onUpdateBookingStatus={handleUpdateBookingStatus}
        onUpdateServicePrice={handleUpdateServicePrice}
        onAddService={handleAddService}
        onDeleteService={handleDeleteService}
        currentDiscount={currentDiscount}
        onUpdateDiscount={setCurrentDiscount}
        inquiries={inquiries}
      />

    </div>
  );
}
