import React from 'react';
import {
  Trees,
  Clock,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  MessageCircle,
  Scissors,
  Wrench,
  Users,
  AlertTriangle,
  Sparkles,
  Languages
} from 'lucide-react';
import {
  TREE_PRUNING_PACKAGES,
  TreePruningPackage,
  ASSET_IMAGES,
  CONTACT_INFO
} from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';
import { ThreeDCard } from './ThreeDCard';

interface TreePruningSectionProps {
  onBookTreeService: (packageName: string, price: number, duration: string, crew: string) => void;
}

export const TreePruningSection: React.FC<TreePruningSectionProps> = ({ onBookTreeService }) => {
  const { language, toggleLanguage, t } = useLanguage();

  const whatsappUrl = (pkgTitle: string, price: number, duration: string) => {
    const text = language === 'hi'
      ? `नमस्ते PURE CLEANING, मुझे पेड़ कटाई / छंटाई की सर्विस बुक करनी है:\n\nपैकेज: ${pkgTitle}\nरेट: ₹${price}\nसमय: ${duration}\n\nकृपया टीम की उपलब्धता कन्फर्म करें।`
      : `Hello PURE CLEANING, I want to book Tree Felling & Pruning Service:\n\nService: ${pkgTitle}\nPrice: ₹${price}\nEstimated Time: ${duration}\n\nPlease check arborist availability.`;
    return `https://wa.me/${CONTACT_INFO.whatsappNumber}?text=${encodeURIComponent(text)}`;
  };

  return (
    <section id="tree-pruning" className="py-16 sm:py-24 bg-gradient-to-b from-emerald-950/20 via-white to-slate-50 border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with 1-Touch Translate */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100 border border-emerald-300 px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-3 shadow-2xs">
            <Trees className="w-3.5 h-3.5 text-emerald-700" />
            <span>{language === 'hi' ? '3D आर्बोरिस्ट एवं पेड़ देखभाल (पेड़ कटाई व छंटाई)' : '3D Arborist & Garden Tree Care'}</span>
          </div>

          <div className="flex items-center justify-center gap-3">
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight font-display text-balance">
              {t('treeTitle')}
            </h2>
            <button
              type="button"
              onClick={toggleLanguage}
              title="Touch to switch language (टच करके भाषा बदलें)"
              className="inline-flex items-center gap-1 px-3 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border-2 border-emerald-300 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
            </button>
          </div>

          <p className="text-base sm:text-lg font-black text-emerald-700 mt-2">
            {t('treeSubHindi')}
          </p>

          <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
            {t('treeDesc')}
          </p>
        </div>

        {/* 3D Visual Showcase Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-white rounded-3xl p-6 sm:p-8 lg:p-10 border-2 border-emerald-100 shadow-[0_20px_45px_rgba(16,185,129,0.08)] mb-12">
          
          {/* Left Photo */}
          <div className="lg:col-span-6 relative group">
            <div className="rounded-3xl overflow-hidden shadow-2xl border-2 border-emerald-100 bg-slate-100 h-[300px] sm:h-[360px]">
              <img
                src={ASSET_IMAGES.treePruning}
                alt="Professional arborist pruning tree branches safely with chainsaw and protective gear"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center group-hover:scale-104 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />

              <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md p-3.5 rounded-2xl border border-slate-200 text-xs text-slate-800 shadow-xl">
                <div className="font-black text-emerald-800 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>{language === 'hi' ? 'रोप रिगिंग व जीरो प्रॉपर्टी डैमेज गारंटी' : 'Rope Rigging & Zero Property Damage Guarantee'}</span>
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5 font-medium">
                  {language === 'hi'
                    ? 'भारी डालियों को रस्सियों से बांधकर धीरे-धीरे नीचे उतारा जाता है ताकि वे खिड़कियों, सोलर पैनल या बाउंड्री पर न गिरें।'
                    : 'Heavy branches are tied with guide ropes and gently lowered down so they never strike windows, solar panels, or walls.'}
                </div>
              </div>
            </div>
          </div>

          {/* Right Column Highlights */}
          <div className="lg:col-span-6 space-y-3.5">
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="flex items-center gap-2.5 mb-1">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs shrink-0">
                  <Scissors className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-black text-slate-900">
                  {language === 'hi' ? 'बिजली के तारों व बालकनी से डालियां हटाना' : 'Overhang & Electric Line Clearance'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed pl-10.5 font-medium">
                {language === 'hi'
                  ? 'हाई-टेंशन तारों, बालकनी रेलिंग या एसी आउटर यूनिट को छूती खतरनाक डालियों को 25 फीट तक एक्सटेंशन पोल आरी से सुरक्षित काटना।'
                  : 'Precision trimming of branches threatening wires, balconies, or AC units using telescopic pole saws up to 25 ft.'}
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="flex items-center gap-2.5 mb-1">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs shrink-0">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-black text-slate-900">
                  {language === 'hi' ? 'तूफान में झुके व खोखले पेड़ को हटाना' : 'Storm-Damaged & Leaning Tree Removal'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed pl-10.5 font-medium">
                {language === 'hi'
                  ? 'दीमक लगे या खतरनाक रूप से झुके पेड़ों को ऊपर से नीचे टुकड़ों में काटकर सुरक्षित हटाना जिससे किसी भी वाहन या दीवार को नुकसान न हो।'
                  : 'Sectional top-down dismantling of termite-damaged or leaning trees without risking nearby homes, cars, or walls.'}
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="flex items-center gap-2.5 mb-1">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs shrink-0">
                  <Trees className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-black text-slate-900">
                  {language === 'hi' ? 'कटी लकड़ियों का बंडल व पत्तों की सफाई' : 'Green Foliage Bagging & Debris Disposal'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed pl-10.5 font-medium">
                {language === 'hi'
                  ? 'कटी लकड़ियों को छोटे टुकड़ों में काटकर एक जगह ढेर लगाना और गिरे पत्तों को झाड़कर बोरियों में भरकर परिसर को साफ-सुथरा छोड़ना।'
                  : 'We chop severed branches into manageable logs, sweep up fallen leaves, and bundle waste neatly for compound cleanup.'}
              </p>
            </div>
          </div>

        </div>

        {/* 4 Packages Grid with 3D Card Elevation & Touch-to-Translate */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {TREE_PRUNING_PACKAGES.map((pkg) => (
            <ThreeDCard key={pkg.id} allowTouchTranslate={true}>
              <div className="bg-white rounded-3xl p-6 border-2 border-slate-200 hover:border-emerald-400 shadow-sm transition-all flex flex-col justify-between h-full relative">
                {pkg.badge && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-emerald-700 text-white text-[10px] font-black uppercase px-3 py-1 rounded-full shadow-md">
                    {pkg.badge}
                  </span>
                )}

                <div>
                  <div className="flex items-center gap-1.5 text-xs font-black text-emerald-700 uppercase tracking-wider mb-1">
                    <Users className="w-3.5 h-3.5" />
                    <span>{pkg.crew}</span>
                  </div>

                  <h3 className="text-lg font-black text-slate-900 font-display">
                    {pkg.title}
                  </h3>

                  <span className="inline-block text-[11px] font-black text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-lg mt-1 border border-emerald-200">
                    {pkg.category}
                  </span>

                  <p className="text-xs text-slate-500 mt-2 leading-relaxed line-clamp-3">
                    {pkg.description}
                  </p>

                  {/* Price & Duration */}
                  <div className="mt-4 p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold block uppercase">
                        {language === 'hi' ? 'शुरुआती रेट' : 'Starting Price'}
                      </span>
                      <span className="text-2xl font-black text-slate-900 font-display">
                        ₹{pkg.startingPrice}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 font-bold block uppercase">
                        {language === 'hi' ? 'काम का समय' : 'Work Time'}
                      </span>
                      <span className="text-xs font-black text-slate-800 flex items-center gap-1 justify-end mt-0.5">
                        <Clock className="w-3.5 h-3.5 text-emerald-600" />
                        {pkg.duration}
                      </span>
                    </div>
                  </div>

                  {/* Work Scope */}
                  <div className="mt-5 space-y-2">
                    <div className="text-[11px] font-black text-slate-900 uppercase tracking-wide">
                      {t('workScope')}
                    </div>
                    <ul className="space-y-1.5 text-xs text-slate-600">
                      {pkg.workScope.map((scope, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{scope}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Equipment Used */}
                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                      {t('machineryUsed')}
                    </span>
                    <div className="flex flex-wrap gap-1.5 text-[11px] text-slate-700">
                      {pkg.equipmentUsed.map((tool, i) => (
                        <span key={i} className="bg-slate-100 px-2.5 py-0.5 rounded-lg text-[11px] font-medium">
                          • {tool}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Action Buttons with 3D Touch */}
                <div className="mt-6 pt-4 border-t border-slate-100 space-y-2.5">
                  <button
                    type="button"
                    onClick={() =>
                      onBookTreeService(
                        `Tree Service: ${pkg.title}`,
                        pkg.startingPrice,
                        pkg.duration,
                        pkg.crew
                      )
                    }
                    className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 text-xs font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-2xl shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none transition-all cursor-pointer"
                  >
                    <span>{t('bookTreeService')} (₹{pkg.startingPrice})</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <a
                    href={whatsappUrl(pkg.title, pkg.startingPrice, pkg.duration)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-black text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{language === 'hi' ? 'व्हाट्सएप पर बुक करें' : 'Book on WhatsApp'}</span>
                  </a>
                </div>

              </div>
            </ThreeDCard>
          ))}
        </div>

        {/* Safety & Municipal Notice */}
        <div className="mt-12 bg-white rounded-2xl p-5 border border-emerald-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-700">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>
              <strong>{language === 'hi' ? 'आर्बोरिस्ट सेफ़्टी स्टैंडर्ड्स:' : 'Arborist Safety Standards:'}</strong>{' '}
              {language === 'hi'
                ? 'सभी पेड़ छंटाई और कटाई का काम प्रशिक्षित क्लाइम्बिंग क्रू और सुरक्षा उपकरणों द्वारा किया जाता है ताकि किसी भी दुर्घटना का जोखिम न हो।'
                : 'All tree trimming & felling is performed by experienced climbing arborists using safety rigging to prevent accidents.'}
            </span>
          </div>
          <div className="text-emerald-700 font-black whitespace-nowrap">
            {language === 'hi' ? 'इमरजेंसी पेड़ कटाई सेवा उपलब्ध' : 'Emergency Branch Clearance Service'}
          </div>
        </div>

      </div>
    </section>
  );
};
