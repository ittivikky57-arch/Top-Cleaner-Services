import React, { useState } from 'react';
import { Home, Sparkles, CheckCircle2, ArrowRight, ShieldCheck, Clock, Users, Wrench, Languages } from 'lucide-react';
import { ASSET_IMAGES } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';
import { ThreeDCard } from './ThreeDCard';

interface FullHomeSectionProps {
  onBookTier: (tierName: string, price: number) => void;
}

export const FullHomeSection: React.FC<FullHomeSectionProps> = ({ onBookTier }) => {
  const { language, toggleLanguage, t } = useLanguage();
  const [selectedTier, setSelectedTier] = useState<'1bhk' | '2bhk' | '3bhk' | '4bhk' | 'bungalow'>('2bhk');

  const tiers = {
    '1bhk': {
      name: language === 'hi' ? '1 BHK फ्लैट' : '1 BHK Apartment',
      price: 999,
      duration: '3.5 - 4 Hours',
      crew: language === 'hi' ? '2 - 3 प्रोफेशनल्स' : '2 - 3 Professionals',
      description: language === 'hi'
        ? 'छोटे फ्लैट्स या 1 BHK के लिए सम्पूर्ण फर्श से छत तक डीप सफाई।'
        : 'Ideal for bachelor flats or compact 1 BHK apartments needing a thorough floor-to-ceiling refresh.',
      scope: language === 'hi' 
        ? ['1 बेडरूम डीप वैक्यूम व डस्टिंग', '1 बाथरूम खारे पानी के दाग हटाना व सैनिटाइजेशन', '1 किचन स्लैब व टाइल्स से तेल हटाना', 'लिविंग रूम फर्श वॉश व बालकनी सफाई']
        : ['1 Bedroom deep vacuum & dust', '1 Bathroom descaling & commode sanitizing', '1 Kitchen platform & backsplash degrease', 'Living-dining floor wet scrubbing & balcony clean']
    },
    '2bhk': {
      name: language === 'hi' ? '2 BHK फ्लैट' : '2 BHK Apartment',
      price: 1499,
      duration: '4.5 - 5 Hours',
      crew: language === 'hi' ? '3 - 4 प्रोफेशनल्स' : '3 - 4 Professionals',
      description: language === 'hi'
        ? 'हमारा सबसे लोकप्रिय पैकेज! परिवार के 2 BHK फ्लैट की सम्पूर्ण डीप सफाई व सैनिटाइजेशन।'
        : 'Our most popular package for standard nuclear family apartments. Complete deep sanitation of all areas.',
      scope: language === 'hi'
        ? ['2 बेडरूम, पंखे, खिड़कियां व वार्डरोब आउटर क्लीनिंग', '2 बाथरूम टाइल्स व कमोड 99.9% कीटाणुमुक्त', 'किचन चिमनी व एग्जॉस्ट फैन ऑयल रिमूवल', 'लिविंग रूम सोफा वैक्यूमिंग व बालकनी वॉश']
        : ['2 Bedrooms detailed sanitization', '2 Bathrooms hard water stain removal', 'Kitchen exhaust, chimney & sink deep scrub', 'Living room sofa vacuuming & balcony wash']
    },
    '3bhk': {
      name: language === 'hi' ? '3 BHK फ्लैट' : '3 BHK Apartment',
      price: 1999,
      duration: '5 - 6 Hours',
      crew: language === 'hi' ? '4 - 5 प्रोफेशनल्स' : '4 - 5 Professionals',
      description: language === 'hi'
        ? 'बड़े 3 BHK फ्लैट्स के लिए व्यापक सफाई, सभी कमरे, कई बालकनियां और बड़ा हॉल।'
        : 'Comprehensive sanitization for spacious family apartments, covering large halls and multiple balconies.',
      scope: language === 'hi'
        ? ['3 बेडरूम व पंखों की डीप डस्टिंग', '3 बाथरूम ग्राउट व लाइमस्केल ट्रीटमेंट', 'किचन का जिद्दी ग्रीस हटाना', 'हॉल, डाइनिंग व 2 बालकनियों की मशीन से धुलाई']
        : ['3 Bedrooms, wardrobes exterior & fan de-dusting', '3 Bathrooms complete lime and grout treatment', 'Full kitchen grease stripping & appliance exterior wipe', 'Living, dining, 2 balconies & window tracks cleaned']
    },
    '4bhk': {
      name: language === 'hi' ? '4 BHK लग्जरी फ्लैट' : '4 BHK Luxury Apartment',
      price: 2499,
      duration: '6 - 7 Hours',
      crew: language === 'hi' ? '5 - 6 प्रोफेशनल्स' : '5 - 6 Professionals',
      description: language === 'hi'
        ? 'बड़े लग्जरी फ्लैट्स, पेंटहाउस और डुप्लेक्स के लिए सुपरवाइजर सहित भारी मशीन सफाई।'
        : 'Intensive deep scrubbing for large luxury flats, penthouses and duplex apartments with supervisor.',
      scope: language === 'hi'
        ? ['4 बेडरूम व ड्रेसिंग एरिया सफाई', '4 बाथरूम हाई ग्लॉस पॉलिश', 'मॉड्यूलर किचन ग्रीस पूरी तरह साफ', 'विशाल लिविंग रूम व सभी बालकनियों की धुलाई']
        : ['4 Bedrooms & dressing spaces', '4 Bathrooms descaled & high gloss polish', 'Modular kitchen grease elimination', 'Expansive living, dining & multiple balconies washed']
    },
    'bungalow': {
      name: language === 'hi' ? 'विला / बंगला / डुप्लेक्स' : 'Bungalow / Villa / Duplex',
      price: 3499,
      duration: '7 - 9 Hours',
      crew: language === 'hi' ? '6 - 8 स्पेशलिस्ट क्रू' : '6 - 8 Specialist Crew',
      description: language === 'hi'
        ? 'मल्टी-फ्लोर स्वतंत्र कोठी व विला के लिए हाई प्रेशर जेट वॉशर और फ्लोर बफर के साथ।'
        : 'Multi-story specialized crew with high-pressure washers, floor scrubbers and exterior terrace cleaners.',
      scope: language === 'hi'
        ? ['सभी मंजिलें, सीढ़ियों की रेलिंग व छत', 'टेरेस व पोर्च हाई-प्रेशर जेट स्प्रे', 'विशाल ग्लास फसाड व झूमर सफाई', 'कम्पाउंड दीवार व ड्राइववे वॉश']
        : ['All floors, grand staircases & multiple bathrooms', 'Terrace & car porch high-pressure jet blast', 'Exterior glass facades & chandeliers', 'Complete boundary & driveway wash']
    }
  };

  const currentTier = tiers[selectedTier];

  return (
    <section id="full-home" className="py-16 sm:py-24 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with 1-Touch Translate */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100/80 border border-emerald-300 px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-3 shadow-2xs">
            <Home className="w-3.5 h-3.5 text-emerald-700" />
            <span>{language === 'hi' ? '3D फुल होम डीप क्लीनिंग पैकेज' : 'Complete Property Transformation'}</span>
          </div>

          <div className="flex items-center justify-center gap-3">
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight font-display text-balance">
              {t('fullHomeTitle')}
            </h2>
            <button
              type="button"
              onClick={toggleLanguage}
              title="Touch to switch language (टच करके भाषा बदलें)"
              className="inline-flex items-center gap-1 px-3 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border-2 border-emerald-300 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
            </button>
          </div>

          <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-2xl mx-auto leading-relaxed">
            {t('fullHomeSub')}
          </p>

          {/* Tier Selector with 3D Pills */}
          <div className="flex items-center justify-center gap-2 overflow-x-auto p-1.5 bg-slate-100 rounded-2xl max-w-2xl mx-auto mt-6 border border-slate-200 shadow-inner">
            {(Object.keys(tiers) as Array<keyof typeof tiers>).map((tierKey) => (
              <button
                key={tierKey}
                onClick={() => setSelectedTier(tierKey)}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer whitespace-nowrap ${
                  selectedTier === tierKey
                    ? 'bg-emerald-600 text-white shadow-[0_4px_10px_rgba(16,185,129,0.35)] -translate-y-0.5'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                }`}
              >
                {tiers[tierKey].name}
              </button>
            ))}
          </div>
        </div>

        {/* 3D Tier Details Showcase Card */}
        <ThreeDCard allowTouchTranslate={true}>
          <div className="bg-slate-50 rounded-3xl p-6 sm:p-8 lg:p-10 border-2 border-slate-200 shadow-[0_20px_50px_rgba(0,0,0,0.06)] grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Visual Photo Slot */}
            <div className="lg:col-span-5 relative group">
              <div className="rounded-3xl overflow-hidden shadow-2xl border-2 border-slate-200 bg-slate-200 h-[280px] sm:h-[350px]">
                <img
                  src={ASSET_IMAGES.deepHome}
                  alt={currentTier.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center group-hover:scale-104 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />
                <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md p-3.5 rounded-2xl border border-slate-200 text-xs">
                  <div className="font-black text-emerald-800 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>{language === 'hi' ? '100% संतुष्टि गारंटी' : '100% Satisfaction Re-clean Guarantee'}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5 font-medium">
                    {language === 'hi'
                      ? 'यदि कोई कोना छूट जाता है, तो हमारी टीम बिना अतिरिक्त शुल्क के उसे ठीक करती है।'
                      : 'If you are not 100% satisfied with any corner, we send a re-cleaner at zero extra charge.'}
                  </div>
                </div>
              </div>
            </div>

            {/* Content & Scope Breakdown */}
            <div className="lg:col-span-7 flex flex-col justify-between h-full space-y-6">
              <div>
                <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-200">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-lg">
                      {language === 'hi' ? 'फ्लैगशिप पैकेज' : 'Flagship Package'}
                    </span>
                    <h3 className="text-2xl font-black text-slate-900 font-display mt-1">
                      {currentTier.name}
                    </h3>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 font-bold block uppercase">
                      {language === 'hi' ? 'पैकेज रेट' : 'Package Price'}
                    </span>
                    <span className="text-3xl font-black text-emerald-700 font-display">
                      ₹{currentTier.price}
                    </span>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-600 mt-3 font-medium leading-relaxed">
                  {currentTier.description}
                </p>

                {/* Micro Meta (Duration & Crew) */}
                <div className="grid grid-cols-2 gap-3 mt-4">
                  <div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center gap-3">
                    <Clock className="w-5 h-5 text-emerald-600 shrink-0" />
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">
                        {language === 'hi' ? 'समय अवधि' : 'Duration'}
                      </span>
                      <span className="text-xs font-black text-slate-800">{currentTier.duration}</span>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center gap-3">
                    <Users className="w-5 h-5 text-emerald-600 shrink-0" />
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">
                        {language === 'hi' ? 'क्रू साइज' : 'Assigned Crew'}
                      </span>
                      <span className="text-xs font-black text-slate-800">{currentTier.crew}</span>
                    </div>
                  </div>
                </div>

                {/* Scope of Work */}
                <div className="mt-5 space-y-2">
                  <div className="text-xs font-black text-slate-900 uppercase tracking-wide">
                    {language === 'hi' ? 'शामिल काम (What is Included):' : 'What is Included in this Package:'}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600">
                    {currentTier.scope.map((item, idx) => (
                      <div key={idx} className="flex items-start gap-1.5 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* 3D Action Button */}
              <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center gap-3">
                <button
                  type="button"
                  onClick={() => onBookTier(currentTier.name, currentTier.price)}
                  className="w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-2 py-3.5 px-6 text-sm font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-2xl shadow-[0_5px_0_#047857] active:translate-y-1 active:shadow-none transition-all cursor-pointer"
                >
                  <span>{t('bookNow')} ({currentTier.name} · ₹{currentTier.price})</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>

          </div>
        </ThreeDCard>

      </div>
    </section>
  );
};
