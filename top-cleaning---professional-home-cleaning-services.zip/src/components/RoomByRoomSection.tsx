import React from 'react';
import { Sparkles, Clock, CheckCircle2, ArrowRight } from 'lucide-react';
import { ROOM_CLEANING_ITEMS, RoomCleaningItem } from '../data/cleaningData';

interface RoomByRoomSectionProps {
  onBookRoom: (roomName: string, price: number) => void;
}

export const RoomByRoomSection: React.FC<RoomByRoomSectionProps> = ({ onBookRoom }) => {
  return (
    <section id="rooms" className="py-16 sm:py-24 bg-slate-50 border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Targeted Cleaning</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-display text-balance">
            Clean Every Room
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Need only specific areas sanitized? Book dedicated room deep-cleaning packages with specialized equipment.
          </p>
        </div>

        {/* 6 Room Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {ROOM_CLEANING_ITEMS.map((room) => (
            <div
              key={room.id}
              className="group bg-white rounded-2xl overflow-hidden border border-slate-200 hover:border-emerald-300 shadow-xs hover:shadow-md transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Visual Area */}
                <div className="relative h-48 w-full overflow-hidden bg-slate-100">
                  <img
                    src={room.image}
                    alt={room.roomName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />

                  <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-white">
                    <h3 className="text-lg font-bold font-display drop-shadow-sm">
                      {room.roomName}
                    </h3>
                    <span className="text-xs bg-emerald-600/90 font-bold px-2 py-1 rounded backdrop-blur-xs shadow-xs">
                      ₹{room.startingPrice} onwards
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 mb-3">
                    <Clock className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Estimated time: {room.duration}</span>
                  </div>

                  <div className="text-xs font-bold text-slate-900 uppercase tracking-wide mb-2">
                    Cleaning Included:
                  </div>

                  <ul className="space-y-1.5">
                    {room.includedTasks.map((task, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs text-slate-600">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{task}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Card Footer Action */}
              <div className="p-5 pt-0">
                <button
                  onClick={() => onBookRoom(`${room.roomName} Cleaning`, room.startingPrice)}
                  className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 text-xs font-bold text-white bg-slate-900 hover:bg-emerald-600 active:bg-emerald-700 rounded-xl transition-all cursor-pointer"
                >
                  <span>Book {room.roomName}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
