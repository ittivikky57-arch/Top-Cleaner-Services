import React from 'react';
import { Sparkles, Phone, Mail, MapPin, MessageCircle, Heart, Languages } from 'lucide-react';
import { CONTACT_INFO } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';

interface FooterProps {
  onOpenBooking: (serviceName?: string) => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenBooking, onOpenAdmin }) => {
  const { language, toggleLanguage, t } = useLanguage();

  return (
    <footer className="bg-slate-950 text-slate-400 text-xs border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-emerald-600 flex items-center justify-center text-white font-bold shadow-md shadow-emerald-600/30">
                <Sparkles className="w-5 h-5" />
              </div>
              <span className="text-xl font-black tracking-tight text-white font-display">
                {CONTACT_INFO.brandName}
              </span>
            </div>

            <p className="text-sm font-bold text-emerald-400">
              "{t('brandTagline')}"
            </p>

            <p className="text-slate-400 leading-relaxed max-w-sm font-medium">
              {language === 'hi'
                ? 'प्रमाणित होम क्लीनिंग, डोरस्टेप कार वॉश, पेड़ कटाई और लोडिंग-अनलोडिंग सेवाएं। आधुनिक मशीनों व सुरक्षित इको-केमिकल्स के साथ सेवा उपलब्ध।'
                : 'Certified doorstep deep cleaning, auto detailing, tree care and moving assistance solutions using commercial-grade machines and safe eco chemicals.'}
            </p>

            {/* 1-Touch Language Switcher in Footer */}
            <div className="pt-1">
              <button
                type="button"
                onClick={toggleLanguage}
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-emerald-400 border border-slate-700 text-xs font-bold transition-all cursor-pointer active:scale-95"
              >
                <Languages className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'Switch Website to English' : 'पूरी वेबसाइट हिंदी में बदलें'}</span>
              </button>
            </div>

            <div className="pt-2 flex items-center gap-4 text-xs font-semibold text-slate-300">
              <a
                href={`tel:${CONTACT_INFO.phoneRaw}`}
                className="hover:text-emerald-400 transition-colors flex items-center gap-1.5"
              >
                <Phone className="w-3.5 h-3.5 text-emerald-500" />
                <span>+91 62043 19105</span>
              </a>
              <span className="text-slate-700">|</span>
              <a
                href={`mailto:${CONTACT_INFO.email}`}
                className="hover:text-emerald-400 transition-colors flex items-center gap-1.5"
              >
                <Mail className="w-3.5 h-3.5 text-emerald-500" />
                <span>{CONTACT_INFO.email}</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-white uppercase tracking-wider">
              {language === 'hi' ? 'महत्वपूर्ण लिंक्स' : 'Quick Links'}
            </h4>
            <ul className="space-y-2 font-medium">
              <li><a href="#" className="hover:text-white transition-colors">{language === 'hi' ? 'होम' : 'Home'}</a></li>
              <li><a href="#loading-unloading" className="hover:text-emerald-400 text-white font-bold transition-colors">📦 {t('navLoading')}</a></li>
              <li><a href="#tree-pruning" className="hover:text-emerald-400 text-white font-bold transition-colors">🌳 {t('navTree')}</a></li>
              <li><a href="#car-wash" className="hover:text-emerald-400 text-white font-bold transition-colors">🚗 {t('navCarWash')}</a></li>
              <li><a href="#materials" className="hover:text-white transition-colors">{t('navMaterials')}</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">{t('navServices')} (28)</a></li>
              <li><a href="#full-home" className="hover:text-white transition-colors">{t('navFullHome')}</a></li>
              <li><a href="#pricing" className="hover:text-white transition-colors">{t('navPricing')}</a></li>
              <li><a href="#calculator" className="hover:text-white transition-colors">{t('navCalculator')}</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">{t('navContact')}</a></li>
            </ul>
          </div>

          {/* Popular Services */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-white uppercase tracking-wider">
              {language === 'hi' ? 'प्रमुख सेवाएं' : 'Popular Services'}
            </h4>
            <ul className="space-y-2 font-medium">
              <li>
                <button
                  onClick={() => onOpenBooking('Full Home Deep Cleaning')}
                  className="hover:text-white transition-colors text-left cursor-pointer"
                >
                  {language === 'hi' ? 'पूरा घर डीप क्लीन' : 'Full Home Cleaning'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenBooking('Room Cleaning (Single Room)')}
                  className="hover:text-white transition-colors text-left cursor-pointer"
                >
                  {language === 'hi' ? 'कमरा क्लीनिंग' : 'Room Cleaning'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenBooking('Kitchen Deep Cleaning')}
                  className="hover:text-white transition-colors text-left cursor-pointer"
                >
                  {language === 'hi' ? 'किचन डीप क्लीन' : 'Kitchen Cleaning'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenBooking('Bathroom Deep Cleaning')}
                  className="hover:text-white transition-colors text-left cursor-pointer"
                >
                  {language === 'hi' ? 'बाथरूम डीप क्लीन' : 'Bathroom Cleaning'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenBooking('Sofa Deep Cleaning & Shampoo')}
                  className="hover:text-white transition-colors text-left cursor-pointer"
                >
                  {language === 'hi' ? 'सोफा शैम्पू वॉश' : 'Sofa Cleaning'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenBooking('Tree Felling & Pruning Services')}
                  className="hover:text-white transition-colors text-left cursor-pointer"
                >
                  {language === 'hi' ? 'पेड़ कटाई व छंटाई' : 'Tree Felling & Pruning'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenBooking('Loading & Unloading Helpers')}
                  className="hover:text-white transition-colors text-left cursor-pointer"
                >
                  {language === 'hi' ? 'लोडिंग व शिफ्टिंग हेल्पर्स' : 'Loading & Shifting Helpers'}
                </button>
              </li>
            </ul>
          </div>

          {/* Connect & Social */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-white uppercase tracking-wider">
              {language === 'hi' ? 'संपर्क साधन' : 'Connect With Us'}
            </h4>
            <p className="text-slate-400 font-medium">
              {language === 'hi' ? 'विशेष सहायता या तुरंत बुकिंग के लिए संपर्क करें:' : 'Need assistance or special commercial booking? We are one click away.'}
            </p>
            <div className="flex items-center gap-3 pt-1">
              <a
                href={`https://wa.me/${CONTACT_INFO.whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-emerald-900/60 hover:bg-emerald-600 text-emerald-300 hover:text-white flex items-center justify-center transition-colors shadow-sm"
                title="WhatsApp"
              >
                <MessageCircle className="w-5 h-5" />
              </a>
              <a
                href={`tel:${CONTACT_INFO.phoneRaw}`}
                className="w-10 h-10 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center transition-colors shadow-sm"
                title="Phone"
              >
                <Phone className="w-5 h-5" />
              </a>
              <a
                href={`mailto:${CONTACT_INFO.email}`}
                className="w-10 h-10 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center transition-colors shadow-sm"
                title="Email"
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>

            <div className="pt-3">
              <button
                onClick={onOpenAdmin}
                className="text-[11px] text-slate-500 hover:text-slate-300 font-mono transition-colors cursor-pointer"
              >
                {language === 'hi' ? '🔒 एडमिन कंसोल' : '🔒 Admin Portal'}
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Copyright Bar with 1-Touch Language Badge */}
        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <div>
            © {new Date().getFullYear()} {CONTACT_INFO.brandName}. {language === 'hi' ? 'सर्वाधिकार सुरक्षित।' : 'All rights reserved.'}
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={toggleLanguage}
              className="hover:text-emerald-400 transition-colors font-bold flex items-center gap-1 cursor-pointer"
            >
              <Languages className="w-3 h-3" />
              <span>{language === 'hi' ? 'English Language' : 'हिंदी भाषा'}</span>
            </button>
            <span aria-hidden="true">•</span>
            <a href="#services" className="hover:text-slate-300 transition-colors">{language === 'hi' ? 'सेवाएं' : 'Services'}</a>
            <span aria-hidden="true">•</span>
            <a href="#contact" className="hover:text-slate-300 transition-colors">{language === 'hi' ? 'संपर्क' : 'Contact'}</a>
          </div>
        </div>

      </div>
    </footer>
  );
};
