import React from 'react';
import { ShieldCheck, Sparkles, CheckCircle2, MessageCircle, Calendar, ArrowRight, Star, Languages, Zap } from 'lucide-react';
import { CONTACT_INFO, ASSET_IMAGES } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';
import { LanguageToggleBadge } from './LanguageToggleBadge';

interface HeroSectionProps {
  onOpenBooking: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenBooking }) => {
  const { language, toggleLanguage, t } = useLanguage();

  const whatsappUrl = `https://wa.me/${CONTACT_INFO.whatsappNumber}?text=${encodeURIComponent(
    language === 'hi'
      ? 'नमस्ते PURE CLEANING, मैं ₹100 की छूट वाला पहला बुकिंग ऑफर लेना चाहता हूँ।\n\nमेरा नाम:\nसर्विस:\nइलाका/शहर:'
      : 'Hello PURE CLEANING, I want to claim the ₹100 OFF First Booking offer for my home cleaning or loading service.\n\nMy Name:\nService needed:\nCity / Area:'
  )}`;

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-white to-slate-50 pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-slate-200/60">
      
      {/* 3D Decorative Floating Ambient Glows */}
      <div className="absolute top-12 left-1/4 w-72 h-72 bg-emerald-300/20 rounded-full blur-3xl pointer-events-none -z-0" />
      <div className="absolute top-24 right-10 w-96 h-96 bg-teal-300/15 rounded-full blur-3xl pointer-events-none -z-0" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top 1-Touch Language Bar Banner for Instant Accessibility */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-6 p-2.5 sm:px-4 bg-white/90 backdrop-blur-md rounded-2xl border border-emerald-200 shadow-[0_4px_15px_rgba(16,185,129,0.12)]">
          <div className="flex items-center gap-2 text-xs font-black text-slate-800">
            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <Languages className="w-4 h-4" />
            </span>
            <span>
              {language === 'hi' 
                ? '👆 एक टच में पूरी वेबसाइट हिंदी या इंग्लिश में बदलें' 
                : '👆 One-Touch Bilingual: Instant switch between English & Hindi'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold text-slate-500 hidden sm:inline">
              {language === 'hi' ? 'क्लिक करें:' : 'Click to toggle:'}
            </span>
            <LanguageToggleBadge variant="hero" />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Hero Content */}
          <div className="lg:col-span-7 flex flex-col space-y-6">
            
            {/* Offer Pill */}
            <div className="inline-flex items-center gap-2 self-start bg-emerald-100/90 text-emerald-950 border border-emerald-300 px-3.5 py-1.5 rounded-full text-xs font-extrabold shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-emerald-700 animate-spin" />
              <span>{t('heroPill')}</span>
            </div>

            {/* Headline with 3D Pop Style */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-[1.15] font-display text-balance">
              {language === 'hi' ? (
                <>
                  पाएं <span className="text-emerald-600 underline decoration-emerald-300 decoration-wavy decoration-2">₹100 की सीधी छूट</span> अपनी पहली होम क्लीनिंग पर
                </>
              ) : (
                <>
                  Get <span className="text-emerald-600 underline decoration-emerald-300 decoration-wavy decoration-2">₹100 OFF</span> on Your First Cleaning
                </>
              )}
            </h1>

            {/* Subheadline */}
            <p className="text-base sm:text-lg lg:text-xl font-medium text-slate-600 leading-relaxed max-w-2xl">
              {t('heroSubheadline')}
            </p>

            {/* Trust Bullets with 3D Badges */}
            <div className="flex flex-wrap items-center gap-y-2 gap-x-4 text-xs sm:text-sm font-bold text-slate-700">
              <div className="flex items-center gap-1.5 bg-white/80 border border-slate-200/80 px-3 py-1.5 rounded-xl shadow-2xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{t('verifiedPros')}</span>
              </div>
              <div className="flex items-center gap-1.5 bg-white/80 border border-slate-200/80 px-3 py-1.5 rounded-xl shadow-2xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{t('safeProducts')}</span>
              </div>
              <div className="flex items-center gap-1.5 bg-white/80 border border-slate-200/80 px-3 py-1.5 rounded-xl shadow-2xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{t('transparentPricing')}</span>
              </div>
            </div>

            {/* 3D Tactile CTAs with Realistic Push Depth */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5">
              <button
                type="button"
                onClick={onOpenBooking}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-4 text-sm font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-2xl shadow-[0_6px_0_#047857] hover:shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none transition-all cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>{t('bookCleaningNow')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-4 text-sm font-black text-slate-800 bg-white hover:bg-slate-50 border-2 border-slate-200 rounded-2xl shadow-[0_5px_0_#cbd5e1] hover:shadow-[0_3px_0_#cbd5e1] active:translate-y-1 active:shadow-none transition-all"
              >
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                <span>{t('whatsappUs')}</span>
              </a>
            </div>

            {/* Micro Social Proof */}
            <div className="pt-2 flex items-center gap-4 text-xs text-slate-500 border-t border-slate-200/80">
              <div className="flex items-center gap-1 text-amber-500">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <div>
                <span className="font-extrabold text-slate-900">4.9 / 5</span>{' '}
                <span className="font-semibold text-slate-600">
                  {language === 'hi' ? '(1,400+ घरों में प्रमाणित संतुष्ट काम)' : 'across 2,800+ homes cleaned'}
                </span>
              </div>
            </div>

          </div>

          {/* Right Column: 3D Visual Asset & Floating Offer Badge */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-3xl overflow-hidden shadow-[0_25px_50px_rgba(0,0,0,0.18)] border-2 border-emerald-100 bg-slate-100 group">
              <img
                src={ASSET_IMAGES.hero}
                alt="Professional Indian cleaner in uniform cleaning modern apartment living room with industrial vacuum cleaner"
                referrerPolicy="no-referrer"
                className="w-full h-[360px] sm:h-[420px] lg:h-[480px] object-cover object-center group-hover:scale-103 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />

              {/* Bottom Caption Overlay with Glassmorphism */}
              <div className="absolute bottom-4 left-4 right-4 text-white p-3.5 rounded-2xl bg-slate-900/85 backdrop-blur-md border border-white/15 text-xs shadow-xl">
                <div className="font-extrabold text-sm text-emerald-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span>PURE CLEANING · {language === 'hi' ? 'सत्यापित टीम' : 'Certified Crew'}</span>
                </div>
                <p className="text-slate-300 text-[11px] mt-0.5 leading-snug">
                  {language === 'hi'
                    ? 'औद्योगिक HEPA वैक्यूम, सुरक्षित इको-केमिकल्स और सिंगल डिस्क फ्लोर स्क्रबर्स से लैस।'
                    : 'Equipped with industrial HEPA vacuums, hospital-grade eco disinfectants & rotary scrubbers.'}
                </p>
              </div>
            </div>

            {/* 3D Floating Offer Card */}
            <div 
              onClick={toggleLanguage}
              title="Touch card to toggle language (टच करके भाषा बदलें)"
              className="absolute -top-4 -right-2 sm:-right-4 sm:-top-5 bg-white text-slate-900 rounded-3xl p-4 shadow-[0_15px_30px_rgba(0,0,0,0.18)] border-2 border-emerald-300 max-w-[220px] transform hover:scale-105 active:scale-95 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] uppercase tracking-wider font-black text-emerald-700">
                  {language === 'hi' ? 'पहली बुकिंग ऑफर' : 'First Booking Offer'}
                </span>
                <span className="text-[9px] font-mono bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-bold">
                  {language === 'hi' ? 'ENG / हिंदी' : 'HI / EN'}
                </span>
              </div>
              <div className="text-2xl font-black text-slate-900 font-display mt-0.5">
                ₹100 OFF
              </div>
              <div className="text-[11px] text-slate-600 mt-1 leading-snug">
                {language === 'hi'
                  ? 'होम, सोफा, किचन या लोडिंग पर आज ही लागू करें!'
                  : 'Apply on any home, sofa, or loading service today!'}
              </div>
              <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] font-mono text-emerald-900 font-black bg-emerald-50 px-2.5 py-1 rounded-xl">
                <span>CODE:</span>
                <span className="tracking-widest">FIRST100</span>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
