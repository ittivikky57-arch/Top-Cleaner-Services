import React, { useState, useMemo } from 'react';
import { Calendar, Clock, Home, MapPin, Phone, Sparkles, CheckCircle2, ArrowRight, Languages } from 'lucide-react';
import { INITIAL_SERVICES, TIME_SLOTS, CONTACT_INFO } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';

interface SearchBookingBoxProps {
  onDirectBook: (bookingData: {
    service: string;
    propertyType: string;
    date: string;
    timeSlot: string;
    address: string;
    phone: string;
    estimatedPrice: number;
  }) => void;
}

export const SearchBookingBox: React.FC<SearchBookingBoxProps> = ({ onDirectBook }) => {
  const { language, toggleLanguage, t } = useLanguage();
  const [selectedServiceId, setSelectedServiceId] = useState<string>('full-home-deep');
  const [propertyType, setPropertyType] = useState<string>('2 BHK');
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date(Date.now() + 86400000).toISOString().split('T')[0]
  );
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>(TIME_SLOTS[1]); // 10:00 AM
  const [address, setAddress] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [discountApplied, setDiscountApplied] = useState<boolean>(true);
  const [errorMsg, setErrorMsg] = useState<string>('');

  const selectedService = useMemo(() => {
    return INITIAL_SERVICES.find((s) => s.id === selectedServiceId) || INITIAL_SERVICES[0];
  }, [selectedServiceId]);

  // Dynamic estimated price calculation
  const calculatedPrice = useMemo(() => {
    let base = selectedService.startingPrice;
    
    // Property scale multiplier
    if (selectedService.category === 'full_home') {
      if (propertyType === '1 BHK') base = 999;
      else if (propertyType === '2 BHK') base = 1499;
      else if (propertyType === '3 BHK') base = 1999;
      else if (propertyType === '4 BHK') base = 2499;
      else if (propertyType === 'Bungalow / Villa') base = 3499;
      else if (propertyType === 'Single Room') base = 699;
    } else {
      if (propertyType === '3 BHK' || propertyType === '4 BHK') {
        base = Math.round(base * 1.25);
      } else if (propertyType === 'Bungalow / Villa') {
        base = Math.round(base * 1.5);
      }
    }

    if (discountApplied) {
      base = Math.max(199, base - CONTACT_INFO.firstBookingDiscount);
    }
    return base;
  }, [selectedService, propertyType, discountApplied]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || phone.trim().length < 10) {
      setErrorMsg(language === 'hi' ? 'कृपया सही 10 अंकों का मोबाइल नंबर दर्ज करें।' : 'Please enter a valid 10-digit mobile number.');
      return;
    }
    setErrorMsg('');
    onDirectBook({
      service: selectedService.name,
      propertyType,
      date: selectedDate,
      timeSlot: selectedTimeSlot,
      address: address.trim() || (language === 'hi' ? 'बुकिंग कन्फर्मेशन पर पता दिया जाएगा' : 'Address will be provided on confirmation'),
      phone: phone.trim(),
      estimatedPrice: calculatedPrice
    });
  };

  return (
    <section className="relative -mt-10 lg:-mt-12 z-30 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
      <div className="bg-white rounded-3xl p-6 sm:p-8 lg:p-10 shadow-[0_20px_50px_rgba(0,0,0,0.1),0_10px_25px_rgba(16,185,129,0.15)] border-2 border-emerald-100 relative group transition-all duration-300">
        
        {/* Header line with 1-Touch Language Switcher */}
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-5 mb-5 border-b border-slate-100 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-display">
                {t('bookServiceTitle')}
              </h2>
              {/* 1-Touch Translate badge */}
              <button
                type="button"
                onClick={toggleLanguage}
                title="Touch to switch Hindi / English (टच करके भाषा बदलें)"
                className="ml-2 inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 cursor-pointer transition-all active:scale-95"
              >
                <Languages className="w-3 h-3 text-emerald-600" />
                <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
              </button>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              {t('bookServiceSub')}
            </p>
          </div>

          {/* Dynamic estimated price display */}
          <div className="flex items-center gap-4 bg-emerald-50/90 border border-emerald-200/90 px-4 py-2.5 rounded-2xl shadow-xs">
            <div className="text-left">
              <div className="text-[11px] text-emerald-800 font-bold uppercase tracking-wider">
                {t('estimatedPrice')}
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-slate-900 font-display">
                  ₹{calculatedPrice}
                </span>
                {discountApplied && (
                  <span className="text-xs text-emerald-700 line-through font-bold">
                    ₹{calculatedPrice + CONTACT_INFO.firstBookingDiscount}
                  </span>
                )}
              </div>
            </div>
            <div className="text-[11px] font-black text-emerald-900 bg-white px-2.5 py-1 rounded-xl shadow-2xs border border-emerald-200">
              {t('offApplied')}
            </div>
          </div>
        </div>

        {/* Search & Booking Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            
            {/* Field 1: Select Service */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t('selectService')}</span>
              </label>
              <select
                value={selectedServiceId}
                onChange={(e) => setSelectedServiceId(e.target.value)}
                className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all cursor-pointer"
              >
                {INITIAL_SERVICES.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} (from ₹{s.startingPrice})
                  </option>
                ))}
              </select>
            </div>

            {/* Field 2: Select Property Type */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <Home className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t('selectProperty')}</span>
              </label>
              <select
                value={propertyType}
                onChange={(e) => setPropertyType(e.target.value)}
                className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all cursor-pointer"
              >
                <option value="1 BHK">{language === 'hi' ? '1 BHK फ्लैट' : '1 BHK Apartment'}</option>
                <option value="2 BHK">{language === 'hi' ? '2 BHK फ्लैट' : '2 BHK Apartment'}</option>
                <option value="3 BHK">{language === 'hi' ? '3 BHK फ्लैट' : '3 BHK Apartment'}</option>
                <option value="4 BHK">{language === 'hi' ? '4 BHK फ्लैट' : '4 BHK Apartment'}</option>
                <option value="Bungalow / Villa">{language === 'hi' ? 'बंगला / विला / डुप्लेक्स' : 'Bungalow / Villa / Duplex'}</option>
                <option value="Single Room">{language === 'hi' ? 'एक कमरा (Single Room)' : 'Single Room / Studio'}</option>
                <option value="Commercial / Office">{language === 'hi' ? 'ऑफिस / कमर्शियल दुकान' : 'Office / Commercial Space'}</option>
              </select>
            </div>

            {/* Field 3: Select Date */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t('selectDate')}</span>
              </label>
              <input
                type="date"
                min={new Date().toISOString().split('T')[0]}
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                required
                className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all cursor-pointer"
              />
            </div>

            {/* Field 4: Select Time Slot */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t('selectTime')}</span>
              </label>
              <select
                value={selectedTimeSlot}
                onChange={(e) => setSelectedTimeSlot(e.target.value)}
                className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all cursor-pointer"
              >
                {TIME_SLOTS.map((slot) => (
                  <option key={slot} value={slot}>
                    {slot}
                  </option>
                ))}
              </select>
            </div>

            {/* Field 5: Enter Address */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t('enterAddress')}</span>
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder={language === 'hi' ? 'सोसायटी, फ्लैट नं, सेक्टर या इलाका' : 'Apartment, Society, Sector / Locality'}
                className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all placeholder:text-slate-400"
              />
            </div>

            {/* Field 6: Mobile Number */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t('mobileNumber')}</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-extrabold text-slate-500">
                  +91
                </span>
                <input
                  type="tel"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="62043 19105"
                  required
                  className="w-full h-11 pl-11 pr-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all placeholder:text-slate-400"
                />
              </div>
            </div>

          </div>

          {errorMsg && (
            <div className="text-xs font-bold text-rose-600 bg-rose-50 border border-rose-200 px-3 py-2 rounded-xl">
              {errorMsg}
            </div>
          )}

          {/* Form Submit & Feature Trust Note with 3D Button */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-100">
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                {language === 'hi' 
                  ? 'फिक्स रेट गारंटी · कोई अग्रिम पेमेंट आवश्यक नहीं · काम पूरा होने पर भुगतान करें' 
                  : 'Fixed Price Guarantee · Zero Advance Needed · Pay after work satisfaction'}
              </span>
            </div>

            <button
              type="submit"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 text-sm font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-2xl shadow-[0_5px_0_#047857] hover:shadow-[0_3px_0_#047857] active:translate-y-1 active:shadow-none transition-all cursor-pointer whitespace-nowrap"
            >
              <span>{t('checkPriceBtn')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>

      </div>
    </section>
  );
};
