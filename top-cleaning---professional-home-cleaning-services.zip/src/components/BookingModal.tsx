import React, { useState } from 'react';
import { X, Calendar, Clock, MapPin, Phone, Mail, User, Sparkles, CheckCircle2, MessageCircle, ArrowRight, Languages } from 'lucide-react';
import { TIME_SLOTS, CONTACT_INFO, BookingRecord } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialService?: string;
  initialPrice?: number;
  initialPropertyType?: string;
  initialDate?: string;
  initialTime?: string;
  initialAddress?: string;
  initialPhone?: string;
  onBookingConfirmed: (newBooking: BookingRecord) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  initialService = 'Full Home Deep Cleaning',
  initialPrice = 1499,
  initialPropertyType = '2 BHK',
  initialDate,
  initialTime,
  initialAddress = '',
  initialPhone = '',
  onBookingConfirmed,
}) => {
  const { language, toggleLanguage, t } = useLanguage();
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState(initialPhone);
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState(initialAddress);
  const [serviceName, setServiceName] = useState(initialService);
  const [propertyType, setPropertyType] = useState(initialPropertyType);
  const [bookingDate, setBookingDate] = useState(
    initialDate || new Date(Date.now() + 86400000).toISOString().split('T')[0]
  );
  const [selectedTimeSlot, setSelectedTimeSlot] = useState(initialTime || TIME_SLOTS[1]);
  const [instructions, setInstructions] = useState('');
  const [confirmedBooking, setConfirmedBooking] = useState<BookingRecord | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      setErrorMsg(language === 'hi' ? 'कृपया अपना पूरा नाम दर्ज करें।' : 'Please enter your full name.');
      return;
    }
    if (!phone || phone.trim().length < 10) {
      setErrorMsg(language === 'hi' ? 'कृपया सही 10-अंकों का मोबाइल नंबर दर्ज करें।' : 'Please enter a valid 10-digit mobile number.');
      return;
    }
    if (!address.trim()) {
      setErrorMsg(language === 'hi' ? 'कृपया पूरा पता दर्ज करें।' : 'Please enter your complete address.');
      return;
    }

    const newRecord: BookingRecord = {
      id: `TC-${Math.floor(1000 + Math.random() * 9000)}`,
      customerName: fullName.trim(),
      phone: phone.trim(),
      email: email.trim() || 'ittivikky57@gmail.com',
      service: serviceName,
      propertyType,
      date: bookingDate,
      timeSlot: selectedTimeSlot,
      address: address.trim(),
      price: Math.max(199, initialPrice),
      status: 'Confirmed',
      createdAt: new Date().toLocaleString(),
      instructions: instructions.trim(),
    };

    onBookingConfirmed(newRecord);
    setConfirmedBooking(newRecord);
  };

  const getWhatsAppBookingUrl = (record: BookingRecord) => {
    const text = language === 'hi'
      ? `नमस्ते PURE CLEANING, मैंने बुकिंग कन्फर्म कर ली है #${record.id}।\n\nग्राहक का नाम: ${record.customerName}\nमोबाइल: ${record.phone}\nसर्विस: ${record.service}\nविवरण: ${record.propertyType}\nतारीख: ${record.date}\nसमय: ${record.timeSlot}\nपता: ${record.address}\nफाइनल रेट: ₹${record.price}\n\nकृपया टीम असाइन करें।`
      : `Hello PURE CLEANING, I have confirmed my booking #${record.id}.\n\nName: ${record.customerName}\nPhone: ${record.phone}\nService: ${record.service}\nDetails/Property: ${record.propertyType}\nDate: ${record.date}\nTime: ${record.timeSlot}\nAddress: ${record.address}\nPrice: ₹${record.price}\n\nPlease assign the service team.`;
    return `https://wa.me/${CONTACT_INFO.whatsappNumber}?text=${encodeURIComponent(text)}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border-2 border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Top Header with 1-Touch Translate */}
        <div className="sticky top-0 bg-white/95 backdrop-blur-md px-6 py-4 border-b border-slate-100 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-sm">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-slate-900 text-base font-display">
                {confirmedBooking 
                  ? (language === 'hi' ? 'बुकिंग कन्फर्म हो गई!' : 'Booking Confirmed!') 
                  : (language === 'hi' ? 'क्लीनिंग व लोडिंग सर्विस बुकिंग' : 'Book Cleaning & Loading Service')}
              </h3>
              <p className="text-[11px] text-slate-500 font-bold">
                PURE CLEANING · {language === 'hi' ? 'वेरीफाइड डोरस्टेप सेवाएं' : 'Verified Doorstep Services'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleLanguage}
              title="Touch to switch Hindi / English"
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-300 cursor-pointer active:scale-95"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Confirmation State Screen */}
        {confirmedBooking ? (
          <div className="p-6 sm:p-8 text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md animate-bounce">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="text-xs uppercase font-black tracking-widest text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                Booking ID: {confirmedBooking.id}
              </span>
              <h4 className="text-2xl font-black text-slate-900 font-display mt-3">
                {language === 'hi' ? `धन्यवाद, ${confirmedBooking.customerName}!` : `Thank You, ${confirmedBooking.customerName}!`}
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-md mx-auto font-medium">
                {language === 'hi'
                  ? 'आपकी बुकिंग सफलतापूर्वक दर्ज हो गई है। हमारी टीम निर्धारित समय पर मशीनें और सामग्री लेकर आपके पते पर पहुँचेगी।'
                  : 'Your cleaning appointment has been registered. Our technician team will arrive with industrial equipment at the scheduled slot.'}
              </p>
            </div>

            {/* Booking Details Card */}
            <div className="bg-slate-50 rounded-2xl p-4 sm:p-5 border border-slate-200 text-left text-xs sm:text-sm space-y-2.5">
              <div className="flex justify-between pb-2 border-b border-slate-200">
                <span className="text-slate-500 font-medium">{language === 'hi' ? 'सर्विस:' : 'Service:'}</span>
                <span className="font-bold text-slate-900">{confirmedBooking.service}</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-slate-200">
                <span className="text-slate-500 font-medium">{language === 'hi' ? 'तारीख व समय:' : 'Date & Slot:'}</span>
                <span className="font-bold text-slate-900 font-mono">
                  {confirmedBooking.date} at {confirmedBooking.timeSlot}
                </span>
              </div>
              <div className="flex justify-between pb-2 border-b border-slate-200">
                <span className="text-slate-500 font-medium">{language === 'hi' ? 'प्रॉपर्टी विवरण:' : 'Property:'}</span>
                <span className="font-bold text-slate-900">{confirmedBooking.propertyType}</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-slate-200">
                <span className="text-slate-500 font-medium">{language === 'hi' ? 'पता:' : 'Address:'}</span>
                <span className="font-semibold text-slate-800 text-right max-w-[240px]">
                  {confirmedBooking.address}
                </span>
              </div>
              <div className="flex justify-between pt-1 text-emerald-800 font-black text-base">
                <span>{language === 'hi' ? 'कुल राशि:' : 'Total Amount:'}</span>
                <span>₹{confirmedBooking.price}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3 pt-2">
              <a
                href={getWhatsAppBookingUrl(confirmedBooking)}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-4 text-xs font-black text-emerald-950 bg-emerald-100 hover:bg-emerald-200 border-2 border-emerald-300 rounded-2xl transition-all shadow-sm"
              >
                <MessageCircle className="w-4 h-4 text-emerald-700" />
                <span>{language === 'hi' ? 'व्हाट्सएप पर बुकिंग स्लिप भेजें' : 'Send Booking Details on WhatsApp'}</span>
              </a>

              <button
                onClick={onClose}
                className="w-full py-3 px-4 text-xs font-bold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
              >
                {language === 'hi' ? 'बंद करें और वेबसाइट पर लौटें' : 'Close & Return to Website'}
              </button>
            </div>
          </div>
        ) : (
          /* Form Entry Screen */
          <form onSubmit={handleConfirm} className="p-6 sm:p-7 space-y-5">
            {/* Selected Service Banner */}
            <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-black text-emerald-800 tracking-wide">
                  {language === 'hi' ? 'चुनी गई सर्विस' : 'Selected Service'}
                </span>
                <div className="font-black text-sm text-slate-900">{serviceName}</div>
                <div className="text-[11px] text-slate-500 font-semibold">{propertyType}</div>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400 font-bold">{language === 'hi' ? 'फाइनल रेट' : 'Total Price'}</span>
                <div className="text-2xl font-black text-slate-900 font-display">
                  ₹{initialPrice}
                </div>
              </div>
            </div>

            {/* Date & Time Slot Selection */}
            <div>
              <label className="block text-xs font-black text-slate-800 mb-2 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                <span>{language === 'hi' ? 'तारीख व पसंदीदा टाइम स्लॉट चुनें' : 'Select Preferred Date & Available Time Slot'}</span>
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                <input
                  type="date"
                  min={new Date().toISOString().split('T')[0]}
                  value={bookingDate}
                  onChange={(e) => setBookingDate(e.target.value)}
                  required
                  className="h-11 px-3 text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />

                <select
                  value={selectedTimeSlot}
                  onChange={(e) => setSelectedTimeSlot(e.target.value)}
                  className="h-11 px-3 text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                >
                  {TIME_SLOTS.map((slot) => (
                    <option key={slot} value={slot}>
                      {slot}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Customer Details */}
            <div className="space-y-3.5">
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{language === 'hi' ? 'आपका पूरा नाम' : 'Your Full Name'} *</span>
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder={language === 'hi' ? 'उदा: विकास शर्मा' : 'e.g. Vikas Sharma'}
                  required
                  className="w-full h-11 px-3.5 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{language === 'hi' ? 'मोबाइल नंबर' : 'Mobile Number'} *</span>
                  </label>
                  <input
                    type="tel"
                    maxLength={10}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                    placeholder="62043 19105"
                    required
                    className="w-full h-11 px-3.5 text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{language === 'hi' ? 'ईमेल (वैकल्पिक)' : 'Email (Optional)'}</span>
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="user@example.com"
                    className="w-full h-11 px-3.5 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 mb-1 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{language === 'hi' ? 'सफाई / लोडिंग का पूरा पता' : 'Complete Service Address'} *</span>
                </label>
                <textarea
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder={language === 'hi' ? 'सोसायटी / अपार्टमेंट नाम, फ्लैट नंबर, फ्लोर, लैंडमार्क' : 'Society name, flat/house number, floor, landmark'}
                  required
                  className="w-full p-3 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  {language === 'hi' ? 'कोई विशेष निर्देश (वैकल्पिक):' : 'Special Instructions (Optional):'}
                </label>
                <input
                  type="text"
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  placeholder={language === 'hi' ? 'उदा: भारी सोफा 2nd फ्लोर ले जाना है / पानी कनेक्शन उपलब्ध है' : 'e.g. Sofa has pet stains, need extra care on marble floor'}
                  className="w-full h-10 px-3.5 text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            {errorMsg && (
              <div className="p-3 text-xs font-bold text-rose-600 bg-rose-50 border border-rose-200 rounded-xl">
                {errorMsg}
              </div>
            )}

            {/* 3D Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 py-4 px-6 text-sm font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-2xl shadow-[0_5px_0_#047857] active:translate-y-1 active:shadow-none transition-all cursor-pointer"
              >
                <span>{language === 'hi' ? `बुकिंग कन्फर्म करें (₹${initialPrice})` : `Confirm Booking Appointment (₹${initialPrice})`}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="text-center mt-2.5 text-[11px] text-slate-400 font-medium">
                {language === 'hi'
                  ? '✓ पे एट डोरस्टेप: काम खत्म होने पर कैश या ऑनलाइन UPI से भुगतान करें।'
                  : '✓ Pay after completion: No online card or prepay required today.'}
              </div>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
