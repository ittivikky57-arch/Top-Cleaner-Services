import React from 'react';
import { Tag, Sparkles, CheckCircle2, ArrowRight, ShieldCheck, HelpCircle, Languages } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { ThreeDCard } from './ThreeDCard';

interface PricingSectionProps {
  onBookService: (serviceName: string, price: number) => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onBookService }) => {
  const { language, toggleLanguage, t } = useLanguage();

  const pricingCards = [
    {
      title: language === 'hi' ? 'बाथरूम डीप क्लीन' : 'Bathroom Deep Clean',
      price: 299,
      unit: language === 'hi' ? 'प्रति बाथरूम' : 'per bathroom',
      popular: false,
      features: language === 'hi'
        ? ['एसिड-फ्री डीस्केलिंग', 'शीशा व नल चमक', 'कमोड व बेसिन सैनिटाइजेशन', 'फर्श स्क्रब व दुर्गंध मुक्ति']
        : ['Acid-free descaling', 'Mirror & glass buffing', 'Toilet & basin sanitization', 'Floor scrub & deodorization'],
      highlight: language === 'hi' ? 'खारे पानी के दागों के लिए बेस्ट' : 'Best for hard water stains'
    },
    {
      title: language === 'hi' ? 'कमरा क्लीनिंग (Single Room)' : 'Room Cleaning',
      price: 399,
      unit: language === 'hi' ? 'प्रति कमरा' : 'per room',
      popular: false,
      features: language === 'hi'
        ? ['बेड के नीचे वैक्यूमिंग', 'वार्डरोब बाहरी सफाई', 'पंखे व ट्यूबलाइट डस्टिंग', 'डिसइन्फेक्टेंट पोछा']
        : ['Under-bed dust extraction', 'Wardrobe exterior wipe', 'Fan & light de-dusting', 'Disinfectant floor scrub'],
      highlight: language === 'hi' ? 'तेज 45-60 मिनट में पूरा' : 'Fast 1-hour turnaround'
    },
    {
      title: language === 'hi' ? 'सोफा डीप शैम्पू वॉश' : 'Sofa Deep Shampoo',
      price: 399,
      unit: language === 'hi' ? '3-सीटर ₹699 से शुरू' : 'per seat / 3-seater from ₹699',
      popular: true,
      features: language === 'hi'
        ? ['मशीन शैम्पू एक्सट्रैक्शन', 'चाय व कॉफी के दाग हटाना', 'त्वरित ड्राई वैक्यूम', 'ताजा खूशबू व सॉफ्ट फैब्रिक']
        : ['Extraction shampooing', 'Tea & coffee stain lift', 'Foam drying suction', 'Fabric aroma refresh'],
      highlight: language === 'hi' ? 'सबसे ज्यादा बुक की जाने वाली सर्विस' : 'Most booked individual service'
    },
    {
      title: language === 'hi' ? 'कारपेट व दरी शैम्पू' : 'Carpet & Rug Cleaning',
      price: 399,
      unit: language === 'hi' ? 'मीडियम साइज कारपेट' : 'medium rug',
      popular: false,
      features: language === 'hi'
        ? ['हाई-पावर वैक्यूमिंग', 'गहराई से मैल निकालना', 'एंटी-एलर्जी सैनिटाइजिंग', 'धागों के लिए 100% सुरक्षित']
        : ['High-power beat vacuum', 'Deep dirt slurry extraction', 'Anti-allergen sanitizing', 'Safe on delicate threads'],
      highlight: language === 'hi' ? 'पुराने रंग फिर से चमकाए' : 'Brings faded colors back'
    },
    {
      title: language === 'hi' ? 'गद्दे सैनिटाइजेशन (Mattress)' : 'Mattress Sanitization',
      price: 399,
      unit: language === 'hi' ? 'सिंगल / डबल ₹599 से' : 'single / double from ₹599',
      popular: false,
      features: language === 'hi'
        ? ['UV-C डस्ट माइट खात्मा', 'पसीने के दागों का इलाज', 'ड्राई स्टीम सैनिटाइजेशन', 'कोई केमिकल गीलापन नहीं']
        : ['UV-C dust mite kill', 'Sweat mark treatment', 'Dry steam sanitization', 'Zero chemical dampness'],
      highlight: language === 'hi' ? 'एलर्जी से राहत प्रमाणित' : 'Allergy relief certified'
    },
    {
      title: language === 'hi' ? 'किचन डीप क्लीनिंग' : 'Kitchen Deep Clean',
      price: 499,
      unit: language === 'hi' ? 'फुल मॉड्यूलर किचन' : 'complete modular kitchen',
      popular: true,
      features: language === 'hi'
        ? ['चिमनी व एग्जॉस्ट डिग्रेस', 'स्टोव व बर्नर कार्बन रिमूवल', 'टाइल्स व सिंक चमक', 'कैबिनेट बाहरी ऑयल रिमूवल']
        : ['Chimney & exhaust degrease', 'Stove & burner carbon strip', 'Tile wall & sink polish', 'Cabinet oil removal'],
      highlight: language === 'hi' ? 'सारे चिपचिपे तेल का खात्मा' : 'Heavy oil & grease specialist'
    },
    {
      title: language === 'hi' ? '1 BHK फुल डीप क्लीन' : '1 BHK Full Home Deep',
      price: 999,
      unit: language === 'hi' ? 'पूरा फ्लैट' : 'full apartment',
      popular: false,
      features: language === 'hi'
        ? ['सभी कमरे व बालकनी', 'बाथरूम डीप स्क्रब', 'किचन डिग्रेसिंग', 'मशीन फ्लोर बफिंग']
        : ['All rooms & balcony', 'Bathroom lime descaled', 'Kitchen platform degreased', 'Floor wet scrubbed'],
      highlight: language === 'hi' ? 'बेस्ट बजट फुल होम पैकेज' : 'Best budget full home'
    },
    {
      title: language === 'hi' ? '2 BHK फुल डीप क्लीन' : '2 BHK Full Home Deep',
      price: 1499,
      unit: language === 'hi' ? 'पूरा फ्लैट' : 'full apartment',
      popular: true,
      features: language === 'hi'
        ? ['3-4 स्किल्ड प्रोफेशनल्स', '2 बाथरूम + किचन + 2 बेडरूम', 'सोफा व पंखे वैक्यूम', 'मशीन टाइल स्क्रबिंग']
        : ['3-4 skilled technicians', '2 Baths + Kitchen + 2 Beds', 'Sofa & fans vacuumed', 'Machine tile scrubbing'],
      highlight: language === 'hi' ? 'हमारा टॉप सेलिंग पैकेज' : 'Top seller package'
    }
  ];

  return (
    <section id="pricing" className="py-16 sm:py-24 bg-slate-50 border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with 1-Touch Translate */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100/80 border border-emerald-300 px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-3 shadow-2xs">
            <Tag className="w-3.5 h-3.5 text-emerald-700" />
            <span>{language === 'hi' ? '3D पारदर्शी रेट लिस्ट' : 'Honest & Transparent Rates'}</span>
          </div>

          <div className="flex items-center justify-center gap-3">
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight font-display text-balance">
              {t('pricingTitle')}
            </h2>
            <button
              type="button"
              onClick={toggleLanguage}
              title="Touch to switch language (टच करके भाषा बदलें)"
              className="inline-flex items-center gap-1 px-3 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border-2 border-emerald-300 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
            </button>
          </div>

          <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-xl mx-auto leading-relaxed">
            {t('pricingSub')}
          </p>
        </div>

        {/* 8 Pricing Cards Grid with 3D Perspective */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {pricingCards.map((card, idx) => (
            <ThreeDCard key={idx} allowTouchTranslate={true}>
              <div
                className={`bg-white rounded-3xl p-6 border-2 transition-all flex flex-col justify-between h-full relative ${
                  card.popular
                    ? 'border-emerald-500 shadow-md ring-2 ring-emerald-500/20'
                    : 'border-slate-200 hover:border-slate-300 shadow-xs'
                }`}
              >
                {card.popular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-emerald-600 text-white text-[10px] font-black uppercase px-3 py-1 rounded-full shadow-md tracking-wider">
                    {language === 'hi' ? 'लोकप्रिय' : 'Most Popular'}
                  </span>
                )}

                <div>
                  <h3 className="text-base font-black text-slate-900 font-display">
                    {card.title}
                  </h3>

                  <span className="inline-block text-[11px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-lg mt-1.5">
                    {card.highlight}
                  </span>

                  {/* Price Tag with 3D Pop */}
                  <div className="mt-4 pb-4 border-b border-slate-100">
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">
                      {language === 'hi' ? 'शुरुआती रेट' : 'Starting From'}
                    </span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="text-3xl font-black text-slate-900 font-display">
                        ₹{card.price}
                      </span>
                      <span className="text-xs text-slate-500 font-medium">
                        / {card.unit}
                      </span>
                    </div>
                  </div>

                  {/* Features List */}
                  <ul className="mt-4 space-y-2 text-xs text-slate-600">
                    {card.features.map((feat, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-1.5 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* 3D Action Button */}
                <div className="mt-6 pt-4 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => onBookService(card.title, card.price)}
                    className={`w-full inline-flex items-center justify-center gap-1.5 py-3 px-4 text-xs font-black rounded-2xl transition-all cursor-pointer ${
                      card.popular
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-800 active:scale-95'
                    }`}
                  >
                    <span>{t('bookNow')} (₹{card.price})</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

              </div>
            </ThreeDCard>
          ))}
        </div>

        {/* Pricing Trust Footer */}
        <div className="mt-12 bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              <strong>{language === 'hi' ? '100% पारदर्शी कोटेशन:' : 'Zero Surprise Upcharges:'}</strong>{' '}
              {language === 'hi'
                ? 'कोई छिपा हुआ टैक्स या विजिटिंग चार्ज नहीं। सभी इक्विपमेंट व केमिकल्स रेट में शामिल हैं।'
                : 'All cleaning chemicals, machinery, and disposable gear are included in the price.'}
            </span>
          </div>
          <div className="text-emerald-700 font-black">
            {language === 'hi' ? 'जीएसटी बिलिंग उपलब्ध' : 'GST Invoicing Available For Businesses'}
          </div>
        </div>

      </div>
    </section>
  );
};
