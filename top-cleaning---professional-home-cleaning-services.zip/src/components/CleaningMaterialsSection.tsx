import React from 'react';
import { Droplets, ShieldCheck, Sparkles, CheckCircle2, Leaf, Heart, AlertTriangle, Languages } from 'lucide-react';
import { CLEANING_MATERIALS, ASSET_IMAGES } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';
import { ThreeDCard } from './ThreeDCard';

export const CleaningMaterialsSection: React.FC = () => {
  const { language, toggleLanguage, t } = useLanguage();

  return (
    <section id="materials" className="py-16 sm:py-24 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with 1-Touch Translate */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100/80 border border-emerald-300 px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-3 shadow-2xs">
            <Leaf className="w-3.5 h-3.5 text-emerald-600" />
            <span>{language === 'hi' ? '3D सुरक्षित क्लीनिंग केमिकल्स व सामग्री' : 'Safe Chemistry & Hygiene'}</span>
          </div>

          <div className="flex items-center justify-center gap-3">
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight font-display text-balance">
              {t('materialsTitle')}
            </h2>
            <button
              type="button"
              onClick={toggleLanguage}
              title="Touch to switch language (टच करके भाषा बदलें)"
              className="inline-flex items-center gap-1 px-3 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border-2 border-emerald-300 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
            </button>
          </div>

          <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-2xl mx-auto leading-relaxed">
            {t('materialsSub')}
          </p>
        </div>

        {/* 3D Visual Hero Banner */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-slate-50 rounded-3xl p-6 sm:p-8 lg:p-10 border-2 border-slate-200 mb-12 shadow-[0_20px_45px_rgba(0,0,0,0.06)]">
          
          {/* Left Column: Photorealistic Materials Image */}
          <div className="lg:col-span-6 relative">
            <div className="rounded-3xl overflow-hidden shadow-2xl border-2 border-slate-200 bg-slate-200 group">
              <img
                src={ASSET_IMAGES.cleaningMaterials}
                alt="Professional organized display of premium eco-friendly cleaning supplies and color-coded microfiber towels"
                referrerPolicy="no-referrer"
                className="w-full h-[320px] sm:h-[380px] object-cover object-center group-hover:scale-104 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />

              <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md p-3.5 rounded-2xl border border-slate-200 text-xs text-slate-800 shadow-xl">
                <div className="font-black text-emerald-800 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>{language === 'hi' ? '100% एसिड-फ्री और बच्चों के लिए सुरक्षित' : '100% Acid-Free & Eco Surfactant Guarantee'}</span>
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5 font-medium">
                  {language === 'hi'
                    ? 'धुएं या हानिकारक गंध से मुक्त। नवजात शिशुओं, बुजुर्गों व इनडोर पालतू जानवरों के लिए पूरी तरह सुरक्षित।'
                    : 'Zero noxious choking fumes · Safe around newborn babies, elder parents & indoor pets.'}
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: 4 Safety Pillars */}
          <div className="lg:col-span-6 space-y-3.5">
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-2.5 mb-1">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs shrink-0">
                  01
                </div>
                <h4 className="text-sm font-black text-slate-900">
                  {language === 'hi' ? 'कलर-कोडेड माइक्रोफाइबर टॉवल प्रणाली' : 'Color-Coded Microfiber Towels'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed pl-10.5 font-medium">
                {language === 'hi'
                  ? 'लाल तौलिया केवल बाथरूम कमोड के लिए, पीला किचन काउंटर के लिए, और नीला बेडरूम फर्नीचर के लिए। क्रॉस-कंटैमिनेशन 0% रहता है।'
                  : 'Red towels exclusively for toilet fixtures, yellow for food-prep kitchens, and blue for living & bedroom surfaces.'}
              </p>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-2.5 mb-1">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs shrink-0">
                  02
                </div>
                <h4 className="text-sm font-black text-slate-900">
                  {language === 'hi' ? 'फूड-ग्रेड किचन डिग्रेसर' : 'Food-Grade Kitchen Degreasers'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed pl-10.5 font-medium">
                {language === 'hi'
                  ? 'सिट्रस और एंजाइम आधारित फॉर्मूला जो चिमनी और गैस चूल्हे से चिपचिपा तेल पिघला देता है बिना किसी जहरीले धुएं के।'
                  : 'Citrus & plant-based degreasers that dissolve sticky cooking grease from chimney hoods and gas stoves.'}
              </p>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-2.5 mb-1">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs shrink-0">
                  03
                </div>
                <h4 className="text-sm font-black text-slate-900">
                  {language === 'hi' ? 'नॉन-कोरोसिव टाइल व क्रोम डीस्केलर' : 'Non-Corrosive Hard Water Descalers'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed pl-10.5 font-medium">
                {language === 'hi'
                  ? 'नलों की क्रोम पॉलिश और टाइलों के ग्राउट को नुकसान पहुँचाए बिना खारे पानी के सफेद जिद्दी दाग हटाता है।'
                  : 'Safely removes stubborn white mineral scale from black tiles and faucets without corroding the chrome finish.'}
              </p>
            </div>
          </div>

        </div>

        {/* 6 Cleaning Chemicals Product Cards with 3D Perspective */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CLEANING_MATERIALS.map((mat) => (
            <ThreeDCard key={mat.id} allowTouchTranslate={true}>
              <div className="bg-white rounded-3xl p-6 border-2 border-slate-200 hover:border-emerald-400 shadow-sm flex flex-col justify-between h-full transition-all">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                      {mat.category}
                    </span>
                    <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-full">
                      {mat.safetyStandard}
                    </span>
                  </div>

                  <h3 className="text-base font-black text-slate-900 mb-1.5">
                    {mat.name}
                  </h3>

                  <p className="text-xs text-slate-500 mb-4 leading-relaxed font-medium">
                    {mat.purpose}
                  </p>

                  <div className="space-y-1.5 border-t border-slate-100 pt-3">
                    {mat.features.map((feat, i) => (
                      <div key={i} className="flex items-center gap-1.5 text-xs text-slate-700">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-bold">
                  <span>{language === 'hi' ? 'सुरक्षित फॉर्मूला' : 'Certified Safe Formulation'}</span>
                  <span className="text-emerald-700 font-black">✓ PURE CLEANING Standard</span>
                </div>
              </div>
            </ThreeDCard>
          ))}
        </div>

      </div>
    </section>
  );
};
