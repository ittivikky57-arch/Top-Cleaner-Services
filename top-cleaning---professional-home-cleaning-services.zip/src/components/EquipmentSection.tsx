import React, { useState } from 'react';
import { Wrench, Sparkles, ShieldCheck, Zap, Droplets, CheckCircle2, Eye, X, ZoomIn, Languages } from 'lucide-react';
import { PROFESSIONAL_EQUIPMENT, EquipmentItem } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';
import { ThreeDCard } from './ThreeDCard';

export const EquipmentSection: React.FC = () => {
  const { language, toggleLanguage, t } = useLanguage();
  const [activeModalImg, setActiveModalImg] = useState<{ name: string; img: string; desc: string; specs: string } | null>(null);

  const mainMachines = PROFESSIONAL_EQUIPMENT.slice(0, 4);
  const handTools = PROFESSIONAL_EQUIPMENT.slice(4);

  return (
    <section id="equipment" className="py-16 sm:py-24 bg-slate-950 text-white border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with 1-Touch Translate */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-800 px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-2">
            <Wrench className="w-3.5 h-3.5" />
            <span>{language === 'hi' ? '3D मशीनें एवं सफाई के औज़ार' : 'Commercial Machinery & Tools (औज़ार)'}</span>
          </div>

          <div className="flex items-center justify-center gap-3">
            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight font-display text-balance">
              {t('equipmentTitle')}
            </h2>
            <button
              type="button"
              onClick={toggleLanguage}
              title="Touch to switch language (टच करके भाषा बदलें)"
              className="inline-flex items-center gap-1 px-3 py-1 bg-slate-900 hover:bg-slate-800 text-emerald-400 border border-slate-700 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
            >
              <Languages className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
            </button>
          </div>

          <p className="text-base sm:text-lg font-bold text-emerald-300 mt-2">
            {t('equipmentSub')}
          </p>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl mx-auto">
            {language === 'hi'
              ? 'PURE CLEANING साधारण झाड़ू के बजाय औद्योगिक सिंगल डिस्क स्क्रबर, वेट-ड्राई एक्सट्रैक्शन वैक्यूम, हाई प्रेशर जेट व स्टीम मशीनों का उपयोग करता है।'
              : 'PURE CLEANING utilizes commercial-grade electric scrubbers, wet extraction vacuums, high-pressure washers, and steam sanitizers for spotless deep cleaning.'}
          </p>
        </div>

        {/* Primary 4 Heavy-Duty Machines with 3D Card Elevation & Images */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {mainMachines.map((eq) => (
            <ThreeDCard key={eq.id} allowTouchTranslate={true}>
              <div className="bg-slate-900 rounded-3xl overflow-hidden border-2 border-slate-800 hover:border-emerald-500 shadow-2xl transition-all duration-300 flex flex-col justify-between h-full">
                <div>
                  {/* Equipment Real Tool Image Slot */}
                  <div 
                    onClick={() => setActiveModalImg({ name: eq.name, img: eq.image, desc: eq.description, specs: eq.specs })}
                    className="relative h-60 w-full overflow-hidden bg-slate-800 cursor-pointer group"
                  >
                    <img
                      src={eq.image}
                      alt={eq.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent pointer-events-none" />

                    {/* Tool category tag */}
                    <div className="absolute top-3 left-3 bg-slate-950/85 backdrop-blur-md px-2.5 py-1 rounded-lg border border-slate-700 text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                      {eq.category}
                    </div>

                    {/* Zoom indicator */}
                    <div className="absolute top-3 right-3 p-1.5 rounded-lg bg-slate-900/80 group-hover:bg-emerald-600 text-slate-300 group-hover:text-white transition-colors">
                      <ZoomIn className="w-3.5 h-3.5" />
                    </div>

                    <div className="absolute bottom-2.5 left-3 right-3">
                      <span className="text-[11px] text-emerald-300 font-mono font-bold block bg-slate-950/80 px-2 py-0.5 rounded border border-slate-800/80 w-fit">
                        {eq.specs}
                      </span>
                    </div>
                  </div>

                  {/* Tool Card Info */}
                  <div className="p-4">
                    <h3 className="text-base font-black text-white group-hover:text-emerald-400 transition-colors">
                      {eq.name}
                    </h3>

                    <div className="mt-3 pt-3 border-t border-slate-800/90 flex items-start gap-1.5 text-xs text-emerald-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{eq.benefit}</span>
                    </div>
                  </div>
                </div>

                {/* 3D Action Button */}
                <div className="p-4 pt-0">
                  <button
                    type="button"
                    onClick={() => setActiveModalImg({ name: eq.name, img: eq.image, desc: eq.description, specs: eq.specs })}
                    className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                  >
                    <Eye className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{language === 'hi' ? 'फोटो व मशीन डिटेल देखें' : 'View Machine Image & Specs'}</span>
                  </button>
                </div>

              </div>
            </ThreeDCard>
          ))}
        </div>

        {/* Handheld Tools & Cleaning Gear (औज़ार) Grid with 3D Styling */}
        <div className="bg-slate-900/80 rounded-3xl p-6 sm:p-8 border-2 border-slate-800 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
            <div>
              <h3 className="text-lg font-black text-white font-display flex items-center gap-2">
                <Wrench className="w-4 h-4 text-emerald-400" />
                <span>{language === 'hi' ? 'स्पेशलाइज्ड हैंड टूल्स और सुरक्षा गियर (सफाई के औज़ार)' : 'Specialized Hand Tools & Safety Gear (सफाई के औज़ार)'}</span>
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'hi'
                  ? 'मशीनों के साथ उपयोग किए जाने वाले जर्मन स्क्वीजी, माइक्रोफाइबर किट और पीपीई सुरक्षा किट।'
                  : 'Precision tools used alongside heavy machines for delicate corners and surfaces.'}
              </p>
            </div>
            <span className="text-xs font-black text-emerald-400 bg-emerald-950/80 border border-emerald-800 px-3 py-1 rounded-full w-fit">
              {language === 'hi' ? 'हॉस्पिटल ग्रेड PPE शामिल' : 'Hospital Standard PPE Included'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {handTools.map((tool) => (
              <div
                key={tool.id}
                className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                      {tool.category}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {tool.specs}
                    </span>
                  </div>
                  <h4 className="text-sm font-black text-white mb-1.5">
                    {tool.name}
                  </h4>
                  <p className="text-xs text-slate-400 leading-relaxed font-normal">
                    {tool.description}
                  </p>
                </div>
                <div className="mt-3 pt-2 border-t border-slate-800/80 text-[11px] text-emerald-400 flex items-center gap-1 font-bold">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                  <span>{tool.benefit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Full Image Preview Modal */}
        {activeModalImg && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
              <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white font-display">
                    {activeModalImg.name}
                  </h3>
                  <span className="text-xs text-emerald-400 font-mono">
                    {activeModalImg.specs}
                  </span>
                </div>
                <button
                  onClick={() => setActiveModalImg(null)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="h-72 sm:h-80 w-full overflow-hidden bg-slate-950">
                <img
                  src={activeModalImg.img}
                  alt={activeModalImg.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center"
                />
              </div>

              <div className="p-5">
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {activeModalImg.desc}
                </p>
                <div className="mt-4 flex justify-end">
                  <button
                    onClick={() => setActiveModalImg(null)}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-xl transition-colors cursor-pointer"
                  >
                    {language === 'hi' ? 'बंद करें' : 'Close Preview'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
