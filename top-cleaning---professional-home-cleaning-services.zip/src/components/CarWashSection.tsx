import React, { useState } from 'react';
import { Car, Clock, Sparkles, ShieldCheck, CheckCircle2, ArrowRight, Zap, Droplets, Wrench, MessageCircle, Languages } from 'lucide-react';
import { CAR_WASH_PACKAGES, CarWashPackage, ASSET_IMAGES, CONTACT_INFO } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';
import { ThreeDCard } from './ThreeDCard';

interface CarWashSectionProps {
  onBookCarWash: (packageName: string, price: number, vehicleType: string) => void;
}

export const CarWashSection: React.FC<CarWashSectionProps> = ({ onBookCarWash }) => {
  const { language, toggleLanguage, t } = useLanguage();
  const [selectedVehicleType, setSelectedVehicleType] = useState<'hatchback' | 'sedan' | 'csuv' | 'suvLuxury'>('sedan');

  const vehicleTypeLabels = {
    hatchback: { 
      name: language === 'hi' ? 'हैचबैक' : 'Hatchback', 
      example: 'Swift, i20, Tiago, WagonR, Baleno' 
    },
    sedan: { 
      name: language === 'hi' ? 'सेडान' : 'Sedan', 
      example: 'City, Verna, Dzire, Ciaz, Slavia' 
    },
    csuv: { 
      name: language === 'hi' ? 'कॉम्पैक्ट SUV' : 'Compact SUV', 
      example: 'Creta, Brezza, Nexon, Seltos, Sonet' 
    },
    suvLuxury: { 
      name: language === 'hi' ? 'SUV / 7-सीटर लग्जरी' : 'SUV / Luxury 7-Seater', 
      example: 'Innova, Fortuner, XUV700, Thar, BMW/Audi' 
    },
  };

  const whatsappUrl = (pkgTitle: string, price: number) => {
    const text = language === 'hi'
      ? `नमस्ते PURE CLEANING, मुझे घर बैठे कार वॉश बुक करना है:\n\nपैकेज: ${pkgTitle}\nकार का प्रकार: ${vehicleTypeLabels[selectedVehicleType].name}\nरेट: ₹${price}\n\nकृपया स्लॉट कन्फर्म करें।`
      : `Hello PURE CLEANING, I want to book a doorstep Car Wash:\n\nPackage: ${pkgTitle}\nCar Type: ${vehicleTypeLabels[selectedVehicleType].name}\nPrice: ₹${price}\n\nPlease confirm availability.`;
    return `https://wa.me/${CONTACT_INFO.whatsappNumber}?text=${encodeURIComponent(text)}`;
  };

  return (
    <section id="car-wash" className="py-16 sm:py-24 bg-slate-900 text-white border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with 1-Touch Translate */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2">
            <Car className="w-3.5 h-3.5 text-emerald-400" />
            <span>{language === 'hi' ? '3D डोरस्टेप कार केयर' : 'Doorstep Auto Care'}</span>
          </div>

          <div className="flex items-center justify-center gap-3">
            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight font-display text-balance">
              {t('carWashTitle')}
            </h2>
            <button
              type="button"
              onClick={toggleLanguage}
              title="Touch to switch language (टच करके भाषा बदलें)"
              className="inline-flex items-center gap-1 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
            >
              <Languages className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
            </button>
          </div>

          <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-xl mx-auto leading-relaxed">
            {t('carWashSub')}
          </p>
        </div>

        {/* 3D Realistic Car Wash Visual Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-slate-800/80 rounded-3xl p-6 sm:p-8 border border-slate-700 mb-12 shadow-2xl">
          
          {/* Left Visual: Foam Cannon Exterior Washing */}
          <div className="lg:col-span-6 relative group">
            <div className="rounded-3xl overflow-hidden shadow-2xl border border-slate-700 bg-slate-800 h-[280px] sm:h-[340px]">
              <img
                src={ASSET_IMAGES.carWash}
                alt="Doorstep high pressure snow foam car washing service in Indian apartment"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center group-hover:scale-104 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-3 left-4 right-4 bg-slate-900/90 backdrop-blur-md p-3.5 rounded-2xl border border-slate-700 text-xs">
                <span className="font-black text-emerald-400 block text-sm">
                  {language === 'hi' ? 'टचलेस स्नो फोम व 140-बार जेट प्रेशर' : 'Touchless Snow Foam & 140-Bar Jet Pressure'}
                </span>
                <span className="text-[11px] text-slate-300 mt-0.5 block">
                  {language === 'hi' 
                    ? 'गाड़ी के पेंट पर बिना कोई खरोंच या स्क्रैच डाले रोड डस्ट को आसानी से अलग करता है।'
                    : 'Safely dislodges abrasive road dust without swirl marks or paint scratching.'}
                </span>
              </div>
            </div>
          </div>

          {/* Right Visual: Interior Detailing */}
          <div className="lg:col-span-6 relative group">
            <div className="rounded-3xl overflow-hidden shadow-2xl border border-slate-700 bg-slate-800 h-[280px] sm:h-[340px]">
              <img
                src={ASSET_IMAGES.carInterior}
                alt="Doorstep interior car vacuuming and dashboard detailing service"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center group-hover:scale-104 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-3 left-4 right-4 bg-slate-900/90 backdrop-blur-md p-3.5 rounded-2xl border border-slate-700 text-xs">
                <span className="font-black text-emerald-400 block text-sm">
                  {language === 'hi' ? 'अंदरूनी सीट शैम्पू व एसी स्टीम डिसइन्फेक्शन' : 'Interior Seat Shampoo & AC Vent Disinfection'}
                </span>
                <span className="text-[11px] text-slate-300 mt-0.5 block">
                  {language === 'hi'
                    ? 'कारपेट और सीटों से गहराई में फंसी धूल, चाय के दाग व बदबू को पूरी तरह हटाता है।'
                    : 'Deep suction pulls out embedded food crumbs, drink spills, and stale AC odors.'}
                </span>
              </div>
            </div>
          </div>

        </div>

        {/* Vehicle Type Selector Tabs with 3D Elevation */}
        <div className="mb-10 text-center">
          <span className="text-xs font-black uppercase tracking-wider text-slate-400 block mb-3">
            {t('selectCarType')}
          </span>
          <div className="inline-flex flex-wrap justify-center gap-2 p-1.5 bg-slate-800/80 rounded-2xl border border-slate-700 shadow-inner">
            {(Object.keys(vehicleTypeLabels) as Array<keyof typeof vehicleTypeLabels>).map((vKey) => (
              <button
                key={vKey}
                onClick={() => setSelectedVehicleType(vKey)}
                className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  selectedVehicleType === vKey
                    ? 'bg-emerald-600 text-white shadow-[0_4px_10px_rgba(16,185,129,0.35)] -translate-y-0.5'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
                }`}
              >
                <span>{vehicleTypeLabels[vKey].name}</span>
                <span className="block text-[10px] font-normal opacity-80 mt-0.5 max-w-[120px] truncate">
                  {vehicleTypeLabels[vKey].example}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* 3 Car Care Packages with 3D Perspective */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {CAR_WASH_PACKAGES.map((pkg) => {
            const currentPrice = pkg.prices[selectedVehicleType];

            return (
              <ThreeDCard key={pkg.id} allowTouchTranslate={true}>
                <div className="bg-slate-800/90 rounded-3xl p-6 border-2 border-slate-700 hover:border-emerald-500 shadow-xl flex flex-col justify-between h-full relative group">
                  {pkg.badge && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-emerald-600 text-white text-[10px] font-black uppercase px-3 py-1 rounded-full shadow-md">
                      {pkg.badge}
                    </span>
                  )}

                  <div>
                    <h3 className="text-lg font-black text-white font-display">
                      {pkg.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      {pkg.shortDesc}
                    </p>

                    {/* Price and Duration */}
                    <div className="mt-4 p-3.5 bg-slate-900/80 rounded-2xl border border-slate-700/90 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">
                          {vehicleTypeLabels[selectedVehicleType].name}
                        </span>
                        <span className="text-2xl font-black text-emerald-400 font-display">
                          ₹{currentPrice}
                        </span>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">
                          {language === 'hi' ? 'समय' : 'Duration'}
                        </span>
                        <span className="text-xs font-black text-white flex items-center gap-1 justify-end mt-0.5">
                          <Clock className="w-3.5 h-3.5 text-amber-400" />
                          {pkg.duration}
                        </span>
                      </div>
                    </div>

                    {/* Detailed 3-Column Work Checklist */}
                    <div className="mt-5 space-y-4 text-xs">
                      
                      {/* Column 1: Exterior */}
                      <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-700/60">
                        <div className="font-black text-emerald-400 uppercase tracking-wide text-[10px] flex items-center gap-1.5 mb-1.5">
                          <Droplets className="w-3.5 h-3.5" />
                          <span>{t('exteriorColumn')}</span>
                        </div>
                        <ul className="space-y-1 text-slate-300 text-[11px]">
                          {pkg.workColumns.exteriorWork.map((item, i) => (
                            <li key={i} className="flex items-start gap-1.5">
                              <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0 mt-0.5" />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Column 2: Interior */}
                      <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-700/60">
                        <div className="font-black text-emerald-400 uppercase tracking-wide text-[10px] flex items-center gap-1.5 mb-1.5">
                          <Zap className="w-3.5 h-3.5" />
                          <span>{t('interiorColumn')}</span>
                        </div>
                        <ul className="space-y-1 text-slate-300 text-[11px]">
                          {pkg.workColumns.interiorWork.map((item, i) => (
                            <li key={i} className="flex items-start gap-1.5">
                              <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0 mt-0.5" />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Column 3: Finishing */}
                      <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-700/60">
                        <div className="font-black text-emerald-400 uppercase tracking-wide text-[10px] flex items-center gap-1.5 mb-1.5">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>{t('finishingColumn')}</span>
                        </div>
                        <ul className="space-y-1 text-slate-300 text-[11px]">
                          {pkg.workColumns.finishingWork.map((item, i) => (
                            <li key={i} className="flex items-start gap-1.5">
                              <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0 mt-0.5" />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                    </div>
                  </div>

                  {/* 3D Action Buttons */}
                  <div className="mt-6 pt-4 border-t border-slate-700 space-y-2.5">
                    <button
                      type="button"
                      onClick={() => onBookCarWash(pkg.title, currentPrice, vehicleTypeLabels[selectedVehicleType].name)}
                      className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 text-xs font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-2xl shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none transition-all cursor-pointer"
                    >
                      <span>{t('bookNow')} (₹{currentPrice})</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    <a
                      href={whatsappUrl(pkg.title, currentPrice)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-950 border border-slate-700 rounded-xl transition-colors"
                    >
                      <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{language === 'hi' ? 'व्हाट्सएप पर बुक करें' : 'Book on WhatsApp'}</span>
                    </a>
                  </div>

                </div>
              </ThreeDCard>
            );
          })}
        </div>

        {/* Doorstep Service Guarantee Note */}
        <div className="mt-12 bg-slate-800/80 rounded-2xl p-4 border border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              <strong>{language === 'hi' ? 'डोरस्टेप पावर व पानी:' : 'Parking Bay Service:'}</strong>{' '}
              {language === 'hi' 
                ? 'हमारी वैन 50-मीटर बिजली केबल और हाई-प्रेशर पंप्स लाती है। केवल 1 पानी कनेक्शन आवश्यक है।'
                : 'Our detailing technicians bring extension cables, high-pressure foam guns, and wet vacuums.'}
            </span>
          </div>
          <div className="text-emerald-400 font-black">
            {language === 'hi' ? 'सोसायटी व विला पार्किंग में उपलब्ध' : 'Available in Society & Villa Parking'}
          </div>
        </div>

      </div>
    </section>
  );
};
