import React, { useState } from 'react';
import { Star, MessageSquare, Plus, CheckCircle, ShieldCheck, X, Languages } from 'lucide-react';
import { TESTIMONIALS, Testimonial } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';
import { ThreeDCard } from './ThreeDCard';

export const ReviewsSection: React.FC = () => {
  const { language, toggleLanguage, t } = useLanguage();
  const [reviewsList, setReviewsList] = useState<Testimonial[]>(TESTIMONIALS);
  const [showReviewModal, setShowReviewModal] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [location, setLocation] = useState<string>('');
  const [service, setService] = useState<string>('Full Home Deep Cleaning');
  const [rating, setRating] = useState<number>(5);
  const [comment, setComment] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !comment.trim()) return;

    const newRev: Testimonial = {
      id: `rev-${Date.now()}`,
      name: name.trim(),
      location: location.trim() || (language === 'hi' ? 'वेरीफाइड ग्राहक' : 'Verified Home'),
      rating,
      service,
      date: language === 'hi' ? 'अभी-अभी' : 'Just now',
      comment: comment.trim(),
    };

    setReviewsList([newRev, ...reviewsList]);
    setSubmitted(true);
    setTimeout(() => {
      setShowReviewModal(false);
      setSubmitted(false);
      setName('');
      setLocation('');
      setComment('');
    }, 1500);
  };

  return (
    <section className="py-16 sm:py-24 bg-slate-50 border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with 1-Touch Translate */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-6">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100 px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-2">
              <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span>{language === 'hi' ? '3D ग्राहक संतुष्टि एवं रिव्यू' : 'Customer Satisfaction'}</span>
            </div>

            <div className="flex items-center gap-3">
              <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight font-display text-balance">
                {t('reviewsTitle')}
              </h2>
              <button
                type="button"
                onClick={toggleLanguage}
                title="Touch to switch language (टच करके भाषा बदलें)"
                className="hidden sm:inline-flex items-center gap-1 px-3 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border-2 border-emerald-300 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
              >
                <Languages className="w-3.5 h-3.5 text-emerald-600" />
                <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
              </button>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-xl font-medium">
              {language === 'hi'
                ? 'हमारे असली ग्राहकों के अनुभव जिन्होंने PURE CLEANING की सेवाओं पर भरोसा किया।'
                : 'Real feedback from real homeowners who trusted PURE CLEANING with their homes.'}
            </p>
          </div>

          {/* Write a Review Button with 3D Depth */}
          <button
            onClick={() => setShowReviewModal(true)}
            className="inline-flex items-center gap-2 px-5 py-3 text-xs font-black text-slate-800 bg-white hover:bg-slate-100 border-2 border-slate-300 rounded-2xl shadow-sm active:translate-y-0.5 transition-all cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-4 h-4 text-emerald-600" />
            <span>{language === 'hi' ? 'रिव्यू लिखें' : 'Write a Review'}</span>
          </button>
        </div>

        {/* Reviews Grid with 3D Card Elevation */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reviewsList.map((rev) => (
            <ThreeDCard key={rev.id} allowTouchTranslate={true}>
              <div className="bg-white rounded-3xl p-6 border-2 border-slate-200 hover:border-emerald-300 shadow-sm flex flex-col justify-between h-full transition-all">
                <div>
                  {/* 5 Star UI */}
                  <div className="flex items-center gap-1 text-amber-400 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'
                        }`}
                      />
                    ))}
                  </div>

                  <p className="text-xs sm:text-sm text-slate-700 leading-relaxed italic font-medium">
                    "{rev.comment}"
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <span>{rev.name}</span>
                      <span title="Verified Customer" className="inline-flex">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5 font-medium">
                      {rev.location} · {rev.service}
                    </div>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono shrink-0">
                    {rev.date}
                  </div>
                </div>
              </div>
            </ThreeDCard>
          ))}
        </div>

      </div>

      {/* Review Modal */}
      {showReviewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border-2 border-slate-200 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-lg font-black text-slate-900 font-display">
                {language === 'hi' ? 'अपना अनुभव शेयर करें' : 'Share Your Experience'}
              </h3>
              <button
                onClick={() => setShowReviewModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {submitted ? (
              <div className="text-center py-8 space-y-3">
                <CheckCircle className="w-12 h-12 text-emerald-600 mx-auto animate-bounce" />
                <h4 className="text-lg font-black text-slate-900">{language === 'hi' ? 'धन्यवाद!' : 'Thank you!'}</h4>
                <p className="text-xs text-slate-500">{language === 'hi' ? 'आपका रिव्यू पब्लिश हो गया है।' : 'Your review has been published.'}</p>
              </div>
            ) : (
              <form onSubmit={handleSubmitReview} className="space-y-4 pt-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{language === 'hi' ? 'आपका नाम' : 'Your Name'}</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={language === 'hi' ? 'उदा: प्रिया शर्मा' : 'e.g. Priya S.'}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{language === 'hi' ? 'इलाका / शहर' : 'Locality / Area'}</label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder={language === 'hi' ? 'उदा: सेक्टर 14 / गोल्फ कोर्स रोड' : 'e.g. Sector 48, Gurgaon'}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{language === 'hi' ? 'स्टार रेटिंग' : 'Rating'}</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setRating(star)}
                        className="p-1 cursor-pointer"
                      >
                        <Star
                          className={`w-6 h-6 ${
                            star <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{language === 'hi' ? 'आपकी राय' : 'Your Review'}</label>
                  <textarea
                    required
                    rows={3}
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder={language === 'hi' ? 'सफाई और सेवा कैसी लगी?' : 'Tell us about the cleaning quality...'}
                    className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 px-4 text-xs font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none transition-all cursor-pointer"
                >
                  {language === 'hi' ? 'रिव्यू सबमिट करें' : 'Submit Review'}
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
