import React, { useState } from 'react';
import {
  Truck,
  Clock,
  Users,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  MessageCircle,
  PackageCheck,
  Move,
  Layers,
  Sparkles,
  PhoneCall,
  CalendarCheck,
  Languages
} from 'lucide-react';
import {
  LOADING_PACKAGES,
  VEHICLE_LOADING_RATES,
  FLOOR_STAIRCASE_CHARGES,
  WORK_TIMINGS_SHIFTS,
  ASSET_IMAGES,
  CONTACT_INFO
} from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';
import { ThreeDCard } from './ThreeDCard';

interface LoadingUnloadingSectionProps {
  onBookLoading: (packageName: string, price: number, duration: string, helpers: string) => void;
}

export const LoadingUnloadingSection: React.FC<LoadingUnloadingSectionProps> = ({ onBookLoading }) => {
  const { language, toggleLanguage, t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'packages' | 'ratesTable'>('packages');

  const whatsappUrl = (pkgTitle: string, price: number, duration?: string) => {
    const text = language === 'hi'
      ? `नमस्ते PURE CLEANING, मुझे लोडिंग व अनलोडिंग हेल्पर बुक करने हैं:\n\nसर्विस: ${pkgTitle}\nरेट: ₹${price}\nसमय: ${duration || 'काम अनुसार'}\n\nकृपया हेल्पर्स की उपलब्धता बताएं।`
      : `Hello PURE CLEANING, I want to book Loading & Unloading Services:\n\nService: ${pkgTitle}\nEstimated Price: ₹${price}\nEstimated Time: ${duration || 'As per requirement'}\n\nPlease confirm helper availability.`;
    return `https://wa.me/${CONTACT_INFO.whatsappNumber}?text=${encodeURIComponent(text)}`;
  };

  return (
    <section id="loading-unloading" className="py-16 sm:py-24 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with 1-Touch Translate */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-300 px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-3 shadow-2xs">
            <Truck className="w-3.5 h-3.5 text-emerald-700" />
            <span>PURE CLEANING · {language === 'hi' ? '3D लोडिंग व शिफ्टिंग हेल्पर्स' : '3D Shifting & Heavy Lifting'}</span>
          </div>
          
          <div className="flex items-center justify-center gap-3">
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight font-display text-balance">
              {t('loadingTitle')}
            </h2>
            <button
              type="button"
              onClick={toggleLanguage}
              title="Touch to switch Hindi / English (टच करके भाषा बदलें)"
              className="inline-flex items-center gap-1 px-3 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border-2 border-emerald-300 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
            </button>
          </div>

          <p className="text-base sm:text-lg font-black text-emerald-700 mt-2">
            {t('loadingSubHindi')}
          </p>

          <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
            {t('loadingDesc')}
          </p>

          {/* Quick Tab Toggle with 3D Pills */}
          <div className="inline-flex items-center p-1 bg-slate-100 rounded-2xl mt-6 border border-slate-200 shadow-inner">
            <button
              onClick={() => setActiveTab('packages')}
              className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeTab === 'packages'
                  ? 'bg-emerald-600 text-white shadow-[0_4px_10px_rgba(16,185,129,0.35)] -translate-y-0.5'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t('tabPackages')}
            </button>
            <button
              onClick={() => setActiveTab('ratesTable')}
              className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeTab === 'ratesTable'
                  ? 'bg-emerald-600 text-white shadow-[0_4px_10px_rgba(16,185,129,0.35)] -translate-y-0.5'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t('tabVehicleRates')}
            </button>
          </div>
        </div>

        {/* 3D Visual Showcase Container */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-slate-50 rounded-3xl p-6 sm:p-8 lg:p-10 border-2 border-slate-200 shadow-[0_20px_40px_rgba(0,0,0,0.06)] mb-12">
          
          {/* Left Visual: Moving Helpers Photo */}
          <div className="lg:col-span-6 relative group">
            <div className="rounded-3xl overflow-hidden shadow-2xl border-2 border-slate-200 bg-slate-100 h-[300px] sm:h-[360px]">
              <img
                src={ASSET_IMAGES.loadingUnloading}
                alt="Professional Indian moving helpers carefully carrying furniture with lifting straps"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center group-hover:scale-104 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />
              
              <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md p-3.5 rounded-2xl border border-slate-200 text-xs text-slate-800 shadow-xl">
                <div className="font-black text-emerald-800 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>{language === 'hi' ? 'जीरो स्क्रैच व सेफ़्टी गारंटी' : 'Zero Scratches & Safe Handling Guarantee'}</span>
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5 font-medium">
                  {language === 'hi' 
                    ? 'हम घर की दीवारों व टाइलों की सुरक्षा के लिए शोल्डर स्ट्रैप्स, कॉर्नर गार्ड्स व फ्लोर स्लाइडर्स उपयोग करते हैं।'
                    : 'We use heavy-duty moving harnesses, floor sliders & corner guards to protect your home walls and tiles.'}
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Key Helper Advantages */}
          <div className="lg:col-span-6 space-y-3.5">
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-2.5 mb-1">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs shrink-0">
                  <Move className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-black text-slate-900">
                  {language === 'hi' ? 'भारी फर्नीचर व सीढ़ियों से सुरक्षित ले जाना' : 'Heavy Furniture & Staircase Navigation'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed pl-10.5 font-medium">
                {language === 'hi'
                  ? '2-पर्सन और 4-पर्सन शोल्डर स्ट्रैप तकनीक ताकि भारी लकड़ी के बेड, अलमारी व डाइनिंग टेबल बिना दरवाजे या सीढ़ी की रेलिंग टकराए सुरक्षित ऊपर-नीचे किए जा सकें।'
                  : 'Our crew is trained in 2-person and 4-person shoulder harness techniques to easily move heavy beds, almirahs, and dining tables through staircases without scraping.'}
              </p>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-2.5 mb-1">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs shrink-0">
                  <Truck className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-black text-slate-900">
                  {language === 'hi' ? 'ट्रक व टेम्पो में वैज्ञानिक तरीके से सामान लगाना' : 'Scientific Truck & Cargo Stacking'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed pl-10.5 font-medium">
                {language === 'hi'
                  ? 'टाटा ऐस, पिकअप या कैंटर में भारी उपकरण नीचे लॉक किए जाते हैं, नाजुक डिब्बे ऊपर रखे जाते हैं और सामान को बेल्ट से कसकर बांधा जाता है।'
                  : 'Proper arrangement inside Tata Ace, Pickup, or Canter: heavy appliances locked safely at the base, fragile cartons stacked on top, and cargo ratcheted tight.'}
              </p>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-2.5 mb-1">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs shrink-0">
                  <PackageCheck className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-black text-slate-900">
                  {language === 'hi' ? 'कमरे अनुसार सामान की सही जगह पर अनलोडिंग' : 'Room-by-Room Placement'}
                </h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed pl-10.5 font-medium">
                {language === 'hi'
                  ? 'दरवाजे पर बक्से नहीं छोड़े जाते। अलमारी बेडरूम में, किचन के डिब्बे किचन में और सोफा ड्रॉइंग रूम में जहाँ आप चाहें वहीं सेट किया जाता है।'
                  : 'No box dumping in entry hallways. Our helpers place wardrobes right into bedrooms, cartons in respective rooms, and align sofas in the living space.'}
              </p>
            </div>
          </div>

        </div>

        {/* View 1: 4 Loading & Unloading Package Cards with 3D Perspective */}
        {activeTab === 'packages' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {LOADING_PACKAGES.map((pkg) => (
              <ThreeDCard key={pkg.id} allowTouchTranslate={true}>
                <div className="bg-white rounded-3xl p-6 border-2 border-slate-200 hover:border-emerald-400 shadow-sm transition-all flex flex-col justify-between h-full relative">
                  {pkg.badge && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-emerald-600 text-white text-[10px] font-black uppercase px-3 py-1 rounded-full shadow-md">
                      {pkg.badge}
                    </span>
                  )}

                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-black text-emerald-700 uppercase tracking-wider mb-1">
                      <Users className="w-3.5 h-3.5" />
                      <span>{pkg.helpersCount}</span>
                    </div>

                    <h3 className="text-lg font-black text-slate-900 font-display">
                      {pkg.title}
                    </h3>

                    <p className="text-xs text-slate-500 mt-1.5 leading-relaxed line-clamp-3">
                      {pkg.description}
                    </p>

                    {/* Price & Duration Box */}
                    <div className="mt-4 p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold block uppercase">
                          {language === 'hi' ? 'शुरुआती रेट' : 'Starting Rate'}
                        </span>
                        <span className="text-2xl font-black text-slate-900 font-display">
                          ₹{pkg.startingPrice}
                        </span>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 font-bold block uppercase">
                          {language === 'hi' ? 'अनुमानित समय' : 'Working Time'}
                        </span>
                        <span className="text-xs font-black text-slate-800 flex items-center gap-1 justify-end mt-0.5">
                          <Clock className="w-3.5 h-3.5 text-emerald-600" />
                          {pkg.duration}
                        </span>
                      </div>
                    </div>

                    {/* Scope of Work */}
                    <div className="mt-5 space-y-2">
                      <div className="text-[11px] font-black text-slate-900 uppercase tracking-wide">
                        {t('workIncluded')}
                      </div>
                      <ul className="space-y-1.5 text-xs text-slate-600">
                        {pkg.scope.map((task, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                            <span>{task}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Equipment Provided */}
                    <div className="mt-4 pt-3 border-t border-slate-100">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                        {t('equipmentBrought')}
                      </span>
                      <div className="flex flex-wrap gap-1.5 text-[11px] text-slate-700">
                        {pkg.equipmentProvided.map((eq, i) => (
                          <span key={i} className="bg-slate-100 px-2.5 py-0.5 rounded-lg text-[11px] font-medium">
                            • {eq}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* 3D Action Buttons */}
                  <div className="mt-6 pt-4 border-t border-slate-100 space-y-2.5">
                    <button
                      type="button"
                      onClick={() =>
                        onBookLoading(
                          `Loading & Unloading: ${pkg.title}`,
                          pkg.startingPrice,
                          pkg.duration,
                          pkg.helpersCount
                        )
                      }
                      className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 text-xs font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-2xl shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none transition-all cursor-pointer"
                    >
                      <span>{t('bookHelpers')} (₹{pkg.startingPrice})</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    <a
                      href={whatsappUrl(pkg.title, pkg.startingPrice, pkg.duration)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-black text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl transition-colors"
                    >
                      <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{language === 'hi' ? 'व्हाट्सएप पर बुक करें' : 'Book on WhatsApp'}</span>
                    </a>
                  </div>

                </div>
              </ThreeDCard>
            ))}
          </div>
        )}

        {/* View 2: Vehicle Rate Table */}
        <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 lg:p-10 border-2 border-slate-800 mb-12 shadow-2xl">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400 uppercase tracking-wider mb-1">
                <Clock className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'फिक्स रेट व काम का समय लिस्ट' : 'Transparent Rates & Estimated Working Hours'}</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black font-display text-white">
                {t('vehicleTableTitle')}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                {language === 'hi' 
                  ? 'गाड़ी के आकार के अनुसार काम का अनुमानित समय, आवश्यक हेल्पर्स और फिक्स लेबर रेट'
                  : 'Fixed labor rates and estimated completion time based on truck & tempo sizes.'}
              </p>
            </div>
            
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggleLanguage}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-emerald-400 border border-slate-700 cursor-pointer flex items-center gap-1"
              >
                <Languages className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'Switch to English' : 'हिंदी में देखें'}</span>
              </button>
            </div>
          </div>

          {/* Vehicle Rates Table */}
          <div className="mt-6 overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[11px] font-bold">
                  <th className="py-3 px-3">{t('colVehicle')}</th>
                  <th className="py-3 px-3">{t('colCapacity')}</th>
                  <th className="py-3 px-3">{t('colHelpers')}</th>
                  <th className="py-3 px-3">{t('colWorkTime')}</th>
                  <th className="py-3 px-3">{t('colRate')}</th>
                  <th className="py-3 px-3 text-right">{t('colAction')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {VEHICLE_LOADING_RATES.map((rateItem, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/60 transition-colors">
                    <td className="py-4 px-3 font-bold text-white flex items-center gap-2">
                      <Truck className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{rateItem.vehicle}</span>
                    </td>
                    <td className="py-4 px-3 text-slate-300">
                      {rateItem.capacity}
                    </td>
                    <td className="py-4 px-3 text-emerald-300 font-bold">
                      {rateItem.helpersAssigned}
                    </td>
                    <td className="py-4 px-3 text-slate-200 font-mono">
                      <span className="inline-flex items-center gap-1 bg-slate-800 px-2 py-1 rounded-lg">
                        <Clock className="w-3.5 h-3.5 text-amber-400" />
                        {rateItem.loadingTime}
                      </span>
                    </td>
                    <td className="py-4 px-3 text-xl font-black text-emerald-400 font-display">
                      ₹{rateItem.rate}
                    </td>
                    <td className="py-4 px-3 text-right">
                      <button
                        onClick={() =>
                          onBookLoading(
                            `Vehicle Loading: ${rateItem.vehicle}`,
                            rateItem.rate,
                            rateItem.loadingTime,
                            rateItem.helpersAssigned
                          )
                        }
                        className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow-[0_3px_0_#047857] active:translate-y-0.5 active:shadow-none transition-all cursor-pointer"
                      >
                        {t('bookNow')}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Secondary Details: Floor / Staircase Charges & Shifts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8 pt-6 border-t border-slate-800">
            {/* Floor Charges */}
            <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800">
              <h4 className="text-xs font-black text-emerald-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'सीढ़ी व मंजिल अनुसार चार्ज (लिफ्ट न होने पर)' : 'Floor & Staircase Cost Structure'}</span>
              </h4>
              <div className="space-y-2 text-xs">
                {FLOOR_STAIRCASE_CHARGES.map((f, i) => (
                  <div key={i} className="flex items-center justify-between py-1.5 border-b border-slate-800/60 last:border-0">
                    <span className="text-slate-300">{f.floor}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-slate-400 text-[11px] font-mono">{f.timeAdded}</span>
                      <span className="font-black text-emerald-300">{f.extraCost}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Shift & Dispatch Times */}
            <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-black text-emerald-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                  <CalendarCheck className="w-3.5 h-3.5" />
                  <span>{language === 'hi' ? 'काम के घंटे एवं तत्काल सेवा' : 'Working Shifts & Instant Dispatch'}</span>
                </h4>
                <div className="space-y-2.5 text-xs text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">{language === 'hi' ? 'नॉर्मल शिफ्ट:' : 'Regular Shifts:'}</span>
                    <span className="font-bold text-white">{WORK_TIMINGS_SHIFTS.regularShift}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">{language === 'hi' ? 'नाइट शिफ्ट:' : 'Night Shift:'}</span>
                    <span className="font-bold text-white">{WORK_TIMINGS_SHIFTS.eveningShift}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">{language === 'hi' ? 'पहुंचने का समय:' : 'Notice Period:'}</span>
                    <span className="font-black text-emerald-400">{WORK_TIMINGS_SHIFTS.sameDayNotice}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  {language === 'hi' ? 'तुरंत हेल्पर चाहिए?' : 'Need helpers immediately?'}
                </span>
                <a
                  href={`tel:${CONTACT_INFO.phoneRaw}`}
                  className="inline-flex items-center gap-1 text-xs font-black text-emerald-400 hover:text-emerald-300"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>{CONTACT_INFO.phone}</span>
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Shifting Safety Bar */}
        <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-700 shadow-2xs">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>
              <strong>{language === 'hi' ? 'फिक्स रेट और शून्य छिपा चार्ज:' : 'Zero Hidden Hourly Penalties:'}</strong>{' '}
              {language === 'hi'
                ? 'PURE CLEANING के हेल्पर्स पूरा काम खत्म होने तक जिम्मेदारी से कार्य करते हैं। काम से संतुष्ट होने पर ही कैश या UPI से भुगतान करें।'
                : 'PURE CLEANING helpers work dedicatedly until your loading or unloading is completed satisfactorily. Pay cash or UPI after job completion.'}
            </span>
          </div>
          <div className="text-emerald-700 font-black whitespace-nowrap">
            {language === 'hi' ? 'सेम-डे व एडवांस बुकिंग उपलब्ध' : 'Same-Day & Advance Booking Available'}
          </div>
        </div>

      </div>
    </section>
  );
};
