import React, { useState, useMemo } from 'react';
import {
  Sparkles,
  Search,
  ArrowRight,
  Armchair,
  Layers,
  BedDouble,
  Utensils,
  Briefcase,
  Bed,
  Archive,
  Tv,
  BookOpen,
  ChefHat,
  Folder,
  Flame,
  Droplets,
  Grid,
  CheckCircle,
  Smile,
  Maximize,
  Sliders,
  DoorClosed,
  Columns,
  Sun,
  Activity,
  Box,
  RotateCw,
  Wind,
  Shield,
  Plus
} from 'lucide-react';
import { CATALOG_ITEMS, CatalogItem } from '../data/cleaningData';

interface ItemCatalogSectionProps {
  onBookItem: (itemName: string, price: number) => void;
}

export const ItemCatalogSection: React.FC<ItemCatalogSectionProps> = ({ onBookItem }) => {
  const [filterText, setFilterText] = useState<string>('');

  const filteredItems = useMemo(() => {
    return CATALOG_ITEMS.filter(
      (item) =>
        item.name.toLowerCase().includes(filterText.toLowerCase()) ||
        item.cleaningType.toLowerCase().includes(filterText.toLowerCase())
    );
  }, [filterText]);

  // Helper icon mapper
  const renderItemIcon = (iconName: string) => {
    const props = { className: 'w-5 h-5 text-emerald-600' };
    switch (iconName) {
      case 'Armchair': return <Armchair {...props} />;
      case 'Layers': return <Layers {...props} />;
      case 'BedDouble': return <BedDouble {...props} />;
      case 'Utensils': return <Utensils {...props} />;
      case 'Briefcase': return <Briefcase {...props} />;
      case 'Bed': return <Bed {...props} />;
      case 'Archive': return <Archive {...props} />;
      case 'Tv': return <Tv {...props} />;
      case 'BookOpen': return <BookOpen {...props} />;
      case 'ChefHat': return <ChefHat {...props} />;
      case 'Folder': return <Folder {...props} />;
      case 'Flame': return <Flame {...props} />;
      case 'Droplets': return <Droplets {...props} />;
      case 'Grid': return <Grid {...props} />;
      case 'CheckCircle': return <CheckCircle {...props} />;
      case 'Smile': return <Smile {...props} />;
      case 'Maximize': return <Maximize {...props} />;
      case 'Sliders': return <Sliders {...props} />;
      case 'DoorClosed': return <DoorClosed {...props} />;
      case 'Columns': return <Columns {...props} />;
      case 'Sun': return <Sun {...props} />;
      case 'Activity': return <Activity {...props} />;
      case 'Box': return <Box {...props} />;
      case 'RotateCw': return <RotateCw {...props} />;
      case 'Wind': return <Wind {...props} />;
      case 'Shield': return <Shield {...props} />;
      default: return <Sparkles {...props} />;
    }
  };

  return (
    <section id="catalog" className="py-16 sm:py-24 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Modular Checklist</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-display text-balance">
              What Can We Clean?
            </h2>
            <p className="text-sm sm:text-base text-slate-600 mt-2 max-w-xl">
              From individual dining chairs and carpets to kitchen chimneys and water tanks, choose exact items for customized doorstep servicing.
            </p>
          </div>

          {/* Quick Filter */}
          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              placeholder="Find item (e.g. Chimney, Sofa)..."
              className="w-full h-10 pl-9 pr-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Catalog Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 xl:grid-cols-7 gap-3 sm:gap-4">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="group bg-slate-50 hover:bg-white rounded-xl p-3.5 border border-slate-200 hover:border-emerald-300 shadow-2xs hover:shadow-sm transition-all flex flex-col justify-between"
            >
              <div>
                <div className="w-9 h-9 rounded-lg bg-emerald-50 group-hover:bg-emerald-100 flex items-center justify-center transition-colors mb-2.5">
                  {renderItemIcon(item.iconName)}
                </div>

                <h4 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1 group-hover:text-emerald-700 transition-colors">
                  {item.name}
                </h4>

                <div className="text-[11px] text-slate-500 mt-0.5 line-clamp-1 font-medium">
                  {item.cleaningType}
                </div>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-200/80 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block font-medium">from</span>
                  <span className="text-xs sm:text-sm font-extrabold text-slate-900 font-display">
                    ₹{item.startingPrice}
                  </span>
                </div>

                <button
                  onClick={() => onBookItem(`${item.name} Cleaning`, item.startingPrice)}
                  title={`Book ${item.name}`}
                  className="p-1.5 rounded-lg bg-emerald-50 text-emerald-800 hover:bg-emerald-600 hover:text-white transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
