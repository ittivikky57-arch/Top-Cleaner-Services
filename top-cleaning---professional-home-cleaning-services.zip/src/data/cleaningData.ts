export interface ServiceItem {
  id: string;
  name: string;
  category: 'full_home' | 'rooms' | 'kitchen_bath' | 'furniture_fabric' | 'appliances' | 'specialized';
  shortDesc: string;
  fullDesc: string;
  startingPrice: number;
  duration: string;
  rating: number;
  reviewsCount: number;
  image: string;
  features: string[];
  includes: string[];
  equipmentUsed: string[];
}

export interface RoomCleaningItem {
  id: string;
  roomName: string;
  startingPrice: number;
  duration: string;
  image: string;
  includedTasks: string[];
}

export interface CatalogItem {
  id: string;
  name: string;
  cleaningType: string;
  startingPrice: number;
  iconName: string;
}

export interface BeforeAfterCase {
  id: string;
  title: string;
  subtitle: string;
  beforeDesc: string;
  afterDesc: string;
  serviceName: string;
  timeTaken: string;
  beforeTag: string;
  afterTag: string;
  beforeBg: string;
  afterBg: string;
}

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  rating: number;
  service: string;
  date: string;
  comment: string;
}

export interface BookingRecord {
  id: string;
  customerName: string;
  phone: string;
  email: string;
  service: string;
  propertyType: string;
  date: string;
  timeSlot: string;
  address: string;
  price: number;
  status: 'New' | 'Confirmed' | 'Assigned' | 'In Progress' | 'Completed' | 'Cancelled';
  createdAt: string;
  instructions?: string;
}

export const CONTACT_INFO = {
  brandName: 'PURE CLEANING',
  tagline: 'Professional Cleaning & Loading Services. Honest Prices. Fresh Homes.',
  phone: '+91 62043 19105',
  phoneRaw: '+916204319105',
  whatsapp: '+91 62043 19105',
  whatsappNumber: '916204319105',
  email: 'ittivikky57@gmail.com',
  workingHours: '8:00 AM – 8:00 PM (Everyday)',
  address: 'Metro Service Hub, Sector 14, Service Center, India',
  promoCode: 'FIRST100',
  firstBookingDiscount: 100,
};

// Generated Asset Paths
import heroImage from '@/src/assets/images/hero_cleaning_livingroom_1791127063259.jpg';
import deepHomeImage from '@/src/assets/images/deep_home_cleaning_1791127077553.jpg';
import sofaCarpetImage from '@/src/assets/images/sofa_carpet_cleaning_1791127090847.jpg';
import kitchenChimneyImage from '@/src/assets/images/kitchen_chimney_clean_1791127103200.jpg';
import cleaningMaterialsImage from '@/src/assets/images/cleaning_materials_supplies_1791127833727.jpg';
import carWashCleaningImage from '@/src/assets/images/car_wash_cleaning_1791127853386.jpg';
import carInteriorDetailingImage from '@/src/assets/images/car_interior_detailing_1791127869190.jpg';
import equipmentVacuumImg from '@/src/assets/images/equipment_vacuum_machine_1791128550193.jpg';
import equipmentScrubberImg from '@/src/assets/images/equipment_floor_scrubber_1791128564982.jpg';
import equipmentSteamImg from '@/src/assets/images/equipment_steam_cleaner_1791128587095.jpg';
import equipmentPressureImg from '@/src/assets/images/equipment_pressure_washer_1791128602052.jpg';
import loadingUnloadingImage from '@/src/assets/images/loading_unloading_service_1791130066024.jpg';
import treePruningImage from '@/src/assets/images/tree_pruning_felling_1791257543871.jpg';

export interface TreePruningPackage {
  id: string;
  title: string;
  category: string;
  startingPrice: number;
  duration: string;
  badge?: string;
  crew: string;
  description: string;
  workScope: string[];
  equipmentUsed: string[];
}

export interface LoadingPackage {
  id: string;
  title: string;
  helpersCount: string;
  startingPrice: number;
  duration: string;
  badge?: string;
  description: string;
  scope: string[];
  equipmentProvided: string[];
}

export interface EquipmentItem {
  id: string;
  name: string;
  category: string;
  description: string;
  benefit: string;
  specs: string;
  image: string;
}

export interface CleaningMaterial {
  id: string;
  name: string;
  category: string;
  purpose: string;
  features: string[];
  safetyStandard: string;
  colorCode: string;
}

export interface CarWashPackage {
  id: string;
  title: string;
  shortDesc: string;
  badge?: string;
  duration: string;
  prices: {
    hatchback: number;
    sedan: number;
    csuv: number;
    suvLuxury: number;
  };
  workColumns: {
    exteriorWork: string[];
    interiorWork: string[];
    finishingWork: string[];
  };
}

export const ASSET_IMAGES = {
  hero: heroImage,
  deepHome: deepHomeImage,
  sofaCarpet: sofaCarpetImage,
  kitchenChimney: kitchenChimneyImage,
  cleaningMaterials: cleaningMaterialsImage,
  carWash: carWashCleaningImage,
  carInterior: carInteriorDetailingImage,
  eqVacuum: equipmentVacuumImg,
  eqScrubber: equipmentScrubberImg,
  eqSteam: equipmentSteamImg,
  eqPressure: equipmentPressureImg,
  loadingUnloading: loadingUnloadingImage,
  treePruning: treePruningImage,
};

export const INITIAL_SERVICES: ServiceItem[] = [
  {
    id: 'full-home-deep',
    name: 'Full Home Deep Cleaning',
    category: 'full_home',
    shortDesc: 'Comprehensive floor-to-ceiling sanitization and deep scrubbing of all rooms.',
    fullDesc: 'Our flagship full home deep cleaning tackles hidden grime, grease, hard water deposits, high ceiling fans, cobwebs, and sanitizes all bathrooms, bedrooms, living spaces, and kitchen with hospital-grade, eco-friendly agents.',
    startingPrice: 999,
    duration: '4 - 6 Hours',
    rating: 4.9,
    reviewsCount: 420,
    image: deepHomeImage,
    features: ['3 to 5 trained professionals', 'Industrial vacuum & single disc scrubber', 'Chemical sanitization included', 'Cobweb and fan de-dusting'],
    includes: ['Deep floor scrubbing and buffing', 'Bathroom descaling & tile grout cleaning', 'Kitchen slab, cabinets & backsplash degreasing', 'Balcony wash & window track vacuuming', 'Door, switchboard, mirror polishing'],
    equipmentUsed: ['Industrial Wet & Dry Vacuum', 'High Speed Floor Scrubber', 'Steam Jet Sanitizer', 'Microfiber Glass Applicators']
  },
  {
    id: 'apartment-cleaning',
    name: 'Apartment Cleaning',
    category: 'full_home',
    shortDesc: 'Tailored deep scrubbing and dust removal for modern residential flats.',
    fullDesc: 'Specially engineered for residential flats and apartments. We eliminate urban pollution dust, balcony soot, bathroom mineral stains, and sanitize common family zones.',
    startingPrice: 999,
    duration: '3 - 5 Hours',
    rating: 4.8,
    reviewsCount: 310,
    image: deepHomeImage,
    features: ['Customized for 1 to 4 BHK', 'Eco-safe surface disinfectants', 'Dust allergy safe filtration'],
    includes: ['All rooms vacuuming and wet mopping', 'Bathroom fixtures & ceramic disinfection', 'Kitchen countertops & sink polishing', 'Wardrobe and exterior cabinet wipe-down'],
    equipmentUsed: ['Canister Vacuum Cleaner', 'Steam Cleaner', 'Specialized Scrubber Pads']
  },
  {
    id: 'bungalow-duplex',
    name: 'Bungalow / Duplex Cleaning',
    category: 'full_home',
    shortDesc: 'Multi-story specialized deep cleaning for villas, duplexes and bungalows.',
    fullDesc: 'Heavy-duty multi-specialist crew for large properties. Includes double-height ceiling dusting, grand staircase scrubbing, exterior glass facade cleaning, terrace, and porch.',
    startingPrice: 3499,
    duration: '6 - 8 Hours',
    rating: 4.9,
    reviewsCount: 185,
    image: deepHomeImage,
    features: ['Dedicated supervisor on-site', 'High-pressure wash for exterior porches', 'Double height ceiling extension kit'],
    includes: ['All floors, bedrooms, bathrooms & halls', 'Staircase railings & step scrubbing', 'Terrace & driveway jet spray', 'Chandelier and high fixture de-dusting'],
    equipmentUsed: ['High Pressure Washer', 'Commercial Vacuum Systems', 'Extension Poles & Ladders']
  },
  {
    id: 'room-cleaning',
    name: 'Room Cleaning (Single Room)',
    category: 'rooms',
    shortDesc: 'Complete deep clean of an individual bedroom or study room.',
    fullDesc: 'Ideal for tenants, guests, or seasonal refresh. Complete dusting of wardrobe exteriors, ceiling fans, under-bed vacuuming, floor wet scrubbing, and switchboard cleaning.',
    startingPrice: 399,
    duration: '45 - 60 Mins',
    rating: 4.8,
    reviewsCount: 220,
    image: heroImage,
    features: ['Single room quick booking', 'Under-bed dust extraction', 'Fan & light fixture wipe-down'],
    includes: ['Fan blades & AC filter dry dusting', 'Floor washing & disinfection', 'Mirror & glass window cleaning', 'Furniture surface polishing'],
    equipmentUsed: ['Dry Vacuum Cleaner', 'Microfiber Dusting Mop', 'Neutral pH Floor Cleaner']
  },
  {
    id: 'living-room-cleaning',
    name: 'Living Room Cleaning',
    category: 'rooms',
    shortDesc: 'Pristine guest-ready cleaning of your primary living and TV lounge.',
    fullDesc: 'Restore the shine of your showcase room. Thorough vacuuming of sofa crevices, TV console wipe-down, coffee table cleaning, chandelier dusting, and floor buffing.',
    startingPrice: 499,
    duration: '1.5 Hours',
    rating: 4.9,
    reviewsCount: 195,
    image: heroImage,
    features: ['TV cabinet & electronics dusting', 'Showpiece careful cleaning', 'Floor high-shine finish'],
    includes: ['Sofa surface vacuuming', 'Curtain de-dusting', 'Glass center table buffing', 'Baseboard & door frame wiping'],
    equipmentUsed: ['HEPA Vacuum Cleaner', 'Anti-static Cloths', 'Wood & Glass Cleaners']
  },
  {
    id: 'bedroom-cleaning',
    name: 'Bedroom Deep Cleaning',
    category: 'rooms',
    shortDesc: 'Hygienic dust-mite sanitization for peaceful, fresh sleeping spaces.',
    fullDesc: 'Intensive dusting and sanitization of master and guest bedrooms. Mattress vacuuming, wardrobe exterior cleaning, mirror polishing, and odor elimination.',
    startingPrice: 449,
    duration: '1 Hour',
    rating: 4.8,
    reviewsCount: 160,
    image: heroImage,
    features: ['Mattress allergen vacuuming', 'Wardrobe top dust removal', 'Pleasant botanical scenting'],
    includes: ['Bed frame and headboard dusting', 'Bedside table & drawer cleaning', 'Floor scrubbing with germicide', 'Window pane wiping'],
    equipmentUsed: ['Anti-mite Vacuum', 'Disinfectant Fogger', 'Microfiber Kits']
  },
  {
    id: 'kitchen-cleaning',
    name: 'Kitchen Deep Cleaning',
    category: 'kitchen_bath',
    shortDesc: 'Removal of stubborn grease, oil stains, burnt residue and grime.',
    fullDesc: 'Commercial grease-dissolving treatment for exhaust fans, gas stove, tile backsplashes, chimney exterior, countertop, sink drain, and cabinet outer surfaces.',
    startingPrice: 499,
    duration: '2 - 3 Hours',
    rating: 4.9,
    reviewsCount: 540,
    image: kitchenChimneyImage,
    features: ['Food-grade degreasing agents', 'Burner carbon removal', 'Sink sanitization & drain declog'],
    includes: ['Stove, platform & tile descaling', 'Exhaust fan deep cleaning', 'Exterior cabinet oil removal', 'Floor washing with heavy-duty cleaner'],
    equipmentUsed: ['Steam Jet Washer', 'Non-scratch Scrub Pads', 'Alkaline Degreasers']
  },
  {
    id: 'bathroom-cleaning',
    name: 'Bathroom Deep Cleaning',
    category: 'kitchen_bath',
    shortDesc: 'Complete hard water stain removal, toilet sanitization & grout scrubbing.',
    fullDesc: 'Eliminates yellow tile stains, limescale on chrome taps, water marks on shower cubicles, and sanitizes toilet commode and washbasin to a sparkling finish.',
    startingPrice: 299,
    duration: '1 - 1.5 Hours',
    rating: 4.9,
    reviewsCount: 680,
    image: deepHomeImage,
    features: ['Acid-free safe descaling chemicals', 'Tap & shower chrome buffing', '99.9% germ elimination'],
    includes: ['Commode inside & rim sanitization', 'Tile wall & floor scrubbing', 'Mirror & glass divider cleaning', 'Drain cover cleaning & deodorization'],
    equipmentUsed: ['High Pressure Steam Jet', 'Rotary Tile Brush', 'Limescale Dissolver']
  },
  {
    id: 'sofa-cleaning',
    name: 'Sofa Deep Cleaning & Shampoo',
    category: 'furniture_fabric',
    shortDesc: 'Deep fabric extraction, spot stain removal, and sanitization.',
    fullDesc: 'Injection-extraction shampoo machine washes out deep sweat stains, pet odor, food spills, and dust mites. Dries fast and leaves fabrics soft and fresh.',
    startingPrice: 399,
    duration: '1 - 2 Hours',
    rating: 4.9,
    reviewsCount: 512,
    image: sofaCarpetImage,
    features: ['Fabric-safe foam shampooing', 'Deep vacuum suction drying', 'Color-safe formula'],
    includes: ['Dry vacuuming for loose debris', 'Stain spot treatment', 'Mechanical foam brush scrub', 'High-suction water extraction'],
    equipmentUsed: ['Upholstery Injection Extractor', 'Foam Applicator', 'Fabric Stain Neutralizer']
  },
  {
    id: 'carpet-cleaning',
    name: 'Carpet & Rug Shampooing',
    category: 'furniture_fabric',
    shortDesc: 'Restores vibrant colors and pulls out buried dirt from deep pile carpets.',
    fullDesc: 'Heavy-duty extraction cleaning for Persian rugs, shaggy carpets, and office flooring. Removes trapped mud, pet hair, allergen dust, and stale odors.',
    startingPrice: 399,
    duration: '1 - 1.5 Hours',
    rating: 4.8,
    reviewsCount: 290,
    image: sofaCarpetImage,
    features: ['Gentle on wool and silk blends', 'Fast drying extraction', 'Pet odor neutralization'],
    includes: ['Power beater vacuuming', 'Enzymatic shampoo scrubbing', 'Deep water rinsing & suction', 'Fringe grooming and pile alignment'],
    equipmentUsed: ['Carpet Extractor Machine', 'Rotary Carpet Brush', 'Mild Botanical Shampoo']
  },
  {
    id: 'mattress-cleaning',
    name: 'Mattress Sanitization & Cleaning',
    category: 'furniture_fabric',
    shortDesc: 'Kills dust mites, dead skin buildup, sweat marks and bed bacteria.',
    fullDesc: 'Medical-grade UV sanitization and dry steam extraction to neutralize allergens, sweat stains, and bacteria inside double and single mattresses.',
    startingPrice: 399,
    duration: '45 - 60 Mins',
    rating: 4.8,
    reviewsCount: 210,
    image: heroImage,
    features: ['Dust mite elimination', 'Stain lightening treatment', 'Anti-bacterial spray'],
    includes: ['Dual-sided vacuuming', 'Stain lifting treatment', 'Steam disinfection', 'Sanitizing mist finish'],
    equipmentUsed: ['UV-C Vacuum Cleaner', 'Steam Disinfector', 'Odor Neutralizer']
  },
  {
    id: 'dining-table-cleaning',
    name: 'Dining Table & Chair Cleaning',
    category: 'furniture_fabric',
    shortDesc: 'Glass/wood conditioning and cushioned chair fabric shampooing.',
    fullDesc: 'Complete restoration of dining furniture. We shampoo padded dining chairs, clean food grease from chair legs, and polish wooden/marble/glass tabletop.',
    startingPrice: 299,
    duration: '45 Mins',
    rating: 4.7,
    reviewsCount: 140,
    image: sofaCarpetImage,
    features: ['Chairs foam wash', 'Food stain removal', 'Table polish & buff'],
    includes: ['Chair upholstery shampooing', 'Table legs & base degreasing', 'Tabletop mirror shine wipe', 'Foot cap dirt removal'],
    equipmentUsed: ['Handheld Upholstery Machine', 'Microfiber Wax Buffers']
  },
  {
    id: 'furniture-cleaning',
    name: 'Furniture Polishing & Cleaning',
    category: 'furniture_fabric',
    shortDesc: 'Protective cleaning and wood/laminate conditioning for home furniture.',
    fullDesc: 'Dust removal, surface conditioning, and grime elimination for coffee tables, credenzas, wardrobes, bookshelves, and study desks.',
    startingPrice: 349,
    duration: '1 Hour',
    rating: 4.8,
    reviewsCount: 115,
    image: heroImage,
    features: ['Wood conditioning oil', 'Scratch-safe microfiber', 'Laminate grime remover'],
    includes: ['Internal/external dust removal', 'Handle and metal accent polishing', 'Protective wax sheen application'],
    equipmentUsed: ['Microfiber Pads', 'Wood Conditioner', 'Anti-static Spray']
  },
  {
    id: 'floor-cleaning',
    name: 'Machine Floor Scrubbing & Polishing',
    category: 'specialized',
    shortDesc: 'High-speed rotary disc scrubber for gleaming marble, granite and vitrified tiles.',
    fullDesc: 'Removes deep ingrained foot grime, construction wax, and discolored grouting using single-disc rotary scrubbers with specialized diamond pads.',
    startingPrice: 499,
    duration: '1.5 - 2 Hours',
    rating: 4.9,
    reviewsCount: 275,
    image: deepHomeImage,
    features: ['Single-disc rotary scrubber', 'Restores natural tile shine', 'Tile grout line whitening'],
    includes: ['Chemical solution dispersal', 'High-RPM mechanical scrub', 'Wet vacuum slurry suction', 'Buffing with dry microfiber pad'],
    equipmentUsed: ['Single Disc Floor Scrubber', 'Wet Vacuum Collector', 'Neutral Stone Shampoo']
  },
  {
    id: 'window-glass-cleaning',
    name: 'Window & Glass Deep Cleaning',
    category: 'specialized',
    shortDesc: 'Crystal clear streak-free glass panes, window tracks and sliding frames.',
    fullDesc: 'We clean high sliding glass doors, window panes, exterior dust screens, and extract hard debris packed in sliding aluminum tracks.',
    startingPrice: 199,
    duration: '45 Mins',
    rating: 4.8,
    reviewsCount: 195,
    image: deepHomeImage,
    features: ['Streak-free glass shine', 'Sliding track debris vacuuming', 'Mosquito mesh wash'],
    includes: ['Track brushing & vacuuming', 'Glass washer squeegee technique', 'Rubber bead wiping', 'Mesh screen water wash'],
    equipmentUsed: ['Rubber Squeegee Blades', 'Track Detail Vacuum Nozzle', 'Glass Gleam Concentrate']
  },
  {
    id: 'balcony-cleaning',
    name: 'Balcony & Utility Area Cleaning',
    category: 'specialized',
    shortDesc: 'Washing off pigeon droppings, moss, balcony railings and drain areas.',
    fullDesc: 'Deep outdoor wash for balconies and utility terraces. Removes rainwater stains, bird droppings, plant pot moss, and washes steel/glass railings.',
    startingPrice: 299,
    duration: '45 Mins',
    rating: 4.8,
    reviewsCount: 165,
    image: deepHomeImage,
    features: ['Pigeon mess sanitization', 'Drain grate clearing', 'Railing wipe-down'],
    includes: ['Floor wet scrub with disinfectant', 'Railing and grill dusting', 'Glass railing streak-free polish', 'Drain pipe flushing'],
    equipmentUsed: ['Pressure Spray Washer', 'Stiff Bristle Brushes', 'Bleach-safe Biocides']
  },
  {
    id: 'office-cleaning',
    name: 'Office & Commercial Deep Cleaning',
    category: 'specialized',
    shortDesc: 'Professional sanitization for startups, clinics, shops and corporate offices.',
    fullDesc: 'Weekend or after-hours commercial deep cleaning. Covers workstation cubicles, executive chairs, server rooms, conference tables, pantry, and restrooms.',
    startingPrice: 1499,
    duration: '3 - 5 Hours',
    rating: 4.9,
    reviewsCount: 140,
    image: deepHomeImage,
    features: ['Flexible after-hours scheduling', 'GST invoice provided', 'Multi-crew efficiency'],
    includes: ['Workstation desk sanitization', 'Office rolling chair shampooing', 'Pantry sink & fridge cleaning', 'Restroom thorough disinfection'],
    equipmentUsed: ['Commercial Floor Machine', 'HEPA Filtration Vacuums', 'Surface Sanitizers']
  },
  {
    id: 'move-in-cleaning',
    name: 'Move-in Deep Cleaning',
    category: 'full_home',
    shortDesc: 'Prepare a 100% sanitized, fresh and spotless home before your family moves in.',
    fullDesc: 'Ensure your new home is free from previous tenant germs and paint dust. Full sanitization of cabinets, wardrobes, kitchen shelves, bathrooms, and polished floors.',
    startingPrice: 1299,
    duration: '4 - 6 Hours',
    rating: 4.9,
    reviewsCount: 320,
    image: deepHomeImage,
    features: ['Cabinet inside/outside wiping', 'Complete disinfection', 'Ready-to-occupy guarantee'],
    includes: ['Every wardrobe and drawer shelf clean', 'Bathroom deep descaling', 'Kitchen storage sanitization', 'Door, frame and electrical socket wiping'],
    equipmentUsed: ['Complete Commercial Cleaning Arsenal']
  },
  {
    id: 'move-out-cleaning',
    name: 'Move-out Cleaning (Security Deposit Back)',
    category: 'full_home',
    shortDesc: 'Leave the rented property in pristine condition to get your full deposit returned.',
    fullDesc: 'Thorough cleaning aimed at passing stringent landlord inspections. Removes scuff marks, kitchen yellow oil spots, bathroom scales, and cleans all floor areas.',
    startingPrice: 1199,
    duration: '4 - 5 Hours',
    rating: 4.8,
    reviewsCount: 280,
    image: deepHomeImage,
    features: ['Deposit-guarantee checklist', 'Wall scuff mark gentle wipe', 'Appliance exterior cleaning'],
    includes: ['Deep floor wash', 'Kitchen degrease', 'Bathroom lime cleanup', 'Balcony and window cleanup'],
    equipmentUsed: ['Steam Machines', 'Scrubbers', 'Specialized Detergents']
  },
  {
    id: 'post-construction',
    name: 'Post-Construction Deep Cleaning',
    category: 'specialized',
    shortDesc: 'Eliminates cement splatters, paint drops, plaster dust and adhesive residue.',
    fullDesc: 'Heavy-duty post-renovation cleanup. We safely remove stubborn paint drops from tiles and window glass, extract fine cement dust from crevices, and polish all surfaces.',
    startingPrice: 2199,
    duration: '5 - 7 Hours',
    rating: 4.9,
    reviewsCount: 175,
    image: deepHomeImage,
    features: ['Paint and adhesive scraper tools', 'Multi-stage fine dust vacuuming', 'Heavy-duty residue removers'],
    includes: ['Glass & tile paint scraper treatment', 'Ceiling and wall dry dusting', 'Switchboard and hinge cleaning', 'Floor machine scrub and slurry vacuum'],
    equipmentUsed: ['Industrial 3-Motor Vacuum', 'Floor Scrubber', 'Brass Scraper Blades']
  },
  {
    id: 'water-tank-cleaning',
    name: 'Underground & Overhead Water Tank Cleaning',
    category: 'specialized',
    shortDesc: '6-stage mechanized cleaning and UV sanitization for safe drinking water.',
    fullDesc: 'Scientific 6-step water tank cleaning: sludge de-watering, high-pressure rotary washing, vacuum slurry removal, anti-bacterial spray, and UV germicidal lamp treatment.',
    startingPrice: 799,
    duration: '2 Hours',
    rating: 4.9,
    reviewsCount: 220,
    image: deepHomeImage,
    features: ['6-stage scientific process', 'UV germicidal sterilization', 'Zero harsh chlorine odor'],
    includes: ['Submersible pump dewatering', 'High-pressure wall descaling', 'Slurry vacuum suction', 'UV lamp disinfection'],
    equipmentUsed: ['Submersible Slurry Pump', 'Pressure Jet (150 Bar)', 'UV Sterilizer Lamp']
  },
  {
    id: 'kitchen-chimney-cleaning',
    name: 'Kitchen Chimney Deep Cleaning',
    category: 'appliances',
    shortDesc: 'Dismantling baffle filters, motor oil tray degreasing, and carbon removal.',
    fullDesc: 'We remove heavy black sticky oil deposits from baffle/cassette filters, clean inner housing, degrease oil collector cup, and restore maximum exhaust suction.',
    startingPrice: 499,
    duration: '1 - 1.5 Hours',
    rating: 4.9,
    reviewsCount: 390,
    image: kitchenChimneyImage,
    features: ['Filter dip-bath chemical degreasing', 'Suction power test', 'Exterior body buffing'],
    includes: ['Filter removal and hot caustic wash', 'Oil tray deep cleanup', 'Blower exterior wipe', 'Stainless steel polish'],
    equipmentUsed: ['Immersion Tank Degreaser', 'Steam Nozzle', 'Stainless Steel Polish']
  },
  {
    id: 'refrigerator-cleaning',
    name: 'Refrigerator Deep Cleaning',
    category: 'appliances',
    shortDesc: 'Food-safe sanitization, shelf washing, freezer defrosting, and odor removal.',
    fullDesc: 'Complete shelf removal and antibacterial washing with organic food-safe agents. Eliminates mold behind rubber door gaskets and cleans condenser coil dust.',
    startingPrice: 349,
    duration: '45 - 60 Mins',
    rating: 4.8,
    reviewsCount: 245,
    image: kitchenChimneyImage,
    features: ['Food-grade sanitizers only', 'Door gasket mold removal', 'Activated carbon deodorization'],
    includes: ['All trays & racks washed in hot water', 'Interior walls disinfected', 'Vegetable crisper sanitization', 'Exterior body buffed'],
    equipmentUsed: ['Steam Jet', 'Food-safe Quat Disinfectant', 'Microfiber Towels']
  },
  {
    id: 'washing-machine-cleaning',
    name: 'Washing Machine Cleaning & Descaling',
    category: 'appliances',
    shortDesc: 'Drum scaling removal, detergent drawer mold cleanup and lint filter clearing.',
    fullDesc: 'Dissolves hidden limescale and detergent residue from the inner and outer washing drum, cleans inlet filter valves, and deodorizes musty mildew smells.',
    startingPrice: 349,
    duration: '45 Mins',
    rating: 4.7,
    reviewsCount: 195,
    image: kitchenChimneyImage,
    features: ['Citric acid tub descaler', 'Rubber seal fungus scrub', 'Drain pump filter clean'],
    includes: ['Drum descaling cycle treatment', 'Detergent drawer soaked and scrubbed', 'Front-loader rubber door gasket wipe', 'Body wiped down'],
    equipmentUsed: ['Tub Descaling Formulation', 'Detail Brushes', 'Steam Sanitizer']
  },
  {
    id: 'ac-cleaning',
    name: 'AC Jet Pump Foam Cleaning',
    category: 'appliances',
    shortDesc: 'Deep cooling coil jet pressure wash, blower fan cleaning and antibacterial foam.',
    fullDesc: 'Improves cooling and lowers electric bills. High-pressure jet pump washes out thick dust and fungal slime from cooling fins, blower fan, and water drain tray.',
    startingPrice: 399,
    duration: '45 Mins',
    rating: 4.9,
    reviewsCount: 460,
    image: heroImage,
    features: ['Water jacket spill protection', 'High pressure jet spray', 'Antibacterial foam wash'],
    includes: ['Filter mesh wash', 'Cooling fin jet wash', 'Blower rotor fan cleaning', 'Drain pipe flushing and anti-leak check'],
    equipmentUsed: ['AC Service Washing Jacket', 'High Pressure Jet Pump', 'Coil Foam Cleaner']
  },
  {
    id: 'car-interior-cleaning',
    name: 'Car Interior Deep Shampooing',
    category: 'specialized',
    shortDesc: 'Doorstep vacuuming, seat upholstery shampoo, dashboard polish and deodorization.',
    fullDesc: 'We bring our machines to your parking spot. Complete vacuuming of foot carpets, trunk, seat shampooing, dashboard UV conditioning, and AC vent steam sanitization.',
    startingPrice: 699,
    duration: '1.5 - 2 Hours',
    rating: 4.8,
    reviewsCount: 230,
    image: sofaCarpetImage,
    features: ['Doorstep service with extension power', 'Seat shampoo & wet vacuum', 'Dashboard UV protectant'],
    includes: ['Deep floor carpet vacuuming', 'Seat stain extraction', 'Roof lining gentle wipe', 'Door panels and dashboard polish'],
    equipmentUsed: ['Wet & Dry Extractor', 'Foam Applicator', 'Leather/Vinyl Conditioner']
  },
  {
    id: 'pest-control',
    name: 'General Home Pest Control',
    category: 'specialized',
    shortDesc: 'Odorless gel & spray treatment for cockroaches, ants, spiders, and silverfish.',
    fullDesc: 'Government-approved, odorless gel baiting and spray application targeting cockroach nests, kitchen hiding spots, drain inlets, and perimeter wall crevices.',
    startingPrice: 699,
    duration: '45 - 60 Mins',
    rating: 4.8,
    reviewsCount: 380,
    image: deepHomeImage,
    features: ['100% odorless Bayer gel formula', 'Safe for children and senior citizens', '90-day protection warranty'],
    includes: ['Kitchen cabinet gel baiting', 'Drainage pipe spray treatment', 'Bathroom crevices sealing check', 'Bed & wardrobe perimeter spray'],
    equipmentUsed: ['Targeted Gel Gun Applicator', 'Manual Compression Sprayer']
  },
  {
    id: 'loading-unloading-service',
    name: 'Loading & Unloading Helpers',
    category: 'specialized',
    shortDesc: 'Trained helpers for safe house shifting, furniture lifting, truck loading and unloading.',
    fullDesc: 'Careful loading, unloading, and heavy furniture handling for residential apartments, villas, and commercial relocations. Includes heavy lifting harnesses, dollies, and floor protection.',
    startingPrice: 499,
    duration: '2 - 4 Hours',
    rating: 4.9,
    reviewsCount: 315,
    image: loadingUnloadingImage,
    features: ['Police verified strong helpers', 'Heavy lifting shoulder straps', 'Zero wall scratch guarantee', 'Punctual arrival at loading point'],
    includes: ['Heavy furniture lifting up/down stairs', 'Careful loading & stacking in truck/tempo', 'Unloading and placement in designated rooms', 'Carton box carrying & floor dolly movement'],
    equipmentUsed: ['Shoulder Lifting Straps', '4-Wheel Heavy Dollies', 'Anti-Slip Gripper Gloves', 'Stretch Film Wrap']
  },
  {
    id: 'tree-felling-pruning',
    name: 'Tree Felling & Pruning Services',
    category: 'specialized',
    shortDesc: 'Professional tree trimming, branch lopping, canopy pruning and safe tree cutting removal.',
    fullDesc: 'Expert arborist tree services for residential compounds, gardens and bungalows. Includes trimming overgrown branches touching roofs/wires, crown thinning, safe sectional tree felling and green waste cleanup.',
    startingPrice: 499,
    duration: '1 - 4 Hours',
    rating: 4.9,
    reviewsCount: 190,
    image: treePruningImage,
    features: ['Electric wire safe clearance', 'Controlled rope lowering', 'Motorized chainsaw & pole loppers', 'Complete branch debris haul-away'],
    includes: ['Hazardous branch lopping & pruning', 'Garden hedge & shrub aesthetic shaping', 'Sectional branch cutting to protect roofs', 'Leaves and green waste bundling & disposal'],
    equipmentUsed: ['Telescopic Pole Saws', 'Motorized Chainsaw', 'Safety Climbing Ropes & Harness', 'Heavy Duty Garden Pruners']
  }
];

export const ROOM_CLEANING_ITEMS: RoomCleaningItem[] = [
  {
    id: 'room-living',
    roomName: 'Living Room',
    startingPrice: 499,
    duration: '1.5 Hours',
    image: heroImage,
    includedTasks: [
      'Sofa dry vacuuming & crevice cleaning',
      'Carpet & center table dust extraction',
      'TV unit, bookshelf & entertainment console wipe',
      'Ceiling fan, chandelier & light fixture de-dusting',
      'Floor wet scrubbing & high-shine buffing',
      'Balcony glass door & window pane cleaning'
    ]
  },
  {
    id: 'room-bedroom',
    roomName: 'Master & Guest Bedroom',
    startingPrice: 449,
    duration: '1 Hour',
    image: deepHomeImage,
    includedTasks: [
      'Mattress UV vacuuming & headboard cleaning',
      'Wardrobe exterior, loft & drawer handles wiped',
      'Bedside tables, dressing mirror & lights cleaned',
      'Ceiling fan blades & AC unit exterior dusted',
      'Floor scrubbing with hospital-grade disinfectant',
      'Under-bed dust extraction with slim nozzle'
    ]
  },
  {
    id: 'room-kitchen',
    roomName: 'Modular Kitchen',
    startingPrice: 499,
    duration: '2 Hours',
    image: kitchenChimneyImage,
    includedTasks: [
      'Exhaust fan & chimney exterior degreasing',
      'Gas stove, knobs & back-splash tile scrub',
      'Granite / quartz platform stain removal',
      'Stainless steel sink descaling & drain flush',
      'Cabinet outer door panels oil removal',
      'Heavy-duty floor grease stripping wash'
    ]
  },
  {
    id: 'room-bathroom',
    roomName: 'Bathroom & Toilet',
    startingPrice: 299,
    duration: '1 Hour',
    image: deepHomeImage,
    includedTasks: [
      'Acid-free chemical descaling of wall tiles',
      'Toilet bowl, rim & seat disinfection',
      'Washbasin, tap & shower head chrome polish',
      'Mirror & glass shower partition streak-free wipe',
      'Floor scrubbing & drain blockage cleaning',
      'Long-lasting anti-microbial deodorization'
    ]
  },
  {
    id: 'room-dining',
    roomName: 'Dining Room',
    startingPrice: 349,
    duration: '45 Mins',
    image: sofaCarpetImage,
    includedTasks: [
      'Dining table glass/wood surface polish',
      'Dining chairs fabric vacuuming / wipe',
      'Crockery unit glass & woodwork cleaning',
      'Floor mopping with germicidal fragrance',
      'Overhead dining pendant light dusting',
      'Door frame and switchboard wipe'
    ]
  },
  {
    id: 'room-balcony',
    roomName: 'Balcony & Utility Area',
    startingPrice: 299,
    duration: '45 Mins',
    image: deepHomeImage,
    includedTasks: [
      'Balcony floor washing with detergent scrub',
      'Pigeon droppings removal & sanitization',
      'Railing (steel, iron or glass) wipe-down',
      'Sliding track dust removal with vacuum',
      'Utility sink & washing machine bay scrub',
      'Drain channel clearing and odor spray'
    ]
  }
];

export const CATALOG_ITEMS: CatalogItem[] = [
  { id: 'cat-sofa', name: 'Sofa Set', cleaningType: 'Fabric Shampoo & Vacuum', startingPrice: 399, iconName: 'Armchair' },
  { id: 'cat-carpet', name: 'Carpet & Rug', cleaningType: 'Deep Wet Extraction', startingPrice: 399, iconName: 'Layers' },
  { id: 'cat-mattress', name: 'Mattress', cleaningType: 'UV Sanitization & Steam', startingPrice: 399, iconName: 'BedDouble' },
  { id: 'cat-dining', name: 'Dining Table', cleaningType: 'Polishing & Sanitizing', startingPrice: 299, iconName: 'Utensils' },
  { id: 'cat-chair', name: 'Dining / Accent Chair', cleaningType: 'Fabric Foam Wash', startingPrice: 99, iconName: 'Armchair' },
  { id: 'cat-office-chair', name: 'Office Ergonomic Chair', cleaningType: 'Deep Shampoo & Castor Clean', startingPrice: 149, iconName: 'Briefcase' },
  { id: 'cat-curtains', name: 'Curtains & Blinds', cleaningType: 'On-site Steam De-dusting', startingPrice: 199, iconName: 'Sparkles' },
  { id: 'cat-bed', name: 'Bed Frame & Storage', cleaningType: 'Dusting & Sanitization', startingPrice: 249, iconName: 'Bed' },
  { id: 'cat-wardrobe', name: 'Wardrobe (Ext + Loft)', cleaningType: 'Surface Buffing', startingPrice: 249, iconName: 'Archive' },
  { id: 'cat-tvunit', name: 'TV Unit & Console', cleaningType: 'Delicate Electronics Wipe', startingPrice: 199, iconName: 'Tv' },
  { id: 'cat-bookshelf', name: 'Bookshelf & Showcases', cleaningType: 'Dust Extraction & Wipe', startingPrice: 199, iconName: 'BookOpen' },
  { id: 'cat-platform', name: 'Kitchen Countertop', cleaningType: 'Grease & Stain Stripping', startingPrice: 199, iconName: 'ChefHat' },
  { id: 'cat-cabinets', name: 'Kitchen Cabinets', cleaningType: 'Oil & Sticky Slime Removal', startingPrice: 349, iconName: 'Folder' },
  { id: 'cat-chimney', name: 'Kitchen Chimney', cleaningType: 'Filter Bath & Degrease', startingPrice: 499, iconName: 'Flame' },
  { id: 'cat-sink', name: 'Kitchen Sink', cleaningType: 'Limescale Buff & Drain Clean', startingPrice: 149, iconName: 'Droplets' },
  { id: 'cat-tiles', name: 'Bathroom Tiles', cleaningType: 'Machine Rotary Scrub', startingPrice: 249, iconName: 'Grid' },
  { id: 'cat-toilet', name: 'Toilet Commode', cleaningType: 'Disinfection & Rim Descaling', startingPrice: 199, iconName: 'CheckCircle' },
  { id: 'cat-basin', name: 'Wash Basin & Vanity', cleaningType: 'Limescale & Chrome Polish', startingPrice: 149, iconName: 'Smile' },
  { id: 'cat-mirror', name: 'Mirrors & Glass Panels', cleaningType: 'Streak-Free Buffing', startingPrice: 99, iconName: 'Maximize' },
  { id: 'cat-windows', name: 'Windows & Sliding Tracks', cleaningType: 'Track Vac & Glass Gleam', startingPrice: 199, iconName: 'Sliders' },
  { id: 'cat-glassdoor', name: 'Glass Doors & Partitions', cleaningType: 'Water Mark Descaling', startingPrice: 249, iconName: 'DoorClosed' },
  { id: 'cat-floor', name: 'Floor Tiles / Marble', cleaningType: 'Rotary Single Disc Scrub', startingPrice: 499, iconName: 'Columns' },
  { id: 'cat-balcony', name: 'Balcony Floor & Grills', cleaningType: 'High Pressure Water Wash', startingPrice: 299, iconName: 'Sun' },
  { id: 'cat-stairs', name: 'Staircase Steps & Railings', cleaningType: 'Step Scrub & Rail Polish', startingPrice: 349, iconName: 'Activity' },
  { id: 'cat-refrigerator', name: 'Refrigerator', cleaningType: 'Defrost & Food-safe Wash', startingPrice: 349, iconName: 'Box' },
  { id: 'cat-washing-mach', name: 'Washing Machine', cleaningType: 'Tub Descaling & Drum Sanitizing', startingPrice: 349, iconName: 'RotateCw' },
  { id: 'cat-ac', name: 'Split / Window AC', cleaningType: 'Jet Pump Foam Cleaning', startingPrice: 399, iconName: 'Wind' },
  { id: 'cat-watertank', name: 'Water Storage Tank', cleaningType: '6-Stage UV Sanitization', startingPrice: 799, iconName: 'Shield' }
];

export const PROFESSIONAL_EQUIPMENT: EquipmentItem[] = [
  {
    id: 'eq-vacuum',
    name: 'Industrial Wet & Dry Vacuum',
    category: 'Dust & Slurry Extraction',
    description: 'Twin-motor heavy suction system capable of pulling out deep allergen dust, pet dander and liquid slurries without aerosolizing particles.',
    benefit: 'Eliminates 99.8% embedded microscopic dust from sofa padding and carpet pile.',
    specs: '2400W Dual Motor · 60L Stainless Steel Drum',
    image: equipmentVacuumImg
  },
  {
    id: 'eq-scrubber',
    name: 'Single-Disc High Speed Floor Scrubber',
    category: 'Tile & Stone Polishing',
    description: 'Rotary planetary drive with nylon brushes and diamond polishing pads to strip away years of stained grime and wax buildup on tiles and marble.',
    benefit: 'Restores natural factory gloss to dull vitrified tiles and marble floors.',
    specs: '175 RPM High Torque · Weight Loaded Disc',
    image: equipmentScrubberImg
  },
  {
    id: 'eq-steam',
    name: 'Commercial Steam Jet Sanitizer',
    category: 'Chemical-Free Sterilization',
    description: 'Produces high-temperature 140°C dry saturated steam to dissolve hardened kitchen grease, kill bathroom mold spores, and eliminate bacteria.',
    benefit: 'Kills 99.99% germs and dissolves stuck grease without toxic fumes.',
    specs: '140°C Pressurized Steam · 4.5 Bar Output',
    image: equipmentSteamImg
  },
  {
    id: 'eq-pressure',
    name: 'High Pressure Water Jet Cleaner',
    category: 'Balcony & Exterior Washing',
    description: 'Controlled variable-pressure jet to blast away stubborn pigeon droppings, terrace algae, moss, and window track soil.',
    benefit: 'Cleans exterior surfaces 5x faster using 70% less water than hoses.',
    specs: '140 Bar Max · Adjustable Fan & Pencil Nozzles',
    image: equipmentPressureImg
  },
  {
    id: 'eq-upholstery',
    name: 'Injection-Extraction Upholstery Machine',
    category: 'Sofa & Fabric Wash',
    description: 'Injects biodegradable shampoo deep into fabric foam and simultaneously vacuums out suspended grime into an isolated dirty water chamber.',
    benefit: 'Fabric dries in 2-3 hours without waterlogging or mildew risk.',
    specs: 'Twin Pressure Jets · Powerful Dual Vacuum',
    image: equipmentVacuumImg
  },
  {
    id: 'eq-window',
    name: 'Microfiber Streak-Free Window Applicator & Squeegee',
    category: 'Glass Finishing',
    description: 'Professional Unger German-engineered squeegee blades and microfiber sleeves leaving glass completely transparent without water marks.',
    benefit: 'Zero streaks, zero scratching on architectural window films.',
    specs: 'Soft Vulcanized Rubber Blade · Telescopic Extension',
    image: cleaningMaterialsImage
  },
  {
    id: 'eq-sprayer',
    name: 'Hospital-Grade Eco Disinfectant Sprayers',
    category: 'Hygiene & Sanitization',
    description: 'Electrostatically charged misting sprayers dispersing child-safe, pet-safe quaternary ammonium sanitizers on all touch surfaces.',
    benefit: 'Non-corrosive, non-toxic, government approved formulation.',
    specs: 'Ultra-Fine Micron Droplets · Safe on Polished Wood',
    image: equipmentSteamImg
  },
  {
    id: 'eq-ppe',
    name: 'Safety & PPE Equipment',
    category: 'Technician Protection & Safety',
    description: 'Every PURE CLEANING verified technician wears clean company polo uniforms, shoe covers, nitrile safety gloves, and protective eyewear.',
    benefit: 'Ensures 100% hygienic presence in your private home sanctuary.',
    specs: 'Disposable Shoe Covers · Food-grade Nitrile Gloves',
    image: heroImage
  }
];

export const BEFORE_AFTER_CASES: BeforeAfterCase[] = [
  {
    id: 'case-sofa',
    title: 'Fabric Sofa Stain Extraction',
    subtitle: 'Tea spill, sweat darkening & pet stains completely removed',
    beforeDesc: 'Heavy brown tea stains, dull faded gray fabric, sweat spots on armrests.',
    afterDesc: 'Restored vibrant original color, 100% stain lifted, fresh citrus scent.',
    serviceName: 'Sofa Deep Shampooing',
    timeTaken: '75 Minutes',
    beforeTag: 'Before: Stained & Dull',
    afterTag: 'After: Fresh & Spotless',
    beforeBg: 'from-amber-950/60 to-stone-900',
    afterBg: 'from-emerald-950/60 to-slate-900'
  },
  {
    id: 'case-kitchen',
    title: 'Modular Kitchen Chimney & Backsplash',
    subtitle: 'Sticky yellow cooking oil residue dissolved to bare stainless steel',
    beforeDesc: 'Thick sticky grease coating on filters, brownish oil stains on tile grout.',
    afterDesc: 'Mirror-finish stainless steel, squeaky clean tiles, zero oily stickiness.',
    serviceName: 'Kitchen Deep Degreasing',
    timeTaken: '2 Hours',
    beforeTag: 'Before: Sticky Oil Slime',
    afterTag: 'After: Squeaky Clean',
    beforeBg: 'from-yellow-950/60 to-stone-900',
    afterBg: 'from-teal-950/60 to-slate-900'
  },
  {
    id: 'case-bathroom',
    title: 'Hard Water Bathroom Descaling',
    subtitle: 'Limescale etched tiles & dull chrome taps restored to sparkle',
    beforeDesc: 'Chalky white mineral scale on black tiles, clouded glass, corroded tap finish.',
    afterDesc: 'Gleaming chrome faucets, crystal clear glass, vibrant deep tile color.',
    serviceName: 'Bathroom Descaling',
    timeTaken: '90 Minutes',
    beforeTag: 'Before: Hard Water Scale',
    afterTag: 'After: Brilliant Shine',
    beforeBg: 'from-zinc-800 to-slate-950',
    afterBg: 'from-cyan-950/60 to-slate-900'
  },
  {
    id: 'case-carpet',
    title: 'Living Room Persian Rug Shampooing',
    subtitle: 'Buried dust, coffee marks & food crumbs extracted',
    beforeDesc: 'Matted pile, hidden dust clouds when walked on, faded pattern definition.',
    afterDesc: 'Fluffy raised pile, vivid contrast, 100% dust-mite allergen free.',
    serviceName: 'Carpet Machine Extraction',
    timeTaken: '60 Minutes',
    beforeTag: 'Before: Matted & Dusty',
    afterTag: 'After: Fluffy & Restored',
    beforeBg: 'from-amber-950/70 to-stone-900',
    afterBg: 'from-blue-950/60 to-slate-900'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Priya Sharma',
    location: 'Sector 48, Gurgaon',
    rating: 5,
    service: 'Full Home Deep Cleaning (3 BHK)',
    date: '3 days ago',
    comment: 'Excellent cleaning service! The team arrived on time with huge professional vacuum cleaners and scrubbers. My entire 3 BHK looks like a newly handed-over flat. Best ₹1,999 ever spent!'
  },
  {
    id: 'test-2',
    name: 'Rahul Kulkarni',
    location: 'Whitefield, Bengaluru',
    rating: 5,
    service: 'Sofa & Carpet Cleaning',
    date: '1 week ago',
    comment: 'Very professional team and honest pricing. Other companies quoted double. The technician Vikky did an unbelievable job on our beige 5-seater sofa. All old chai stains are gone.'
  },
  {
    id: 'test-3',
    name: 'Neha Mehta',
    location: 'Andheri West, Mumbai',
    rating: 5,
    service: 'Kitchen Chimney & Bathroom Deep Clean',
    date: '2 weeks ago',
    comment: 'Booked on WhatsApp within 2 minutes. The kitchen exhaust fan and chimney had thick sticky oil that refused to budge with regular wiping. PURE CLEANING made it look brand new.'
  },
  {
    id: 'test-4',
    name: 'Amitabh Sen',
    location: 'Salt Lake, Kolkata',
    rating: 5,
    service: 'Move-in Deep Cleaning (2 BHK)',
    date: '3 weeks ago',
    comment: 'Shifted into a new rented flat that was left dusty by the previous tenant. In 4 hours, their 3-member crew transformed the place. Transparent price, no hidden charges. Highly recommended!'
  }
];

export const FAQS = [
  {
    question: 'What areas do you provide cleaning services in?',
    answer: 'PURE CLEANING provides doorstep home and commercial cleaning services across all major residential sectors, apartments, gated societies, villas, and commercial complexes. You can enter your locality during booking or call +91 62043 19105 to check immediate availability.'
  },
  {
    question: 'How much does home cleaning cost? Are there hidden charges?',
    answer: 'Our pricing is 100% transparent with zero hidden fees. Single rooms start at ₹399, bathrooms at ₹299, 1 BHK deep cleaning starts at ₹999, 2 BHK at ₹1,499, 3 BHK at ₹1,999, and 4 BHK at ₹2,499. You see the final estimated price upfront before confirming.'
  },
  {
    question: 'Do you bring your own cleaning equipment and chemicals?',
    answer: 'Yes! Our professional team brings all necessary commercial equipment: industrial wet/dry vacuum cleaners, rotary floor scrubbers, steam machines, specialized descaling agents, fabric shampoo, microfiber tools, and safety gear. You only need to provide standard running water and an electrical power socket.'
  },
  {
    question: 'Are the cleaning chemicals safe for kids and pets?',
    answer: 'Absolutely. We use government-certified, biodegradable, non-toxic cleaning agents and eco-safe formulations. We do not use harsh noxious acids that damage tiles or cause choking fumes.'
  },
  {
    question: 'How long does deep cleaning take?',
    answer: 'Single room or bathroom cleaning takes about 45 to 60 minutes. A 1 BHK or 2 BHK deep cleaning typically takes 3 to 4 hours, while larger 3-4 BHK homes take 5 to 6 hours with a multi-person crew.'
  },
  {
    question: 'Can I book a single room, sofa or bathroom only?',
    answer: 'Yes! You can book individual services (like just sofa shampooing for ₹399, single bathroom for ₹299, or kitchen chimney for ₹499) without needing to book the full home package.'
  },
  {
    question: 'Can I choose my preferred date and time slot?',
    answer: 'Yes, you can pick any date up to 30 days in advance and choose convenient morning, afternoon, or evening slots: 08:00 AM, 10:00 AM, 12:00 PM, 02:00 PM, 04:00 PM, or 06:00 PM.'
  },
  {
    question: 'Can I book through WhatsApp directly?',
    answer: 'Yes! Click the green "Book on WhatsApp" button or message +91 62043 19105. Our WhatsApp desk responds in under 3 minutes with slot confirmation and special discount codes.'
  },
  {
    question: 'Can I cancel or reschedule my booking?',
    answer: 'Yes, rescheduling or cancellation is completely free of charge up to 2 hours before the scheduled time slot. Simply call or WhatsApp us at +91 62043 19105.'
  },
  {
    question: 'Do you provide commercial office and post-construction cleaning?',
    answer: 'Yes, we handle corporate office deep cleaning, showroom sanitization, clinic maintenance, and heavy-duty post-renovation cement & paint removal with specialized high-powered machinery and GST invoices.'
  },
  {
    question: 'How do I claim the ₹100 First Booking Discount?',
    answer: 'The ₹100 discount is automatically applied to all first-time bookings using promo code FIRST100 during checkout, or mention it when calling or chatting on WhatsApp (+91 62043 19105).'
  }
];

export const INITIAL_BOOKINGS: BookingRecord[] = [
  {
    id: 'TC-94821',
    customerName: 'Rohit Verma',
    phone: '+91 98112 44321',
    email: 'rohit.v@example.com',
    service: 'Full Home Deep Cleaning',
    propertyType: '3 BHK',
    date: '2026-10-05',
    timeSlot: '10:00 AM',
    address: 'Flat 402, Tower B, Palm Heights, DLF Phase 5',
    price: 1899,
    status: 'Confirmed',
    createdAt: '2026-10-04 07:15 AM',
    instructions: 'Please pay extra attention to kitchen exhaust and master bath limescale.'
  },
  {
    id: 'TC-94822',
    customerName: 'Ananya Deshmukh',
    phone: '+91 97230 19823',
    email: 'ananya.d@example.com',
    service: 'Sofa Deep Cleaning & Shampoo',
    propertyType: '5-Seater L-Shape',
    date: '2026-10-05',
    timeSlot: '02:00 PM',
    address: 'B-1204, Casa Bella, Hiranandani Estate',
    price: 699,
    status: 'Assigned',
    createdAt: '2026-10-04 06:40 AM',
    instructions: 'Light grey fabric with milk spill stain on right lounger.'
  },
  {
    id: 'TC-94823',
    customerName: 'Manish Rawat',
    phone: '+91 98450 78210',
    email: 'm.rawat92@example.com',
    service: 'Kitchen Chimney & Bathroom Deep Clean',
    propertyType: '2 BHK Flat',
    date: '2026-10-06',
    timeSlot: '08:00 AM',
    address: 'Villa 18, Green Meadows, Sarjapur Road',
    price: 798,
    status: 'New',
    createdAt: '2026-10-04 08:00 AM',
    instructions: 'Gate code 4490. Call before arriving.'
  },
  {
    id: 'TC-94819',
    customerName: 'Kavita Chawla',
    phone: '+91 98711 23091',
    email: 'kavita.c@example.com',
    service: 'Move-in Deep Cleaning',
    propertyType: '2 BHK',
    date: '2026-10-03',
    timeSlot: '12:00 PM',
    address: 'A-301, Silver Crest, Sector 62',
    price: 1399,
    status: 'Completed',
    createdAt: '2026-10-02 04:30 PM',
    instructions: 'Completed satisfactorily, customer gave 5 star feedback.'
  }
];

export const TIME_SLOTS = [
  '08:00 AM',
  '10:00 AM',
  '12:00 PM',
  '02:00 PM',
  '04:00 PM',
  '06:00 PM'
];

export const CLEANING_MATERIALS: CleaningMaterial[] = [
  {
    id: 'mat-descaler',
    name: 'Citric-Bio Bathroom Descaler',
    category: 'Bathroom Care',
    purpose: 'Hard water limescale, calcium deposits, soap scum & tap mineral crust removal.',
    features: ['100% Acid-Free (No Hydrochloric / Muriatic acid)', 'Restores chrome taps without corrosion', 'Safe on ceramic and granite tiles'],
    safetyStandard: 'Non-toxic, Zero fumes, Biodegradable',
    colorCode: 'Red (Bathroom Dedicated)'
  },
  {
    id: 'mat-degreaser',
    name: 'Organic Citrus Alkaline Degreaser',
    category: 'Kitchen Care',
    purpose: 'Deep dissolution of burnt oil, greasy chimney baffles, exhaust deposits & stove grease.',
    features: ['Food-grade organic surfactants', 'Fast emulsification of sticky grease', 'Zero toxic chemical residue on cooking slabs'],
    safetyStandard: 'Food-safe formulation, Eco-certified',
    colorCode: 'Green (Kitchen Dedicated)'
  },
  {
    id: 'mat-disinfectant',
    name: 'Hospital-Grade 5th-Gen Quat Sanitizer',
    category: 'Surface Disinfection',
    purpose: 'Kills 99.999% germs, viruses, salmonella, E. coli and fungal spores on touch points.',
    features: ['Non-bleach, non-staining', 'Safe on polished wood, brass and metals', 'Leaves subtle pleasant natural pine scent'],
    safetyStandard: 'Safe for infants, toddlers and pets',
    colorCode: 'Blue (General Living & Bedrooms)'
  },
  {
    id: 'mat-shampoo',
    name: 'Enzyme Fabric & Upholstery Foam Shampoo',
    category: 'Sofa & Fabric Care',
    purpose: 'Encapsulates dust mite allergens, sweat stains, beverage spots and pet odors in fabric.',
    features: ['pH-balanced color-safe formula', 'Low-moisture fast drying technology', 'Leaves fabric fibers soft and fluffy'],
    safetyStandard: 'Dermatologically tested, Hypoallergenic',
    colorCode: 'Yellow (Fabrics & Furnishings)'
  },
  {
    id: 'mat-microfiber',
    name: 'German High-GSM Split Microfiber System',
    category: 'Wiping & Buffing',
    purpose: 'Color-coded cross-contamination prevention protocol across all household zones.',
    features: ['4-Color zoned hygiene (Red=Bath, Green=Kitchen, Blue=Living, Yellow=Fabric)', '380 GSM ultra-dense loop fibers', 'Picks 99% bacteria using minimal water'],
    safetyStandard: 'Hospital cross-infection standard',
    colorCode: '4-Color Coded Protocol'
  },
  {
    id: 'mat-glass',
    name: 'Anti-Static Streak-Free Glass Gleam',
    category: 'Glass & Mirrors',
    purpose: 'Crystal transparent finish on architectural glass windows, shower partitions and mirrors.',
    features: ['Zero ammonia formula (safe on window tints)', 'Repels airborne dust for up to 3 weeks', 'Zero smudge streaks under bright sunlight'],
    safetyStandard: 'Ammonia-free, Eco surfactant',
    colorCode: 'Blue (Glass Specialized)'
  }
];

export const CAR_WASH_PACKAGES: CarWashPackage[] = [
  {
    id: 'car-foam-wash',
    title: 'Exterior Snow Foam Jet Wash',
    shortDesc: 'Touchless high-pressure pre-wash, thick snow foam soak, two-bucket hand wash and tire dresser.',
    badge: 'Popular Routine Care',
    duration: '35 - 45 Mins',
    prices: {
      hatchback: 299,
      sedan: 349,
      csuv: 399,
      suvLuxury: 499
    },
    workColumns: {
      exteriorWork: [
        '140-bar high pressure mud & grime rinse',
        'pH-neutral thick snow foam cannon spray',
        'Scratch-free microfiber mitt two-bucket wash',
        'Underbody & wheel arch water pressure blast',
        'Alloy rim brake dust cleaning with detail brush'
      ],
      interiorWork: [
        'Door frame & jambs pressure wipe',
        'Foot mat water blast & dry'
      ],
      finishingWork: [
        'Streak-free exterior glass microfiber dry',
        'High-gloss silicone tire dresser & shine',
        'Exterior black plastic trim conditioning'
      ]
    }
  },
  {
    id: 'car-interior-spa',
    title: 'Deep Interior Sanitization & Shampoo',
    shortDesc: 'Deep upholstery foam shampoo, trunk vacuuming, dashboard UV treatment and AC vent steam sanitization.',
    badge: 'Anti-Allergen Refresh',
    duration: '60 - 75 Mins',
    prices: {
      hatchback: 499,
      sedan: 599,
      csuv: 699,
      suvLuxury: 849
    },
    workColumns: {
      exteriorWork: [
        'Exterior glass crystal clear wipe',
        'Door jamb & boot gutter deep cleaning'
      ],
      interiorWork: [
        'Deep carpet & seat fabric high-suction vacuuming',
        'Fabric seats foam shampoo machine extraction',
        'Leather seat cleaning & nourishing conditioner',
        'Roof headliner gentle de-staining wipe',
        'Trunk & spare tire compartment vacuuming'
      ],
      finishingWork: [
        'Dashboard & console matte UV protectant dress',
        'AC vent brush de-dusting & disinfectant steam mist',
        'Long-lasting car aroma freshener spray'
      ]
    }
  },
  {
    id: 'car-360-full',
    title: 'Complete 360° Car Wash & Interior Spa',
    shortDesc: 'Our flagship bumper-to-bumper car spa: complete snow foam jet wash + deep interior shampooing & engine bay wipe.',
    badge: 'Best Value Full Spa',
    duration: '90 - 110 Mins',
    prices: {
      hatchback: 699,
      sedan: 799,
      csuv: 899,
      suvLuxury: 1099
    },
    workColumns: {
      exteriorWork: [
        'High pressure underbody & wheel arch jet blast',
        'Snow foam cannon pre-wash & hand mitt wash',
        'Alloy wheel de-grease and caliper detailing',
        'Front grille bug splatter removal',
        'Engine bay dry wipe-down and dresser'
      ],
      interiorWork: [
        'Full seat shampoo machine extraction / leather spa',
        'Deep carpet vacuuming & rubber foot mat wash',
        'Door panels, cup holders & glovebox detailing',
        'Pedal area dirt stripping & sanitization',
        'Trunk cavity deep cleaning'
      ],
      finishingWork: [
        'Liquid polymer spray wax applied on exterior paint',
        'Interior & exterior streak-free glass polish',
        'Tire jet black dressing & fiber trim restoration',
        'Botanical cabin deodorizer treatment'
      ]
    }
  },
  {
    id: 'car-ceramic-wax',
    title: 'Ceramic Gloss Wax & Deep Detailing',
    shortDesc: 'Includes full exterior wash, clay bar paint decontamination, hand-buffed carnauba/ceramic gloss wax and full interior spa.',
    badge: 'Showroom Shine',
    duration: '120 - 140 Mins',
    prices: {
      hatchback: 999,
      sedan: 1199,
      csuv: 1299,
      suvLuxury: 1499
    },
    workColumns: {
      exteriorWork: [
        'Full snow foam jet wash & underbody blast',
        'Chemical iron fallout and tar spot removal',
        'Clay bar treatment to remove rough paint grit',
        'Hand applied high-grade synthetic ceramic wax',
        'Machine microfiber buffer for deep mirror reflection'
      ],
      interiorWork: [
        'Full interior upholstery foam extraction wash',
        'Leather upholstery conditioning with lanolin balm',
        'AC duct steam sterilization (kills mold & smell)',
        'Roof lining & pillar fabric spot cleaned'
      ],
      finishingWork: [
        'Rain-repellent hydrophobic windshield coating',
        'Deep gloss tire shine and rim sealant',
        'Headlight & taillight clarity hand polish',
        '100% Doorstep convenience with our power & water equipment'
      ]
    }
  }
];

export const LOADING_PACKAGES: LoadingPackage[] = [
  {
    id: 'load-single-item',
    title: 'Single Heavy Item Moving / Shifting',
    helpersCount: '1 - 2 Dedicated Helpers',
    startingPrice: 399,
    duration: '30 - 60 Mins',
    badge: 'Quick Single Item',
    description: 'Specialized assistance to safely carry heavy individual items like double door refrigerators, washing machines, 3-seater sofas, or wooden beds via stairs or lifts.',
    scope: [
      'Staircase navigation for heavy furniture without scratching walls',
      'Corner foam guards & stretch wrap application',
      'Safe placement & leveling at new room destination',
      'Doorway clearance & disassembly support if needed'
    ],
    equipmentProvided: ['Heavy lifting body harnesses', 'Padded corner blankets', 'Anti-slip grip gloves']
  },
  {
    id: 'load-1bhk',
    title: '1 BHK Complete Home Loading & Unloading',
    helpersCount: '2 Trained Helpers',
    startingPrice: 999,
    duration: '2 - 3 Hours',
    badge: 'Most Popular for Flats',
    description: 'End-to-end loading of furniture, cartons, kitchen utensils & electronics into your moving vehicle, and careful unloading & room placement at destination.',
    scope: [
      'Complete furniture & carton loading into tempo/truck',
      'Safe arrangement & tie-down inside vehicle to prevent transit damage',
      'Unloading and moving items into respective bedrooms & kitchen',
      'Mattress and sofa careful placement on bed frame'
    ],
    equipmentProvided: ['Floor moving dollies', 'Heavy cargo ratchet belts', 'Corrugated corner protectors']
  },
  {
    id: 'load-family-home',
    title: '2 - 3 BHK Family Home Shifting Helpers',
    helpersCount: '3 - 4 Skilled Helpers + Lead',
    startingPrice: 1699,
    duration: '3.5 - 5 Hours',
    badge: 'Heavy Shifting Crew',
    description: 'Full-crew handling for standard family homes. Accommodates double beds, dining tables, wardrobes, kitchen boxes, fragile glass units and home appliances.',
    scope: [
      'Full coordination for multi-floor apartments with or without elevator',
      'Bulky wardrobe, sofa and dining table heavy lifting',
      'Fragile crockery box gentle handling and vehicle placement',
      'Room-by-room designated unloading & unpacking assistance'
    ],
    equipmentProvided: ['4-wheel heavy dollies', 'Furniture sliders', 'Heavy-duty lifting straps', 'Industrial stretch film']
  },
  {
    id: 'load-truck-tempo',
    title: 'Truck / Tempo Loading, Stacking & Unloading',
    helpersCount: '2 - 4 Helpers (As required)',
    startingPrice: 1299,
    duration: '2 - 4 Hours',
    badge: 'Commercial & Shifting',
    description: 'Efficient loading, interlocking cargo stacking, space maximization, and unloading for Tata Ace, Pickup, 14ft/17ft Canter trucks or storage units.',
    scope: [
      'Space-efficient tight stacking to ensure zero cargo shifting in transit',
      'Heavy items on floor base, lighter fragile cartons securely on top',
      'Rope / ratchet strap cargo securing',
      'Fast turnaround unloading at delivery location'
    ],
    equipmentProvided: ['Cargo securing straps', 'Ramp assistance', 'High-grip gloves & safety shoes']
  }
];

export interface LoadingItemRate {
  id: string;
  itemName: string;
  workTime: string;
  rate: number;
  category: 'Appliances' | 'Furniture' | 'Heavy Items' | 'Cartons';
  helpers: string;
}

export interface VehicleLoadingRate {
  vehicle: string;
  capacity: string;
  helpersAssigned: string;
  loadingTime: string;
  rate: number;
}

export interface HourlyShiftRate {
  planName: string;
  helpers: string;
  duration: string;
  rate: number;
  overtimePerHour: number;
}

export const HOURLY_HELPER_RATES: HourlyShiftRate[] = [
  {
    planName: 'Hourly Helper (Pay-Per-Hour)',
    helpers: '1 Helper',
    duration: 'Min. 2 Hours',
    rate: 398, // ₹199/hr * 2
    overtimePerHour: 199
  },
  {
    planName: 'Dual Helper Dynamic Team',
    helpers: '2 Helpers',
    duration: 'Min. 2 Hours',
    rate: 698, // ₹349/hr * 2
    overtimePerHour: 349
  },
  {
    planName: 'Half-Day Shift Package',
    helpers: '2 Helpers',
    duration: 'Up to 4 Hours',
    rate: 1299,
    overtimePerHour: 299
  },
  {
    planName: 'Full-Day Comprehensive Shift',
    helpers: '2 Helpers + Supervisor',
    duration: 'Up to 8 Hours',
    rate: 2299,
    overtimePerHour: 249
  }
];

export const ITEM_LOADING_RATES: LoadingItemRate[] = [
  {
    id: 'item-fridge',
    itemName: 'Double Door / Side-by-Side Refrigerator',
    workTime: '20 - 30 Mins',
    rate: 299,
    category: 'Appliances',
    helpers: '2 Helpers'
  },
  {
    id: 'item-washing',
    itemName: 'Fully Automatic Washing Machine',
    workTime: '15 - 20 Mins',
    rate: 199,
    category: 'Appliances',
    helpers: '2 Helpers'
  },
  {
    id: 'item-bed',
    itemName: 'King/Queen Bed (Dismantle + Move + Rebuild)',
    workTime: '45 - 60 Mins',
    rate: 499,
    category: 'Furniture',
    helpers: '2 Helpers'
  },
  {
    id: 'item-sofa',
    itemName: '3-Seater Sofa / L-Shape Recliner Lounger',
    workTime: '25 - 35 Mins',
    rate: 349,
    category: 'Furniture',
    helpers: '2 Helpers'
  },
  {
    id: 'item-almirah',
    itemName: '3 or 4-Door Heavy Wooden/Steel Almirah',
    workTime: '35 - 50 Mins',
    rate: 449,
    category: 'Furniture',
    helpers: '2 - 3 Helpers'
  },
  {
    id: 'item-dining',
    itemName: 'Glass/Marble 4 to 6 Seater Dining Table',
    workTime: '25 - 35 Mins',
    rate: 349,
    category: 'Furniture',
    helpers: '2 Helpers'
  },
  {
    id: 'item-tv',
    itemName: 'Large Smart TV (55"+) & Media Console',
    workTime: '20 Mins',
    rate: 249,
    category: 'Heavy Items',
    helpers: '2 Helpers'
  },
  {
    id: 'item-safe',
    itemName: 'Heavy Iron Godrej Locker / Commercial Safe',
    workTime: '40 - 50 Mins',
    rate: 699,
    category: 'Heavy Items',
    helpers: '3 - 4 Helpers'
  },
  {
    id: 'item-boxes',
    itemName: 'Batch of 10 Packed Moving Cartons / Boxes',
    workTime: '25 - 35 Mins',
    rate: 299,
    category: 'Cartons',
    helpers: '2 Helpers'
  }
];

export const VEHICLE_LOADING_RATES: VehicleLoadingRate[] = [
  {
    vehicle: 'Tata Ace / Chhota Hathi / Dost',
    capacity: 'Up to 1 BHK (750 - 1000 kg)',
    helpersAssigned: '2 Trained Helpers',
    loadingTime: '1 - 1.5 Hours',
    rate: 799
  },
  {
    vehicle: 'Mahindra Bolero Pickup / 8ft Open Body',
    capacity: '1 - 2 BHK (1200 - 1500 kg)',
    helpersAssigned: '2 - 3 Trained Helpers',
    loadingTime: '1.5 - 2 Hours',
    rate: 1199
  },
  {
    vehicle: '14ft / 17ft Eicher Canter Truck',
    capacity: '2 - 3 BHK Full House (2500 - 3500 kg)',
    helpersAssigned: '3 - 4 Skilled Helpers',
    loadingTime: '2.5 - 3.5 Hours',
    rate: 1899
  }
];

export const FLOOR_STAIRCASE_CHARGES = [
  { floor: 'Ground Floor or Working Lift Available', timeAdded: 'Standard Time', extraCost: '₹0 (Free)' },
  { floor: '1st - 2nd Floor (Staircase Only, No Lift)', timeAdded: '+20 Mins', extraCost: '+₹150' },
  { floor: '3rd - 4th Floor (Staircase Only, No Lift)', timeAdded: '+35 Mins', extraCost: '+₹300' },
  { floor: '5th Floor & Above (Staircase Only, No Lift)', timeAdded: '+50 Mins', extraCost: '+₹500' }
];

export const WORK_TIMINGS_SHIFTS = {
  regularShift: '7:00 AM – 8:00 PM (Standard Regular Rates)',
  eveningShift: '8:00 PM – 11:00 PM (+₹200 Night Shift Allowance)',
  sameDayNotice: 'Helpline Dispatch within 45 to 60 Minutes',
  cancellationPolicy: 'Free cancellation up to 2 hours before scheduled shift'
};

export const TREE_PRUNING_PACKAGES: TreePruningPackage[] = [
  {
    id: 'tree-branch-pruning',
    title: 'Branch Pruning & Overhang Trimming',
    category: 'Pruning & Trimming',
    startingPrice: 499,
    duration: '45 - 90 Mins',
    badge: 'Popular Garden Care',
    crew: '2 Arborist Crew Members',
    description: 'Trimming overgrown branches extending over roof tiles, balcony railings, electric lines or solar panels to allow sunlight and remove hazards.',
    workScope: [
      'Identification of weak, dead and overgrown tree limbs',
      'Telescopic pole saw precision cutting up to 20 feet height',
      'Electric line & window clearance check',
      'Foliage cutting into manageable logs & sweeping'
    ],
    equipmentUsed: ['Telescopic Extension Pole Saws', 'Heavy Bypass Loppers', 'Safety Helmets & Visors']
  },
  {
    id: 'tree-hedge-shaping',
    title: 'Hedge Trimming & Bush Shaping',
    category: 'Garden Aesthetics',
    startingPrice: 399,
    duration: '60 - 90 Mins',
    badge: 'Aesthetic Shaping',
    crew: '1 - 2 Garden Specialists',
    description: 'Neat leveling, boundary hedge trimming, ornamental shrub pruning, and dry foliage clearance for villas, apartment gardens and farmhouses.',
    workScope: [
      'Geometric & symmetrical hedge boundary trimming',
      'Bush crown clearing and dead branch cutting',
      'De-weeding and base clearing around tree trunk',
      'Green leaf bag collection'
    ],
    equipmentUsed: ['Motorized Hedge Trimmer', 'Manual Precision Shears', 'Garden Rakes & Leaf Tarps']
  },
  {
    id: 'tree-hazardous-lopping',
    title: 'Heavy Branch Lopping & Crown Thinning',
    category: 'Hazard Prevention',
    startingPrice: 999,
    duration: '1.5 - 3 Hours',
    badge: 'Monsoon Storm Safety',
    crew: '2 - 3 Specialists + Rigging Lead',
    description: 'Cutting large, heavy wooden boughs at height using rope rigging systems so falling wood does not crack roof tiles, car porches, or compound boundary walls.',
    workScope: [
      'Pre-monsoon deadwood removal to prevent storm collapse',
      'Rope-assisted controlled lowering of heavy logs',
      'Crown thinning to allow wind flow through tree',
      'Wound sealing spray on tree cuts to prevent fungal rot'
    ],
    equipmentUsed: ['Compact Chainsaw', 'Arborist Climbing Ropes', 'Lowering Pulleys & Harness', 'Tree Wound Dressing']
  },
  {
    id: 'tree-complete-felling',
    title: 'Complete Tree Felling & Stump Removal',
    category: 'Tree Removal (पेड़ काटना)',
    startingPrice: 1999,
    duration: '3 - 5 Hours',
    badge: 'Heavy Tree Removal',
    crew: '3 - 4 Heavy Arborist Crew',
    description: 'Complete removal of dead, diseased, termite-hollowed or dangerously leaning trees in residential compounds using sectional dismantling top-to-bottom.',
    workScope: [
      'Piece-by-piece sectional dismantling from tree top to bottom',
      'Trunk bucking into manageable firewood/timber logs',
      'Stump level cutting flush with ground level',
      'Complete green waste hauling & compound cleanup'
    ],
    equipmentUsed: ['Heavy Commercial Chainsaw (70cc)', 'Rigging Ropes & Winch', 'Stump Cutting Bars', 'Debris Truck Loading']
  }
];




