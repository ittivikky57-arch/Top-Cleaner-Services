import React, { useState } from 'react';
import { HelpCircle, ChevronDown, Sparkles, Languages } from 'lucide-react';
import { FAQS } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';

export const FAQSection: React.FC = () => {
  const { language, toggleLanguage, t } = useLanguage();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const hindiFaqs = [
    {
      question: 'PURE CLEANING किन-किन इलाकों में सेवाएं प्रदान करता है?',
      answer: 'PURE CLEANING सभी प्रमुख आवासीय सेक्टरों, सोसायटियों, विला और ऑफिसों में डोरस्टेप सेवा प्रदान करता है। आप बुकिंग के समय अपना इलाका चुन सकते हैं या +91 62043 19105 पर कॉल करके तुरंत पूछ सकते हैं।'
    },
    {
      question: 'क्या सर्विस के दौरान कोई छिपा हुआ या अलग से चार्ज लिया जाता है?',
      answer: 'बिल्कुल नहीं! हमारी रेट लिस्ट 100% पारदर्शी है। सिंगल रूम ₹399, बाथरूम ₹299, 1 BHK ₹999, और 2 BHK ₹1,499 से शुरू है। जो रेट आप स्क्रीन पर देखते हैं, वही फाइनल होता है।'
    },
    {
      question: 'क्या आपकी टीम अपने साथ मशीनें और केमिकल्स खुद लाती है?',
      answer: 'हाँ! हमारी टीम औद्योगिक वैक्यूम क्लीनर, सिंगल डिस्क फ्लोर स्क्रबर, स्टीम मशीन, कपड़े का शैम्पू और सभी टूल्स साथ लेकर आती है। आपको केवल पानी और बिजली का सॉकेट देना होता है।'
    },
    {
      question: 'क्या इस्तेमाल किए जाने वाले केमिकल्स बच्चों और पालतू जानवरों के लिए सुरक्षित हैं?',
      answer: 'जी हाँ, हम सरकारी प्रमाणित, बायोडिग्रेडेबल और एसिड-फ्री सुरक्षित सामग्री का उपयोग करते हैं। हम किसी भी तरह का तीखा तेज़ाब इस्तेमाल नहीं करते जिससे फर्श या स्वास्थ्य को नुकसान हो।'
    },
    {
      question: 'क्या लोडिंग और अनलोडिंग के लिए भी हेल्पर्स मिल सकते हैं?',
      answer: 'हाँ, घर शिफ्टिंग या भारी सामान (सोफा, फ्रिज, अलमारी) उठाने के लिए हमारे पास वेरीफाइड और मजबूत हेल्पर्स उपलब्ध हैं जो शोल्डर स्ट्रैप्स और स्लाइडर्स के साथ आते हैं।'
    },
    {
      question: 'पेड़ कटाई या डालियाँ छंटवाने के लिए क्या प्रक्रिया है?',
      answer: 'हमारे पास चेनसॉ और टेलीस्कोपिक आरी से लैस आर्बोरिस्ट क्रू है। वे बिजली के तारों से दूर सुरक्षित डालियों को काटकर रस्सियों से नीचे उतारते हैं और पत्तों की सफाई भी करते हैं।'
    }
  ];

  const currentFaqs = language === 'hi' ? hindiFaqs : FAQS;

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section id="faq" className="py-16 sm:py-24 bg-white border-b border-slate-200/80">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with 1-Touch Translate */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100 px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-2">
            <HelpCircle className="w-3.5 h-3.5 text-emerald-600" />
            <span>{language === 'hi' ? '3D सवाल व जवाब' : 'Got Questions?'}</span>
          </div>

          <div className="flex items-center justify-center gap-3">
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight font-display text-balance">
              {t('faqTitle')}
            </h2>
            <button
              type="button"
              onClick={toggleLanguage}
              title="Touch to switch language (टच करके भाषा बदलें)"
              className="inline-flex items-center gap-1 px-3 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border-2 border-emerald-300 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
            </button>
          </div>

          <p className="text-xs sm:text-sm text-slate-600 mt-2 font-medium">
            {language === 'hi'
              ? 'हमारी क्लीनिंग प्रक्रिया, लोडिंग हेल्पर्स, मशीनों व सुरक्षा नियमों के बारे में जरूरी जानकारी।'
              : 'Everything you need to know about our home cleaning process, equipment and safety standards.'}
          </p>
        </div>

        {/* Accordion List with 3D Depth */}
        <div className="space-y-3.5">
          {currentFaqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="bg-slate-50 rounded-2xl border-2 border-slate-200/90 overflow-hidden transition-all shadow-xs"
              >
                <button
                  type="button"
                  onClick={() => toggle(idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-100/70 transition-colors"
                  aria-expanded={isOpen}
                >
                  <span className="font-black text-sm sm:text-base text-slate-900">
                    {faq.question}
                  </span>
                  <div
                    className={`w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0 transition-transform duration-200 shadow-2xs ${
                      isOpen ? 'rotate-180 bg-emerald-50 text-emerald-700 border-emerald-300' : 'text-slate-400'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-200 bg-white/70 font-medium">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
