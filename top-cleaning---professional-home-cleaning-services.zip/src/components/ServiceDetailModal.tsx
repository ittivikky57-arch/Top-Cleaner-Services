import React from 'react';
import { X, Clock, Star, CheckCircle, Wrench, Calendar, Sparkles, ShieldCheck } from 'lucide-react';
import { ServiceItem } from '../data/cleaningData';

interface ServiceDetailModalProps {
  service: ServiceItem | null;
  onClose: () => void;
  onBookNow: (serviceName: string, price: number) => void;
}

export const ServiceDetailModal: React.FC<ServiceDetailModalProps> = ({
  service,
  onClose,
  onBookNow,
}) => {
  if (!service) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Image Header */}
        <div className="relative h-64 sm:h-72 w-full overflow-hidden bg-slate-100">
          <img
            src={service.image}
            alt={service.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/30 to-transparent pointer-events-none" />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-900/80 backdrop-blur-md text-white flex items-center justify-center hover:bg-slate-900 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Overlay info */}
          <div className="absolute bottom-4 left-6 right-6 text-white">
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-emerald-600/90 text-white text-[11px] font-bold px-2 py-0.5 rounded capitalize">
                {service.category.replace('_', ' ')}
              </span>
              <div className="flex items-center gap-1 text-xs text-amber-400 font-bold bg-slate-900/60 px-2 py-0.5 rounded backdrop-blur-xs">
                <Star className="w-3.5 h-3.5 fill-amber-400" />
                <span>{service.rating}</span>
                <span className="text-slate-300 font-normal">({service.reviewsCount} reviews)</span>
              </div>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold font-display leading-tight">
              {service.name}
            </h2>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6">
          
          {/* Quick Stats Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Estimated Time</span>
              <span className="font-bold text-slate-800 flex items-center gap-1 mt-0.5">
                <Clock className="w-3.5 h-3.5 text-emerald-600" />
                {service.duration}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Starting Price</span>
              <span className="font-black text-emerald-600 text-base font-display">
                ₹{service.startingPrice} onwards
              </span>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Hygiene Standard</span>
              <span className="font-bold text-slate-800 flex items-center gap-1 mt-0.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                Certified Safe
              </span>
            </div>
          </div>

          {/* Description */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
              Service Overview
            </h4>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {service.fullDesc}
            </p>
          </div>

          {/* Key Features */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
              Key Features & Benefits
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {service.features.map((feat, idx) => (
                <div key={idx} className="flex items-center gap-2 text-xs text-slate-700 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>

          {/* What's Included */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
              What Is Included In The Cleaning
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-600 bg-emerald-50/50 p-4 rounded-2xl border border-emerald-100">
              {service.includes.map((inc, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold shrink-0">✓</span>
                  <span>{inc}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Equipment Used */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Wrench className="w-3.5 h-3.5 text-emerald-600" />
              Professional Equipment Used
            </h4>
            <div className="flex flex-wrap gap-2 text-xs font-medium text-slate-700">
              {service.equipmentUsed.map((eq, idx) => (
                <span key={idx} className="bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
                  {eq}
                </span>
              ))}
            </div>
          </div>

          {/* CTA Footer */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-xs text-slate-400">Total Starting Price</span>
              <div className="text-2xl font-black text-slate-900 font-display">
                ₹{service.startingPrice}
              </div>
            </div>

            <button
              onClick={() => {
                onClose();
                onBookNow(service.name, service.startingPrice);
              }}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 py-3.5 px-8 text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-xl shadow-md shadow-emerald-600/25 transition-all cursor-pointer"
            >
              <Calendar className="w-4 h-4" />
              <span>Book {service.name}</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
