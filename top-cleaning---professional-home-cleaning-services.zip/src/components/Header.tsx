import React, { useState } from 'react';
import { Phone, MessageCircle, Calendar, Menu, X, Sparkles, ShieldCheck, Lock, Languages } from 'lucide-react';
import { CONTACT_INFO } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';
import { LanguageToggleBadge } from './LanguageToggleBadge';

interface HeaderProps {
  onOpenBooking: (serviceName?: string) => void;
  onOpenAdmin: () => void;
  bookingCount: number;
}

export const Header: React.FC<HeaderProps> = ({ onOpenBooking, onOpenAdmin, bookingCount }) => {
  const { language, toggleLanguage, t } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [promoDismissed, setPromoDismissed] = useState(false);

  const whatsappUrl = `https://wa.me/${CONTACT_INFO.whatsappNumber}?text=${encodeURIComponent(
    language === 'hi'
      ? 'नमस्ते PURE CLEANING, मुझे घर की सफाई या लोडिंग सर्विस बुक करनी है।\n\nनाम:\nसर्विस:\nपता:\nतारीख:\nसमय:'
      : 'Hello PURE CLEANING, I want to book a cleaning or loading service.\n\nName:\nService:\nAddress:\nPreferred Date:\nPreferred Time:'
  )}`;

  return (
    <>
      {/* Top Notification Announcement Bar */}
      {!promoDismissed && (
        <div className="bg-emerald-950 text-emerald-100 text-xs py-2 px-4 border-b border-emerald-800/80">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
              <span className="font-extrabold bg-emerald-600 text-white px-2 py-0.5 rounded text-[11px] tracking-wide shadow-2xs">
                {t('limitedOffer')}
              </span>
              <span className="text-xs">
                {t('offerText')}{' '}
                <strong className="text-emerald-300 font-mono font-bold bg-emerald-900/60 px-1.5 py-0.5 rounded border border-emerald-700/60">FIRST100</strong>
              </span>
            </div>
            
            <div className="flex items-center gap-3 shrink-0">
              {/* Quick One-Touch Switch inside top banner */}
              <button
                onClick={toggleLanguage}
                title="1-Touch Language Switch (एक टच में भाषा बदलें)"
                className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-emerald-800/80 hover:bg-emerald-700 text-white rounded-md text-[11px] font-bold border border-emerald-600/60 cursor-pointer transition-all active:scale-95"
              >
                <Languages className="w-3 h-3 text-emerald-300" />
                <span>{language === 'hi' ? 'Switch to English' : 'हिंदी में पढ़ें'}</span>
              </button>

              <span className="hidden md:inline text-emerald-400 text-xs font-medium">{t('timings')}</span>
              
              <button
                onClick={() => setPromoDismissed(true)}
                className="text-emerald-300 hover:text-white transition-colors cursor-pointer"
                aria-label="Dismiss banner"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Sticky Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs transition-shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          
          {/* Zone 1: Brand Wordmark */}
          <a href="#" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-600/25 group-hover:scale-105 group-hover:rotate-3 transition-transform">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-black tracking-tight text-slate-900 font-display">
                PURE CLEANING
              </span>
              <span className="text-[10px] uppercase font-bold text-emerald-700 tracking-wider -mt-1 hidden sm:block">
                {language === 'hi' ? 'क्लीनिंग व लोडिंग सेवाएं' : 'Cleaning & Moving Services'}
              </span>
            </div>
          </a>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden xl:flex items-center gap-3.5 text-xs font-bold text-slate-600">
            <a href="#services" className="hover:text-emerald-700 transition-colors py-1">{t('navServices')}</a>
            <a href="#loading-unloading" className="hover:text-emerald-700 transition-colors text-emerald-800 font-extrabold bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-200/60">{t('navLoading')}</a>
            <a href="#tree-pruning" className="hover:text-emerald-700 transition-colors text-emerald-800 font-extrabold bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-200/60">{t('navTree')}</a>
            <a href="#car-wash" className="hover:text-emerald-700 transition-colors py-1">{t('navCarWash')}</a>
            <a href="#materials" className="hover:text-emerald-700 transition-colors py-1">{t('navMaterials')}</a>
            <a href="#full-home" className="hover:text-emerald-700 transition-colors py-1">{t('navFullHome')}</a>
            <a href="#equipment" className="hover:text-emerald-700 transition-colors py-1">{t('navTools')}</a>
            <a href="#pricing" className="hover:text-emerald-700 transition-colors py-1">{t('navPricing')}</a>
            <a href="#calculator" className="hover:text-emerald-700 transition-colors py-1">{t('navCalculator')}</a>
            <a href="#contact" className="hover:text-emerald-700 transition-colors py-1">{t('navContact')}</a>
          </nav>

          {/* Zone 3: Primary Actions & 3D 1-Touch Language Pill */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            
            {/* 3D One-Touch Language Switcher */}
            <LanguageToggleBadge variant="header" />

            {/* Direct Call Button */}
            <a
              href={`tel:${CONTACT_INFO.phoneRaw}`}
              className="hidden lg:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors whitespace-nowrap active:scale-95"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-600" />
              <span>+91 62043 19105</span>
            </a>

            {/* WhatsApp CTA */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl transition-colors whitespace-nowrap active:scale-95"
            >
              <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t('whatsapp')}</span>
            </a>

            {/* Book Now Button with 3D tactile elevation */}
            <button
              onClick={() => onOpenBooking()}
              className="inline-flex items-center gap-1.5 px-3.5 sm:px-4 py-2 text-xs font-extrabold text-white bg-emerald-600 hover:bg-emerald-700 active:translate-y-0.5 rounded-xl shadow-[0_4px_12px_rgba(16,185,129,0.35)] transition-all whitespace-nowrap cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>{t('bookNow')}</span>
            </button>

            {/* Admin Management console access */}
            <button
              onClick={onOpenAdmin}
              title="Admin Dashboard"
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors relative cursor-pointer"
            >
              <Lock className="w-4 h-4" />
              {bookingCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 text-[10px] font-bold bg-amber-500 text-white rounded-full flex items-center justify-center">
                  {bookingCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 text-slate-600 hover:text-slate-900 rounded-xl focus:outline-none cursor-pointer"
              aria-label="Toggle Navigation"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>

        {/* Mobile Navigation Dropdown */}
        {mobileMenuOpen && (
          <div className="xl:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-150">
            {/* Quick 1-Touch Language Pill inside Mobile Menu */}
            <div className="flex items-center justify-between p-3 bg-emerald-50 rounded-2xl border border-emerald-200 mb-3">
              <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                <Languages className="w-4 h-4 text-emerald-700" />
                <span>{language === 'hi' ? 'भाषा (Language)' : 'Select Language'}</span>
              </span>
              <LanguageToggleBadge variant="header" />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-bold text-slate-700 mb-4">
              <a
                href="#services"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-xl hover:bg-slate-100 transition-colors"
              >
                {t('navServices')} (28)
              </a>
              <a
                href="#loading-unloading"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-xl bg-emerald-100/70 text-emerald-900 font-black hover:bg-emerald-200 transition-colors"
              >
                📦 {t('navLoading')}
              </a>
              <a
                href="#tree-pruning"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-xl bg-emerald-100/70 text-emerald-900 font-black hover:bg-emerald-200 transition-colors"
              >
                🌳 {t('navTree')}
              </a>
              <a
                href="#car-wash"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-xl hover:bg-slate-100 transition-colors"
              >
                🚗 {t('navCarWash')}
              </a>
              <a
                href="#materials"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-xl hover:bg-slate-100 transition-colors"
              >
                {t('navMaterials')}
              </a>
              <a
                href="#full-home"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-xl hover:bg-slate-100 transition-colors"
              >
                {t('navFullHome')}
              </a>
              <a
                href="#rooms"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-xl hover:bg-slate-100 transition-colors"
              >
                {t('navRooms')}
              </a>
              <a
                href="#equipment"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-xl hover:bg-slate-100 transition-colors"
              >
                {t('navTools')}
              </a>
              <a
                href="#before-after"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-xl hover:bg-slate-100 transition-colors"
              >
                {language === 'hi' ? 'सफाई का परिणाम' : 'Before / After'}
              </a>
              <a
                href="#pricing"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-xl hover:bg-slate-100 transition-colors"
              >
                {t('navPricing')}
              </a>
              <a
                href="#calculator"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-xl hover:bg-slate-100 transition-colors"
              >
                {t('navCalculator')}
              </a>
              <a
                href="#contact"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-xl hover:bg-slate-100 transition-colors"
              >
                {t('navContact')}
              </a>
            </div>

            <div className="flex flex-col gap-2 pt-2 border-t border-slate-100">
              <a
                href={`tel:${CONTACT_INFO.phoneRaw}`}
                className="flex items-center justify-center gap-2 w-full py-2.5 text-xs font-bold text-slate-800 bg-slate-100 rounded-xl"
              >
                <Phone className="w-4 h-4 text-emerald-600" />
                <span>{t('callNow')}: +91 62043 19105</span>
              </a>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full py-2.5 text-xs font-bold text-emerald-900 bg-emerald-50 border border-emerald-200 rounded-xl"
              >
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                <span>{language === 'hi' ? 'व्हाट्सएप पर चैट करें' : 'Chat on WhatsApp'}</span>
              </a>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
