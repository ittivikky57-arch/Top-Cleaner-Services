import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'hi' | 'en';

export interface Translations {
  [key: string]: {
    en: string;
    hi: string;
  };
}

export const DICTIONARY: Translations = {
  // Brand & Top Header
  brandTagline: {
    en: 'Professional Cleaning & Loading Services. Honest Prices. Fresh Homes.',
    hi: 'प्रोफेशनल क्लीनिंग व लोडिंग सर्विसेज। सही रेट। चमकता हुआ घर।'
  },
  limitedOffer: {
    en: 'LIMITED OFFER',
    hi: 'सीमित समय ऑफर'
  },
  offerText: {
    en: 'Get ₹100 OFF on your first booking with code',
    hi: 'अपनी पहली बुकिंग पर पाएँ ₹100 की छूट, कोड इस्तेमाल करें'
  },
  timings: {
    en: 'Mon-Sun 8 AM – 8 PM',
    hi: 'सोम-रवि सुबह 8 बजे से रात 8 बजे तक'
  },
  touchToTranslate: {
    en: '🇮🇳 हिंदी में बदलें (Touch here)',
    hi: '🇬🇧 Switch to English'
  },
  tapCardHint: {
    en: 'Touch anywhere to switch language',
    hi: 'भाषा बदलने के लिए कहीं भी टच करें'
  },

  // Navigation Links
  navServices: { en: 'Services', hi: 'सेवाएं' },
  navLoading: { en: 'Loading/Shifting', hi: 'लोडिंग व शिफ्टिंग' },
  navTree: { en: 'Tree Pruning', hi: 'पेड़ कटाई व छंटाई' },
  navCarWash: { en: 'Car Wash', hi: 'कार वॉश' },
  navMaterials: { en: 'Materials', hi: 'सफाई सामग्री' },
  navFullHome: { en: 'Full Home', hi: 'पूरा घर' },
  navRooms: { en: 'Rooms', hi: 'कमरे' },
  navTools: { en: 'Tools (औज़ार)', hi: 'औज़ार व मशीनें' },
  navPricing: { en: 'Pricing', hi: 'रेट लिस्ट' },
  navCalculator: { en: 'Calculator', hi: 'कैलकुलेटर' },
  navContact: { en: 'Contact', hi: 'संपर्क करें' },
  callNow: { en: 'Call Now', hi: 'कॉल करें' },
  whatsapp: { en: 'WhatsApp', hi: 'व्हाट्सएप' },
  bookNow: { en: 'Book Now', hi: 'अभी बुक करें' },

  // Hero Section
  heroPill: {
    en: 'Limited First Booking Offer | Use Code FIRST100',
    hi: 'पहली बुकिंग पर स्पेशल ऑफर | कोड: FIRST100'
  },
  heroHeadingPart1: {
    en: 'Get',
    hi: 'पाएं'
  },
  heroHeadingPart2: {
    en: '₹100 OFF',
    hi: '₹100 की सीधी छूट'
  },
  heroHeadingPart3: {
    en: 'on Your First Cleaning',
    hi: 'अपनी पहली होम क्लीनिंग पर'
  },
  heroSubheadline: {
    en: 'Professional home cleaning services at affordable prices.',
    hi: 'किफायती दामों पर विश्वसनीय एवं प्रोफेशनल होम क्लीनिंग सेवा।'
  },
  verifiedPros: { en: 'Verified Professionals', hi: 'वेरीफाइड प्रोफेशनल्स' },
  safeProducts: { en: 'Safe Cleaning Products', hi: 'सुरक्षित क्लीनिंग प्रोडक्ट्स' },
  transparentPricing: { en: 'Transparent Pricing', hi: 'पारदर्शी व फिक्स रेट' },
  bookCleaningNow: { en: 'Book Cleaning Now', hi: 'अभी बुकिंग करें' },
  whatsappUs: { en: 'WhatsApp Us', hi: 'व्हाट्सएप पर बात करें' },
  heroRating: { en: '4.9/5 Rating (1,400+ Homes Cleaned)', hi: '4.9/5 रेटिंग (1,400+ घरों में संतुष्ट ग्राहक)' },
  hero3DBadge: { en: '3D Deep Extraction & Sanitization', hi: '3D डीप एक्सट्रैक्शन व सैनिटाइजेशन' },

  // Search / Booking Box
  bookServiceTitle: { en: 'Book a Cleaning Service', hi: 'क्लीनिंग व लोडिंग सर्विस बुक करें' },
  bookServiceSub: { en: 'Instant pricing, verified technician matching & slot reservation.', hi: 'तुरंत अनुमानित रेट, ट्रेंड टीम और अपने मनपसंद समय पर बुकिंग।' },
  selectService: { en: 'Select Service', hi: 'सर्विस चुनें' },
  selectProperty: { en: 'Select Property Type', hi: 'घर / जगह का प्रकार चुनें' },
  selectDate: { en: 'Select Date', hi: 'तारीख चुनें' },
  selectTime: { en: 'Select Time Slot', hi: 'समय (टाइम स्लॉट) चुनें' },
  enterAddress: { en: 'Service Address / Locality', hi: 'घर का पता / इलाका दर्ज करें' },
  mobileNumber: { en: 'Mobile Number', hi: 'मोबाइल नंबर' },
  estimatedPrice: { en: 'Estimated Price', hi: 'अनुमानित रेट' },
  offApplied: { en: '₹100 OFF Applied', hi: '₹100 छूट शामिल' },
  checkPriceBtn: { en: 'Check Price & Confirm Booking', hi: 'रेट चेक करें और बुकिंग कन्फर्म करें' },

  // Services Grid
  servicesTitle: { en: 'Professional Home Cleaning Services', hi: 'प्रोफेशनल होम क्लीनिंग सर्विसेज' },
  servicesSub: { en: 'Choose the service your home needs. 28 verified specialized treatments.', hi: 'अपनी आवश्यकता अनुसार सर्विस चुनें। 28 प्रमाणित स्पेशलाइज्ड सर्विसेज।' },
  searchServicePlaceholder: { en: 'Search service (e.g. Sofa, Kitchen, Bathroom, Full Home)...', hi: 'सर्विस खोजें (उदा: सोफा, किचन, बाथरूम, पूरा घर)...' },
  allCategories: { en: 'All Services', hi: 'सभी सर्विसेज' },
  catFullHome: { en: 'Full Home', hi: 'पूरा घर डीप क्लीन' },
  catRooms: { en: 'Rooms', hi: 'कमरे' },
  catKitchenBath: { en: 'Kitchen & Bath', hi: 'किचन व बाथरूम' },
  catFabric: { en: 'Sofa & Fabric', hi: 'सोफा व कारपेट' },
  catSpecialized: { en: 'Specialized', hi: 'स्पेशल काम (लोडिंग, पेड़, कार)' },
  viewDetails: { en: 'View Details', hi: 'पूरी डिटेल देखें' },
  startingFrom: { en: 'Starting', hi: 'शुरुआती रेट' },

  // Loading & Unloading
  loadingTitle: { en: 'Loading & Unloading Work — Time & Rates', hi: 'सामान लोडिंग व अनलोडिंग — समय और रेट' },
  loadingSubHindi: { en: 'Trained & verified helpers for safe house shifting (Fixed rates & time)', hi: 'सामान लोड और अनलोड करने के लिए ट्रेंड एवं वेरीफाइड हेल्पर्स (फिक्स रेट & समय)' },
  loadingDesc: {
    en: 'Need strong, dependable manpower to lift heavy refrigerators, sofas, double beds, or unload your shifting truck? PURE CLEANING provides verified helpers equipped with shoulder lifting harnesses, furniture sliders, and safety gloves.',
    hi: 'भारी फ्रिज, सोफा, डबल बेड उठाने या शिफ्टिंग ट्रक खाली करने के लिए मजबूत व भरोसेमंद मजदूर चाहिए? PURE CLEANING के वेरीफाइड हेल्पर्स शोल्डर हार्नेस, फर्नीचर स्लाइडर व सेफ़्टी ग्लव्स के साथ आते हैं।'
  },
  tabPackages: { en: 'Helper Packages (हेल्पर पैकेज)', hi: 'हेल्पर पैकेज' },
  tabVehicleRates: { en: 'Vehicle Work Time & Rate Table (गाड़ी अनुसार रेट व समय)', hi: 'गाड़ी अनुसार रेट व समय तालिका' },
  workIncluded: { en: 'Work Included (काम का विवरण):', hi: 'काम का विवरण:' },
  equipmentBrought: { en: 'Helpers Equipment Brought:', hi: 'हेल्पर साथ में क्या लाएंगे:' },
  bookHelpers: { en: 'Book Helpers', hi: 'हेल्पर बुक करें' },
  vehicleTableTitle: { en: 'Vehicle-Wise Loading & Unloading Rates & Work Time', hi: 'गाड़ी के आकार अनुसार काम का समय और लेबर रेट' },
  colVehicle: { en: 'Vehicle / Tempo Type', hi: 'गाड़ी / टेम्पो का प्रकार' },
  colCapacity: { en: 'Capacity / Home Size', hi: 'क्षमता / घर का आकार' },
  colHelpers: { en: 'Helpers Assigned', hi: 'हेल्पर्स की संख्या' },
  colWorkTime: { en: 'Work Time (समय)', hi: 'काम का समय' },
  colRate: { en: 'Rate (रेट)', hi: 'रेट' },
  colAction: { en: 'Action', hi: 'बुकिंग' },

  // Tree Felling & Pruning
  treeTitle: { en: 'Tree Felling & Pruning Work', hi: 'पेड़ कटाई व छंटाई का काम' },
  treeSubHindi: { en: 'Safe tree cutting, branch lopping and boundary hedge trimming', hi: 'सुरक्षित पेड़ कटाई, डालियों की छंटाई और बाउंड्री हेज ट्रिमिंग' },
  treeDesc: {
    en: 'Overgrown branches touching balcony railings or electric wires? Dangerous leaning tree threatening your roof tiles? PURE CLEANING deploys equipped arborists with telescopic pole saws, rigging ropes, chainsaws, and safety harnesses.',
    hi: 'बालकनी या बिजली के तारों को छूती अनचाही डालियाँ? छत पर गिरता खतरनाक झुका हुआ पेड़? PURE CLEANING के प्रशिक्षित पेड़ काटने वाले टेलीस्कोपिक आरी, रस्सियों, चेनसॉ और सेफ़्टी बेल्ट के साथ सुरक्षित काम करते हैं।'
  },
  workScope: { en: 'Work Scope (काम का दायरा):', hi: 'काम का दायरा:' },
  machineryUsed: { en: 'Machinery & Tools (औज़ार):', hi: 'मशीनें व औज़ार:' },
  bookTreeService: { en: 'Book Service', hi: 'सर्विस बुक करें' },

  // Car Wash
  carWashTitle: { en: 'Doorstep Car Washing & Detailing', hi: 'घर बैठे कार वॉश व डीप क्लीनिंग' },
  carWashSub: {
    en: 'We bring high-pressure snow foam cannons, dual-action vacuums, steam sanitizers & tire dressings directly to your parking bay. No waiting at service centers.',
    hi: 'हम हाई-प्रेशर स्नो-फोम मशीन, वैक्यूम, स्टीम सैनिटाइजर व टायर शाइनर सीधे आपकी पार्किंग में लाते हैं। सर्विस सेंटर पर लाइन लगाने की जरूरत नहीं।'
  },
  selectCarType: { en: 'Select Your Vehicle Type:', hi: 'अपनी गाड़ी का प्रकार चुनें:' },
  exteriorColumn: { en: 'Exterior Snow Foam & Wash', hi: 'बाहरी स्नो-फोम वॉश' },
  interiorColumn: { en: 'Interior Deep Vacuum & Detailing', hi: 'अंदरूनी वैक्यूम व सीट क्लीनिंग' },
  finishingColumn: { en: 'Paint Polish & Tire Glow', hi: 'पेंट पॉलिश व टायर शाइन' },

  // Materials & Equipment
  materialsTitle: { en: 'Certified Cleaning Materials & Safe Chemicals', hi: 'प्रमाणित क्लीनिंग सामग्री व सुरक्षित केमिकल्स' },
  materialsSub: {
    en: 'We strictly prohibit corrosive acids and harsh chlorine that destroy grout and damage faucets. PURE CLEANING uses hospital-grade, eco-certified and food-safe solutions.',
    hi: 'हम कठोर तेज़ाब या हानिकारक एसिड का इस्तेमाल नहीं करते जो टाइल्स या नलों को खराब करें। PURE CLEANING बच्चों और पालतू जानवरों के लिए 100% सुरक्षित सामग्री उपयोग करता है।'
  },
  equipmentTitle: { en: 'Professional Equipment & Machinery', hi: 'प्रोफेशनल उपकरण, मशीनें एवं औज़ार' },
  equipmentSub: { en: 'High-Performance Machines & Authentic Cleaning Tools (औज़ार)', hi: 'हाई-परफॉर्मेंस मशीनें और सफाई के असली औज़ार' },

  // Full Home BHK
  fullHomeTitle: { en: 'Full Home Deep Cleaning Packages', hi: 'फुल होम डीप क्लीनिंग पैकेज' },
  fullHomeSub: { en: 'Specialized complete floor-to-ceiling sanitization with heavy-duty machines.', hi: 'बड़ी मशीनों के साथ फर्श से छत तक पूरे घर की डीप सफाई।' },
  
  // Room By Room
  roomsTitle: { en: 'Clean Every Room With Care', hi: 'हर कमरे की अलग से डीप सफाई' },
  roomsSub: { en: 'Book individual rooms without committing to full apartment packages.', hi: 'पूरे घर के बजाय केवल जिस कमरे की जरूरत हो, उसे बुक करें।' },

  // Before After
  beforeAfterTitle: { en: 'Real Before & After Cleaning Results', hi: 'सफाई के पहले और बाद का असली फर्क' },
  beforeAfterSub: { en: 'Drag the 3D comparison slider to see actual results achieved in homes.', hi: '3D स्लाइडर को खिसकाकर हमारे काम का असली असर खुद देखें।' },

  // Pricing
  pricingTitle: { en: 'Affordable & Transparent Cleaning Prices', hi: 'किफायती एवं पारदर्शी रेट लिस्ट' },
  pricingSub: { en: 'No hidden estimates. No surprise visit fees. What you see is what you pay.', hi: 'कोई छुपा हुआ चार्ज नहीं। कोई विज़िटिंग फीस नहीं। जो रेट दिखे, वही फाइनल।' },

  // Price Calculator
  calcTitle: { en: 'Interactive Cleaning Cost Calculator', hi: 'इंटरएक्टिव क्लीनिंग व लोडिंग कैलकुलेटर' },
  calcSub: { en: 'Customize property type, cleaning depth and add-ons for an accurate instant estimate.', hi: 'अपने घर का साइज, सफाई का स्तर व एक्स्ट्रा काम चुनकर तुरंत फाइनल रेट निकालें।' },

  // About & Why Choose
  aboutTitle: { en: 'About PURE CLEANING', hi: 'PURE CLEANING के बारे में' },
  whyChooseTitle: { en: 'Why Choose PURE CLEANING', hi: 'PURE CLEANING को ही क्यों चुनें?' },

  // Reviews & FAQ
  reviewsTitle: { en: 'Customer Reviews & Real Feedback', hi: 'ग्राहकों की राय एवं रिव्यू' },
  faqTitle: { en: 'Frequently Asked Questions (FAQ)', hi: 'अक्सर पूछे जाने वाले सवाल (FAQ)' },

  // Contact
  contactTitle: { en: 'Get In Touch With PURE CLEANING', hi: 'PURE CLEANING से संपर्क करें' },
  contactSub: { en: 'Have a question or need custom villa/commercial quotation? Reach us directly.', hi: 'कोई सवाल है या विशेष काम के लिए बात करनी है? हमसे सीधा संपर्क करें।' },
  fullName: { en: 'Your Full Name', hi: 'आपका पूरा नाम' },
  sendInquiry: { en: 'Send Service Inquiry', hi: 'पूछताछ मैसेज भेजें' },

  // 3D Toggle Prompt
  tapToToggle3D: { en: '3D Visual Mode Active', hi: '3D विजुअल मोड सक्रिय' }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  t: (key: string, fallback?: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('hi'); // Default to Hindi as per user request to make it easiest to understand, with 1-touch toggle

  useEffect(() => {
    const savedLang = localStorage.getItem('pure_cleaning_lang') as Language;
    if (savedLang === 'en' || savedLang === 'hi') {
      setLanguage(savedLang);
    }
  }, []);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('pure_cleaning_lang', lang);
  };

  const toggleLanguage = () => {
    const next = language === 'hi' ? 'en' : 'hi';
    handleSetLanguage(next);
  };

  const t = (key: string, fallback?: string): string => {
    if (DICTIONARY[key]) {
      return DICTIONARY[key][language] || DICTIONARY[key].en;
    }
    return fallback || key;
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage: handleSetLanguage,
        toggleLanguage,
        t
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
