import React from 'react';
import { Languages, Sparkles } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface LanguageToggleBadgeProps {
  variant?: 'header' | 'floating' | 'hero' | 'compact';
  className?: string;
}

export const LanguageToggleBadge: React.FC<LanguageToggleBadgeProps> = ({
  variant = 'header',
  className = ''
}) => {
  const { language, toggleLanguage } = useLanguage();

  if (variant === 'compact') {
    return (
      <button
        onClick={toggleLanguage}
        title={language === 'hi' ? 'Switch to English' : 'हिंदी में बदलें'}
        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold transition-all duration-200 cursor-pointer select-none border shadow-xs active:translate-y-0.5 ${
          language === 'hi'
            ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
            : 'bg-emerald-50 text-emerald-900 border-emerald-300 hover:bg-emerald-100'
        } ${className}`}
      >
        <Languages className="w-3.5 h-3.5 text-emerald-600" />
        <span>{language === 'hi' ? '🇮🇳 हिंदी' : '🇬🇧 English'}</span>
      </button>
    );
  }

  if (variant === 'hero') {
    return (
      <button
        onClick={toggleLanguage}
        className={`group relative inline-flex items-center gap-2.5 px-4 py-2 rounded-2xl border-2 transition-all duration-300 shadow-md hover:shadow-lg active:scale-95 cursor-pointer bg-white ${
          language === 'hi'
            ? 'border-emerald-500 shadow-emerald-500/20'
            : 'border-blue-500 shadow-blue-500/20'
        } ${className}`}
      >
        <span className="flex h-2.5 w-2.5 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-600"></span>
        </span>
        <div className="flex items-center gap-1.5 text-xs font-black tracking-wide text-slate-800">
          <Languages className="w-4 h-4 text-emerald-600 group-hover:rotate-180 transition-transform duration-500" />
          <span>{language === 'hi' ? 'भाषा: 🇮🇳 हिंदी' : 'Language: 🇬🇧 English'}</span>
        </div>
        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase tracking-wider">
          {language === 'hi' ? '1-Touch English' : '1-टच हिंदी'}
        </span>
      </button>
    );
  }

  // Header 3D pill toggle button
  return (
    <div className={`relative inline-flex items-center p-0.5 rounded-xl bg-slate-100 border border-slate-200/90 shadow-inner ${className}`}>
      <button
        type="button"
        onClick={() => toggleLanguage()}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition-all duration-300 cursor-pointer select-none ${
          language === 'hi'
            ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-[0_4px_10px_rgba(16,185,129,0.35)] translate-y-[-1px]'
            : 'text-slate-600 hover:text-slate-900'
        }`}
      >
        <span>🇮🇳</span>
        <span>हिंदी</span>
      </button>

      <button
        type="button"
        onClick={() => toggleLanguage()}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition-all duration-300 cursor-pointer select-none ${
          language === 'en'
            ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-[0_4px_10px_rgba(16,185,129,0.35)] translate-y-[-1px]'
            : 'text-slate-600 hover:text-slate-900'
        }`}
      >
        <span>🇬🇧</span>
        <span>English</span>
      </button>
    </div>
  );
};
