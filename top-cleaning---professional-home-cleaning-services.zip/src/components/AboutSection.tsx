import React from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  Users,
  Award,
  Clock,
  HeartHandshake,
  Sparkles,
  PhoneCall,
  CreditCard,
  ThumbsUp,
  Languages
} from 'lucide-react';
import { ASSET_IMAGES, CONTACT_INFO } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';
import { ThreeDCard } from './ThreeDCard';

export const AboutSection: React.FC = () => {
  const { language, toggleLanguage, t } = useLanguage();

  const whyChooseFeatures = [
    { 
      title: language === 'hi' ? 'प्रशिक्षित एवं वेरीफाइड प्रोफेशनल्स' : 'Trained Professionals', 
      desc: language === 'hi' ? 'बैकग्राउंड चेक, पुलिस वेरीफाइड और 40 घंटे प्रैक्टिकल ट्रेनिंग प्राप्त अनुभवी कर्मचारी।' : 'Background verified, police checked and rigorous 40-hour hands-on trained technicians.' 
    },
    { 
      title: language === 'hi' ? 'किफायती एवं फिक्स रेट' : 'Affordable Prices', 
      desc: language === 'hi' ? '₹299 से शुरू होने वाले रेट ताकि हर परिवार बिना जेब पर बोझ डाले घर को साफ रख सके।' : 'Honest rates from ₹299 so every household can enjoy deep hygiene without overpaying.' 
    },
    { 
      title: language === 'hi' ? '100% पारदर्शी कोटेशन' : 'Transparent Charges', 
      desc: language === 'hi' ? 'कोई छुपा टैक्स नहीं, कोई अचानक आने वाला ट्रैवल चार्ज या केमिकल फीस नहीं।' : 'Zero hidden taxes, no surprise travel surcharges or chemical add-on fees.' 
    },
    { 
      title: language === 'hi' ? 'आधुनिक मशीनें एवं औज़ार' : 'Professional Equipment', 
      desc: language === 'hi' ? 'औद्योगिक वेट/ड्राई वैक्यूम, रोटरी फ्लोर स्क्रबर, स्टीम मशीन और 140-बार प्रेशर जेट्स।' : 'Industrial wet/dry vacuums, rotary scrubbers, steam cleaners and high-pressure jets.' 
    },
    { 
      title: language === 'hi' ? 'सुरक्षित एवं प्रमाणित केमिकल्स' : 'Safe Cleaning Products', 
      desc: language === 'hi' ? 'हॉस्पिटल-ग्रेड, बच्चों और पालतू जानवरों के लिए पूरी तरह सुरक्षित, बिना किसी तेज़ाब की गंध के।' : 'Hospital-grade, child-safe and pet-safe biodegradable solutions without noxious acid fumes.' 
    },
    { 
      title: language === 'hi' ? '1-मिनट में आसान बुकिंग' : 'Convenient Booking', 
      desc: language === 'hi' ? 'वेबसाइट पर 60 सेकंड में या सीधे व्हाट्सएप (+91 62043 19105) पर त्वरित स्लॉट बुक करें।' : 'Book in 60 seconds on website or directly via WhatsApp at +91 62043 19105.' 
    },
  ];

  const additionalFeatures = [
    { 
      title: language === 'hi' ? 'समय पर पहुंचने की गारंटी' : 'On-Time Service Guarantee', 
      desc: language === 'hi' ? 'आपके चुने हुए स्लॉट पर टीम की समय पर उपस्थिति।' : 'Punctual arrival at your selected slot.' 
    },
    { 
      title: language === 'hi' ? 'समर्पित कस्टमर सपोर्ट' : 'Dedicated Customer Support', 
      desc: language === 'hi' ? 'फोन व व्हाट्सएप डेस्क रोजाना सुबह 8 से रात 8 बजे तक उपलब्ध।' : 'Direct phone & WhatsApp desk everyday 8 AM - 8 PM.' 
    },
    { 
      title: language === 'hi' ? 'क्वालिटी वॉक-थ्रू इंस्पेक्शन' : 'Quality Checked Service', 
      desc: language === 'hi' ? 'टीम जाने से पहले आपके साथ हर कोने का मुआयना करती है।' : 'Inspection walk-through with you before technician departs.' 
    },
    { 
      title: language === 'hi' ? 'सुविधाजनक पेमेंट विकल्प' : 'Multiple Payment Options', 
      desc: language === 'hi' ? 'काम पूरा होने पर UPI, GPay, PhonePe, कार्ड या कैश से भुगतान करें।' : 'Pay via UPI, GPay, PhonePe, Card or Cash after service.' 
    },
  ];

  return (
    <div id="about" className="space-y-0">
      
      {/* 15. About Us Main Section */}
      <section className="py-16 sm:py-24 bg-white border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Visual Asset */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-2 border-slate-200 bg-slate-100">
                <img
                  src={ASSET_IMAGES.hero}
                  alt="Professional PURE CLEANING technician working in modern Indian home"
                  referrerPolicy="no-referrer"
                  className="w-full h-[400px] object-cover object-center"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />
                
                {/* Floating experience badge */}
                <div className="absolute bottom-6 left-6 right-6 p-4 rounded-2xl bg-white/95 backdrop-blur-md border border-slate-200 text-slate-900 shadow-xl">
                  <div className="text-2xl font-black text-emerald-600 font-display">
                    2,800+
                  </div>
                  <div className="text-xs font-black text-slate-800">
                    {language === 'hi' ? 'संतुष्ट ग्राहक · घर, गाड़ियाँ व शिफ्टिंग काम' : 'Homes & Offices Cleaned & Moved'}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5 font-medium">
                    {language === 'hi' ? 'विश्वसनीयता व ईमानदारी के लिए 4.9/5 स्टार रेटिंग।' : 'Consistent 4.9/5 star ratings for reliability and honesty.'}
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: About Content */}
            <div className="lg:col-span-7 flex flex-col space-y-6">
              <div className="flex items-center justify-between">
                <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{language === 'hi' ? 'हमारी विरासत एवं विज़न' : 'Our Heritage & Vision'}</span>
                </div>

                <button
                  type="button"
                  onClick={toggleLanguage}
                  className="inline-flex items-center gap-1 px-3 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border-2 border-emerald-300 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
                >
                  <Languages className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
                </button>
              </div>

              <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight font-display text-balance">
                {t('aboutTitle')}
              </h2>

              <div className="space-y-4 text-sm sm:text-base text-slate-600 leading-relaxed font-medium">
                <p>
                  <strong>PURE CLEANING</strong> {language === 'hi' 
                    ? 'एक आधुनिक और विश्वसनीय होम क्लीनिंग, कार वॉश, पेड़ कटाई और लोडिंग-अनलोडिंग सर्विस प्लेटफॉर्म है, जिसका उद्देश्य हर घर को स्वच्छ, सुंदर और शिफ्टिंग को आसान बनाना है।'
                    : 'is a professional home, commercial cleaning and loading-unloading assistance service focused on making everyday spaces cleaner, healthier, and moving hassle-free.'}
                </p>
                <p>
                  {language === 'hi'
                    ? 'हम ग्राहकों को प्रशिक्षित कर्मचारियों और उचित, पारदर्शी दामों पर सेवा उपलब्ध कराते हैं। न कोई छिपा हुआ चार्ज, न कोई अतिरिक्त मांग।'
                    : 'We connect customers with trained cleaning professionals and reliable shifting helpers at transparent and honest prices.'}
                </p>
                <p>
                  {language === 'hi'
                    ? 'पूरे घर की डीप सफाई से लेकर फर्नीचर लोडिंग, पेड़ छंटाई, सोफा शैम्पू और चिमनी सफाई तक — हमारा लक्ष्य केवल एक है: उत्तम गुणवत्ता और भरोसेमंद सेवा।'
                    : 'From complete home deep cleaning to furniture loading, truck unloading, kitchens, bathrooms, and sofas, our goal is simple — quality cleaning and dependable labor service.'}
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5 pt-4 border-t border-slate-100">
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                  <span className="text-[11px] text-slate-400 font-bold uppercase block">{language === 'hi' ? 'हेल्पलाइन' : 'Customer Support'}</span>
                  <div className="text-sm font-black text-slate-900 mt-0.5">+91 62043 19105</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                  <span className="text-[11px] text-slate-400 font-bold uppercase block">{language === 'hi' ? 'ईमेल' : 'Email Enquiries'}</span>
                  <div className="text-sm font-black text-slate-900 mt-0.5 truncate">{CONTACT_INFO.email}</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 col-span-2 sm:col-span-1">
                  <span className="text-[11px] text-slate-400 font-bold uppercase block">{language === 'hi' ? 'काम के घंटे' : 'Operating Hours'}</span>
                  <div className="text-sm font-black text-slate-900 mt-0.5">8:00 AM – 8:00 PM</div>
                </div>
              </div>

            </div>

          </div>
        </div>
      </section>

      {/* 16. Why Choose PURE CLEANING */}
      <section className="py-16 sm:py-24 bg-slate-50 border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-14">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100 px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-2">
              <Award className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'hi' ? '3D एडवांटेज' : 'The Pure Cleaning Advantage'}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight font-display text-balance">
              {t('whyChooseTitle')}
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-2 font-medium">
              {language === 'hi' 
                ? 'हमने अपनी सेवा को उन 6 प्रमुख स्तंभों पर तैयार किया है जिनकी हर परिवार को सबसे ज्यादा जरूरत होती है।' 
                : 'We engineered our service around the 6 core pillars modern homeowners care about most.'}
            </p>
          </div>

          {/* 6 Core Feature Cards with 3D Perspective */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {whyChooseFeatures.map((feat, idx) => (
              <ThreeDCard key={idx} allowTouchTranslate={true}>
                <div className="p-6 bg-white rounded-3xl border-2 border-slate-200 hover:border-emerald-400 shadow-sm transition-all h-full">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-black text-sm mb-4">
                    0{idx + 1}
                  </div>
                  <h3 className="text-base font-black text-slate-900 mb-2">
                    {feat.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed font-medium">
                    {feat.desc}
                  </p>
                </div>
              </ThreeDCard>
            ))}
          </div>

          {/* 4 Secondary Benefits Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {additionalFeatures.map((item, idx) => (
              <div key={idx} className="p-4 bg-white rounded-2xl border border-slate-200 flex items-start gap-3 shadow-2xs">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-black text-slate-900">{item.title}</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5 font-medium">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

    </div>
  );
};
