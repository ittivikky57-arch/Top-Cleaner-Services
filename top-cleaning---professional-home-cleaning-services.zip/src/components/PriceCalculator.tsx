import React, { useState, useMemo } from 'react';
import { Calculator, Sparkles, Check, ArrowRight, ShieldCheck, Tag, Languages } from 'lucide-react';
import { CONTACT_INFO } from '../data/cleaningData';
import { useLanguage } from '../context/LanguageContext';

interface PriceCalculatorProps {
  onBookCalculated: (summary: {
    propertyType: string;
    cleaningType: string;
    addons: string[];
    price: number;
  }) => void;
}

export const PriceCalculator: React.FC<PriceCalculatorProps> = ({ onBookCalculated }) => {
  const { language, toggleLanguage, t } = useLanguage();
  const [propertyType, setPropertyType] = useState<string>('2 BHK');
  const [cleaningTier, setCleaningTier] = useState<'Standard' | 'Deep Cleaning' | 'Premium'>('Deep Cleaning');
  
  const [selectedAddons, setSelectedAddons] = useState<Record<string, boolean>>({
    'Sofa Shampooing': true,
    'Kitchen Degreasing': false,
    'Bathroom Descaling': false,
    'Carpet Cleaning': false,
    'Mattress Sanitization': false,
    'Window & Track Cleaning': false,
    'Balcony Jet Wash': false,
    'General Pest Control': false,
  });

  const [promoCode, setPromoCode] = useState<string>('FIRST100');
  const [isPromoApplied, setIsPromoApplied] = useState<boolean>(true);

  const addonPrices: Record<string, number> = {
    'Sofa Shampooing': 399,
    'Kitchen Degreasing': 449,
    'Bathroom Descaling': 299,
    'Carpet Cleaning': 399,
    'Mattress Sanitization': 399,
    'Window & Track Cleaning': 199,
    'Balcony Jet Wash': 249,
    'General Pest Control': 599,
  };

  const addonHindiLabels: Record<string, string> = {
    'Sofa Shampooing': 'सोफा शैम्पू वॉश',
    'Kitchen Degreasing': 'किचन चिमनी व तेल हटाना',
    'Bathroom Descaling': 'बाथरूम खारे पानी के दाग हटाना',
    'Carpet Cleaning': 'कारपेट व दरी क्लीनिंग',
    'Mattress Sanitization': 'गद्दे सैनिटाइजेशन',
    'Window & Track Cleaning': 'खिड़की व चैनल सफाई',
    'Balcony Jet Wash': 'बालकनी हाई प्रेशर जेट वॉश',
    'General Pest Control': 'पेस्ट कंट्रोल ट्रीटमेंट',
  };

  const basePrices: Record<string, Record<string, number>> = {
    '1 BHK': { Standard: 699, 'Deep Cleaning': 999, Premium: 1399 },
    '2 BHK': { Standard: 1099, 'Deep Cleaning': 1499, Premium: 1999 },
    '3 BHK': { Standard: 1499, 'Deep Cleaning': 1999, Premium: 2599 },
    '4 BHK': { Standard: 1899, 'Deep Cleaning': 2499, Premium: 3299 },
    'Bungalow / Villa': { Standard: 2799, 'Deep Cleaning': 3499, Premium: 4499 },
  };

  const calculatedTotal = useMemo(() => {
    let base = basePrices[propertyType]?.[cleaningTier] || 1499;

    Object.entries(selectedAddons).forEach(([addonName, isChecked]) => {
      if (isChecked) {
        base += addonPrices[addonName] || 0;
      }
    });

    if (isPromoApplied) {
      base = Math.max(299, base - CONTACT_INFO.firstBookingDiscount);
    }

    return base;
  }, [propertyType, cleaningTier, selectedAddons, isPromoApplied]);

  const toggleAddon = (addon: string) => {
    setSelectedAddons((prev) => ({
      ...prev,
      [addon]: !prev[addon],
    }));
  };

  const handleApplyPromo = () => {
    if (promoCode.trim().toUpperCase() === 'FIRST100') {
      setIsPromoApplied(true);
    }
  };

  const activeAddonNames = useMemo(() => {
    return Object.entries(selectedAddons)
      .filter(([_, isChecked]) => isChecked)
      .map(([name]) => name);
  }, [selectedAddons]);

  const handleBook = () => {
    onBookCalculated({
      propertyType,
      cleaningType: cleaningTier,
      addons: activeAddonNames,
      price: calculatedTotal,
    });
  };

  return (
    <section id="calculator" className="py-16 sm:py-24 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading with 1-Touch Translate */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100/80 border border-emerald-300 px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-3 shadow-2xs">
            <Calculator className="w-3.5 h-3.5 text-emerald-700" />
            <span>{language === 'hi' ? '3D लाइव कॉस्ट कैलकुलेटर' : 'Live Estimate Engine'}</span>
          </div>

          <div className="flex items-center justify-center gap-3">
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight font-display text-balance">
              {t('calcTitle')}
            </h2>
            <button
              type="button"
              onClick={toggleLanguage}
              title="Touch to switch language (टच करके भाषा बदलें)"
              className="inline-flex items-center gap-1 px-3 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border-2 border-emerald-300 rounded-full text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
            </button>
          </div>

          <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-xl mx-auto leading-relaxed font-medium">
            {t('calcSub')}
          </p>
        </div>

        {/* 3D Calculator Container */}
        <div className="bg-slate-50 rounded-3xl p-6 sm:p-8 lg:p-10 border-2 border-slate-200 shadow-[0_20px_50px_rgba(0,0,0,0.06)] grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Interactive Inputs */}
          <div className="lg:col-span-8 space-y-8">
            
            {/* Step 1: Property Type */}
            <div>
              <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-3">
                {language === 'hi' ? '1. घर का आकार चुनें:' : '1. Select Property Type:'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                {['1 BHK', '2 BHK', '3 BHK', '4 BHK', 'Bungalow / Villa'].map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setPropertyType(type)}
                    className={`py-3 px-2 rounded-2xl text-xs font-black transition-all cursor-pointer border text-center ${
                      propertyType === type
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-[0_4px_10px_rgba(16,185,129,0.35)] -translate-y-0.5'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 2: Cleaning Level */}
            <div>
              <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-3">
                {language === 'hi' ? '2. सफाई का स्तर चुनें:' : '2. Select Cleaning Intensity:'}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  {
                    tier: 'Standard' as const,
                    title: language === 'hi' ? 'स्टैंडर्ड क्लीन' : 'Standard Clean',
                    desc: language === 'hi' ? 'डस्टिंग, वैक्यूमिंग और फर्श सैनिटाइजेशन।' : 'Dusting, dry vacuuming, wet mop, basic bath wipe.'
                  },
                  {
                    tier: 'Deep Cleaning' as const,
                    title: language === 'hi' ? 'डीप क्लीनिंग (बेस्ट)' : 'Deep Cleaning',
                    desc: language === 'hi' ? 'मशीन स्क्रबिंग, हार्ड वाटर डीस्केलिंग, एग्जॉस्ट डिग्रेसिंग।' : 'Tile scrubbing, hard water descaling, chimney degrease.'
                  },
                  {
                    tier: 'Premium' as const,
                    title: language === 'hi' ? 'प्रीमियम स्टेरलाइजेशन' : 'Premium Sterilize',
                    desc: language === 'hi' ? '140°C स्टीम डिसइन्फेक्शन, वुड पॉलिश व ग्लास शीन।' : '140°C dry steam sanitization, woodwork conditioning, glass sheen.'
                  }
                ].map((item) => (
                  <button
                    key={item.tier}
                    type="button"
                    onClick={() => setCleaningTier(item.tier)}
                    className={`p-4 rounded-2xl text-left border-2 transition-all cursor-pointer ${
                      cleaningTier === item.tier
                        ? 'bg-emerald-50 border-emerald-500 shadow-sm'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="font-black text-xs sm:text-sm text-slate-900">{item.title}</div>
                    <div className="text-xs text-slate-500 mt-1 leading-snug font-medium">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 3: Additional Services */}
            <div>
              <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-3">
                {language === 'hi' ? '3. एक्स्ट्रा सर्विस चुनें (वैकल्पिक):' : '3. Choose Add-on Services (Optional):'}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {Object.keys(addonPrices).map((addon) => {
                  const isChecked = selectedAddons[addon] || false;
                  return (
                    <button
                      key={addon}
                      type="button"
                      onClick={() => toggleAddon(addon)}
                      className={`p-3 rounded-2xl border-2 flex items-center justify-between text-left transition-all cursor-pointer ${
                        isChecked
                          ? 'bg-emerald-50 border-emerald-400'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-4 h-4 rounded-md flex items-center justify-center border transition-colors ${
                            isChecked
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : 'border-slate-300 bg-white'
                          }`}
                        >
                          {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                        <span className="text-xs sm:text-sm font-bold text-slate-800">
                          {language === 'hi' ? addonHindiLabels[addon] || addon : addon}
                        </span>
                      </div>
                      <span className="text-xs font-black text-slate-900 font-mono">
                        +₹{addonPrices[addon]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Right Column: Live Price Summary with 3D Pop */}
          <div className="lg:col-span-4 flex flex-col justify-between bg-white rounded-3xl p-6 border-2 border-slate-200 shadow-xl">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500">
                  {language === 'hi' ? 'कोटेशन समरी' : 'Quote Summary'}
                </span>
                <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200">
                  {language === 'hi' ? 'लाइव कैलकुलेशन' : 'Live Calculation'}
                </span>
              </div>

              {/* Breakdown lines */}
              <div className="mt-4 space-y-2 text-xs text-slate-600 font-medium">
                <div className="flex justify-between">
                  <span>{language === 'hi' ? 'घर का प्रकार:' : 'Property Type:'}</span>
                  <span className="font-bold text-slate-900">{propertyType}</span>
                </div>
                <div className="flex justify-between">
                  <span>{language === 'hi' ? 'सफाई का स्तर:' : 'Cleaning Level:'}</span>
                  <span className="font-bold text-slate-900">{cleaningTier}</span>
                </div>
                <div className="flex justify-between">
                  <span>{language === 'hi' ? 'बेस पैकेज:' : 'Base Package:'}</span>
                  <span className="font-bold text-slate-900">
                    ₹{basePrices[propertyType]?.[cleaningTier]}
                  </span>
                </div>

                {/* Selected addons list */}
                {activeAddonNames.map((addon) => (
                  <div key={addon} className="flex justify-between text-slate-500 pl-2">
                    <span>+ {language === 'hi' ? addonHindiLabels[addon] || addon : addon}</span>
                    <span className="font-semibold text-slate-700">₹{addonPrices[addon]}</span>
                  </div>
                ))}

                {isPromoApplied && (
                  <div className="flex justify-between text-emerald-700 font-bold pt-2 border-t border-slate-100">
                    <span>{language === 'hi' ? 'FIRST100 छूट:' : 'FIRST100 Discount:'}</span>
                    <span>-₹{CONTACT_INFO.firstBookingDiscount}</span>
                  </div>
                )}
              </div>

              {/* Promo Code Box */}
              <div className="mt-6 pt-4 border-t border-slate-100">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                    placeholder="PROMO CODE"
                    className="flex-1 px-3 py-2 text-xs font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl uppercase text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={handleApplyPromo}
                    className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black transition-colors cursor-pointer"
                  >
                    {language === 'hi' ? 'लागू करें' : 'Apply'}
                  </button>
                </div>
              </div>

              {/* Grand Total */}
              <div className="mt-6 p-4 bg-emerald-50/90 rounded-2xl border border-emerald-200 text-center">
                <div className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider">
                  {language === 'hi' ? 'कुल फाइनल अनुमानित रेट' : 'Total Estimated Price'}
                </div>
                <div className="text-3xl font-black text-slate-900 font-display mt-1">
                  ₹{calculatedTotal}
                </div>
                <div className="text-[10px] text-emerald-700 font-bold mt-0.5">
                  ✓ {language === 'hi' ? 'टैक्स व केमिकल्स शामिल' : 'Inclusive of all supplies & crew'}
                </div>
              </div>

            </div>

            {/* 3D Action Button */}
            <div className="mt-6 space-y-2">
              <button
                type="button"
                onClick={handleBook}
                className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-4 text-xs font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-2xl shadow-[0_5px_0_#047857] active:translate-y-1 active:shadow-none transition-all cursor-pointer"
              >
                <span>{language === 'hi' ? `इस रेट पर बुक करें (₹${calculatedTotal})` : `Book at this Price (₹${calculatedTotal})`}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
